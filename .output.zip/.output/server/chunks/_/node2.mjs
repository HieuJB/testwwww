import _satori from 'satori';

const node = {
  initWasmPromise: Promise.resolve(),
  satori: _satori
};

export { node as default };
//# sourceMappingURL=node2.mjs.map
