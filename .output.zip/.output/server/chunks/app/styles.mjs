const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/.pnpm/nuxt@3.9.1_@types+node@18.18.9_eslint@8.53.0_rollup@3.29.4_typescript@5.2.2_vite@5.0.11/node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.I70iGnJt.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.6iimVXkX.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
