const client_manifest = {
  "_logo.wp8_XMO4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo.wp8_XMO4.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_@types+node@18.18.9_eslint@8.53.0_rollup@3.29.4_typescript@5.2.2_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "i18n.config.ts?hash=bffaebcb&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "i18n.config.aLWhNpGX.js",
    "isDynamicEntry": true,
    "src": "i18n.config.ts?hash=bffaebcb&config=1"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-1.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-300-1.oYcJdSap.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-1.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-2.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-300-2.yXyAqcnH.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-2.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-4.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-300-4.cfHnVZpf.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-4.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-5.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-300-5.D2WvShPy.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-5.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-6.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-300-6.c0VT00tv.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-6.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-7.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-300-7.Ys4GWd8s.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-300-7.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-11.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-500-11.YPAS6IZh.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-11.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-12.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-500-12.KdFdAQAB.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-12.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-13.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-500-13.DkCYcml3.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-13.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-14.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-500-14.uolvK3YK.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-14.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-8.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-500-8.Sby9w-4W.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-8.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-9.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-500-9.P4WpnKb_.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-500-9.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-15.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-700-15.smYIdND7.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-15.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-16.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-700-16.I67kCE3Q.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-16.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-18.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-700-18.bNOZ9WR1.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-18.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-19.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-700-19.gW4XodLC.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-19.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-20.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-700-20.3IQW81c1.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-20.woff2"
  },
  "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-21.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Roboto-700-21.m2GA31kg.woff2",
    "src": "node_modules/.cache/nuxt-google-fonts/fonts/Roboto-700-21.woff2"
  },
  "node_modules/.pnpm/nuxt@3.9.1_@types+node@18.18.9_eslint@8.53.0_rollup@3.29.4_typescript@5.2.2_vite@5.0.11/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "i18n.config.ts?hash=bffaebcb&config=1"
    ],
    "file": "entry.axEWF5A3.js",
    "isEntry": true,
    "src": "node_modules/.pnpm/nuxt@3.9.1_@types+node@18.18.9_eslint@8.53.0_rollup@3.29.4_typescript@5.2.2_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "pages/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.h2R7CMgc.js",
    "imports": [
      "_logo.wp8_XMO4.js",
      "node_modules/.pnpm/nuxt@3.9.1_@types+node@18.18.9_eslint@8.53.0_rollup@3.29.4_typescript@5.2.2_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/[id].vue"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.4fq_7E4-.js",
    "imports": [
      "_logo.wp8_XMO4.js",
      "node_modules/.pnpm/nuxt@3.9.1_@types+node@18.18.9_eslint@8.53.0_rollup@3.29.4_typescript@5.2.2_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.8xal7amS.css": {
    "file": "index.8xal7amS.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
