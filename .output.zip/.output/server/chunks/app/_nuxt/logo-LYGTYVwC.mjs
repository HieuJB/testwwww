import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, computed, toValue, reactive, defineComponent, mergeProps, unref, ref, shallowRef, toRef, getCurrentInstance, onServerPrefetch, onUnmounted, h, resolveComponent } from 'vue';
import { t as fetchDefaults, q as useState, r as asyncDataDefaults, v as useRequestFetch, u as useRoute, b as useI18n, e as useHead, d as useLocalePath, g as useSchemaOrg, a as useRouter, i as hasProtocol, j as joinURL, p as parseURL, k as parseQuery$1, n as nuxtLinkDefaults, s as useNuxtApp, c as createError, l as useRuntimeConfig, m as navigateTo, w as withTrailingSlash$1, o as withoutTrailingSlash$1 } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate, ssrRenderClass, ssrRenderAttr, ssrRenderList, ssrRenderComponent } from 'vue/server-renderer';
import { n as hash } from '../../nitro/node-server.mjs';
import { useClipboard } from '@vueuse/core';

const firstNonUndefined = (...args) => args.find((arg) => arg !== void 0);
const DEFAULT_EXTERNAL_REL_ATTRIBUTE = "noopener noreferrer";
// @__NO_SIDE_EFFECTS__
function defineNuxtLink(options) {
  const componentName = options.componentName || "NuxtLink";
  const resolveTrailingSlashBehavior = (to, resolve) => {
    if (!to || options.trailingSlash !== "append" && options.trailingSlash !== "remove") {
      return to;
    }
    if (typeof to === "string") {
      return applyTrailingSlashBehavior(to, options.trailingSlash);
    }
    const path = "path" in to ? to.path : resolve(to).path;
    return {
      ...to,
      name: void 0,
      // named routes would otherwise always override trailing slash behavior
      path: applyTrailingSlashBehavior(path, options.trailingSlash)
    };
  };
  return defineComponent({
    name: componentName,
    props: {
      // Routing
      to: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      href: {
        type: [String, Object],
        default: void 0,
        required: false
      },
      // Attributes
      target: {
        type: String,
        default: void 0,
        required: false
      },
      rel: {
        type: String,
        default: void 0,
        required: false
      },
      noRel: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Prefetching
      prefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      noPrefetch: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Styling
      activeClass: {
        type: String,
        default: void 0,
        required: false
      },
      exactActiveClass: {
        type: String,
        default: void 0,
        required: false
      },
      prefetchedClass: {
        type: String,
        default: void 0,
        required: false
      },
      // Vue Router's `<RouterLink>` additional props
      replace: {
        type: Boolean,
        default: void 0,
        required: false
      },
      ariaCurrentValue: {
        type: String,
        default: void 0,
        required: false
      },
      // Edge cases handling
      external: {
        type: Boolean,
        default: void 0,
        required: false
      },
      // Slot API
      custom: {
        type: Boolean,
        default: void 0,
        required: false
      }
    },
    setup(props, { slots }) {
      const router = useRouter();
      const config = useRuntimeConfig();
      const to = computed(() => {
        const path = props.to || props.href || "";
        return resolveTrailingSlashBehavior(path, router.resolve);
      });
      const isProtocolURL = computed(() => typeof to.value === "string" && hasProtocol(to.value, { acceptRelative: true }));
      const isExternal = computed(() => {
        if (props.external) {
          return true;
        }
        if (props.target && props.target !== "_self") {
          return true;
        }
        if (typeof to.value === "object") {
          return false;
        }
        return to.value === "" || isProtocolURL.value;
      });
      const prefetched = ref(false);
      const el = void 0;
      const elRef = void 0;
      return () => {
        var _a2;
        var _a, _b;
        if (!isExternal.value) {
          const routerLinkProps = {
            ref: elRef,
            to: to.value,
            activeClass: props.activeClass || options.activeClass,
            exactActiveClass: props.exactActiveClass || options.exactActiveClass,
            replace: props.replace,
            ariaCurrentValue: props.ariaCurrentValue,
            custom: props.custom
          };
          if (!props.custom) {
            if (prefetched.value) {
              routerLinkProps.class = props.prefetchedClass || options.prefetchedClass;
            }
            routerLinkProps.rel = props.rel;
          }
          return h(
            resolveComponent("RouterLink"),
            routerLinkProps,
            slots.default
          );
        }
        const href = typeof to.value === "object" ? (_a2 = (_a = router.resolve(to.value)) == null ? void 0 : _a.href) != null ? _a2 : null : to.value && !props.external && !isProtocolURL.value ? resolveTrailingSlashBehavior(joinURL(config.app.baseURL, to.value), router.resolve) : to.value || null;
        const target = props.target || null;
        const rel = props.noRel ? null : firstNonUndefined(props.rel, options.externalRelAttribute, href ? DEFAULT_EXTERNAL_REL_ATTRIBUTE : "") || null;
        const navigate = () => navigateTo(href, { replace: props.replace });
        if (props.custom) {
          if (!slots.default) {
            return null;
          }
          return slots.default({
            href,
            navigate,
            get route() {
              if (!href) {
                return void 0;
              }
              const url = parseURL(href);
              return {
                path: url.pathname,
                fullPath: url.pathname,
                get query() {
                  return parseQuery$1(url.search);
                },
                hash: url.hash,
                // stub properties for compat with vue-router
                params: {},
                name: void 0,
                matched: [],
                redirectedFrom: void 0,
                meta: {},
                href
              };
            },
            rel,
            target,
            isExternal: isExternal.value,
            isActive: false,
            isExactActive: false
          });
        }
        return h("a", { ref: el, href, rel, target }, (_b = slots.default) == null ? void 0 : _b.call(slots));
      };
    }
  });
}
const __nuxt_component_0 = /* @__PURE__ */ defineNuxtLink(nuxtLinkDefaults);
function applyTrailingSlashBehavior(to, trailingSlash) {
  const normalizeFn = trailingSlash === "append" ? withTrailingSlash$1 : withoutTrailingSlash$1;
  const hasProtocolDifferentFromHttp = hasProtocol(to) && !to.startsWith("http");
  if (hasProtocolDifferentFromHttp) {
    return to;
  }
  return normalizeFn(to, true);
}
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _sfc_main$4 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<svg${ssrRenderAttrs(mergeProps({
    height: "1em",
    viewBox: "0 0 677 128",
    xmlns: "http://www.w3.org/2000/svg"
  }, _attrs))}><path d="M65.968 31.24C62.64 29.0213 59.184 27.1867 55.6 25.736C52.1013 24.2 48.7307 23.3467 45.488 23.176C43.44 23.0907 41.6053 23.2187 39.984 23.56C38.3627 23.816 36.912 24.328 35.632 25.096C34.4373 25.7787 33.456 26.7173 32.688 27.912C32.0053 29.1067 31.5787 30.5147 31.408 32.136C31.152 34.3547 31.7493 36.4027 33.2 38.28C34.736 40.072 36.784 41.736 39.344 43.272C41.9893 44.808 44.7627 46.216 47.664 47.496C51.1627 49.032 54.4907 50.952 57.648 53.256C60.8053 55.56 63.28 58.5893 65.072 62.344C66.864 66.0133 67.376 70.8347 66.608 76.808C66.1813 80.392 65.072 83.7627 63.28 86.92C61.488 90.0773 59.056 92.8507 55.984 95.24C52.9973 97.544 49.4133 99.2933 45.232 100.488C41.0507 101.683 36.3147 102.109 31.024 101.768C27.44 101.512 23.856 100.915 20.272 99.976C16.688 99.0373 13.1893 97.7573 9.776 96.136C6.36267 94.4293 3.12 92.296 0.0480001 89.736L10.032 75.784C11.9947 77.4907 14.2133 79.0693 16.688 80.52C19.1627 81.8853 21.68 82.9947 24.24 83.848C26.8 84.7013 29.1893 85.2133 31.408 85.384C33.6267 85.4693 35.888 85.2987 38.192 84.872C40.496 84.36 42.5013 83.3787 44.208 81.928C45.9147 80.4773 46.9387 78.3867 47.28 75.656C47.536 73.7787 47.1093 72.0293 46 70.408C44.8907 68.7867 43.3973 67.2933 41.52 65.928C39.6427 64.5627 37.5093 63.3253 35.12 62.216C32.3893 60.936 29.5733 59.4853 26.672 57.864C23.7707 56.2427 21.0827 54.3227 18.608 52.104C16.2187 49.8853 14.384 47.1547 13.104 43.912C11.824 40.6693 11.4827 36.8293 12.08 32.392C12.7627 26.9307 14.5547 22.28 17.456 18.44C20.3573 14.5147 24.1547 11.5707 28.848 9.60799C33.5413 7.56 38.832 6.57866 44.72 6.66399C49.7547 6.92 54.064 7.60266 57.648 8.712C61.3173 9.73599 64.5173 11.016 67.248 12.552C69.9787 14.088 72.496 15.752 74.8 17.544L65.968 31.24ZM102.949 87.304C104.656 87.304 106.277 87.0053 107.813 86.408C109.434 85.8107 111.056 85.0853 112.677 84.232L118.949 98.056C116.133 99.4213 113.146 100.488 109.989 101.256C106.917 102.024 103.93 102.408 101.029 102.408C94.885 102.408 89.509 101.384 84.901 99.336C80.3783 97.2027 76.837 94.0027 74.277 89.736C71.717 85.384 70.437 79.9653 70.437 73.48C70.437 70.152 71.0343 66.696 72.229 63.112C73.509 59.528 75.429 56.2 77.989 53.128C80.6343 49.9707 84.0477 47.4107 88.229 45.448C92.4957 43.4853 97.6157 42.504 103.589 42.504C106.832 42.504 110.032 42.9307 113.189 43.784C116.432 44.552 119.376 46.0027 122.021 48.136C124.752 50.184 127.056 53.0853 128.933 56.84C130.896 60.5947 132.261 65.4587 133.029 71.432L87.973 82.568L85.157 72.584L120.229 63.496L113.957 65.416C113.274 62.5147 111.909 60.296 109.861 58.76C107.898 57.224 105.594 56.456 102.949 56.456C99.4503 56.456 96.6343 57.1813 94.501 58.632C92.3677 60.0827 90.789 61.96 89.765 64.264C88.8263 66.568 88.357 68.9573 88.357 71.432C88.357 75.6987 89.125 78.984 90.661 81.288C92.2823 83.592 94.2023 85.1707 96.421 86.024C98.725 86.8773 100.901 87.304 102.949 87.304ZM156.413 102.28C152.744 102.365 149.16 101.341 145.661 99.208C142.162 97.0747 139.261 93.96 136.957 89.864C134.738 85.768 133.629 80.8187 133.629 75.016C133.629 70.8347 134.397 66.824 135.933 62.984C137.469 59.0587 139.645 55.56 142.461 52.488C145.277 49.3307 148.605 46.856 152.445 45.064C156.285 43.1867 160.509 42.248 165.117 42.248C168.872 42.248 171.901 42.6747 174.205 43.528C176.594 44.3813 178.514 45.4907 179.965 46.856C181.416 48.136 182.653 49.544 183.677 51.08L182.525 53.768L185.341 45.064H201.981L195.197 101H177.277L178.685 88.84L179.709 92.68C179.538 92.68 178.941 93.192 177.917 94.216C176.893 95.1547 175.4 96.264 173.437 97.544C171.56 98.824 169.17 99.976 166.269 101C163.453 101.939 160.168 102.365 156.413 102.28ZM166.525 87.944C168.232 87.944 169.853 87.6453 171.389 87.048C173.01 86.3653 174.546 85.4267 175.997 84.232C177.448 82.952 178.728 81.3733 179.837 79.496L181.501 65.8C181.074 63.9227 180.264 62.344 179.069 61.064C177.874 59.6987 176.381 58.6747 174.589 57.992C172.797 57.224 170.749 56.84 168.445 56.84C165.544 56.84 163.069 57.352 161.021 58.376C158.973 59.4 157.266 60.7227 155.901 62.344C154.621 63.9653 153.682 65.7147 153.085 67.592C152.488 69.384 152.189 71.1333 152.189 72.84C152.189 75.912 152.786 78.6 153.981 80.904C155.176 83.1227 156.84 84.872 158.973 86.152C161.192 87.3467 163.709 87.944 166.525 87.944ZM229.01 45.064L228.498 57.48C230.546 54.152 232.978 51.3787 235.794 49.16C238.695 46.856 241.597 45.1493 244.498 44.04C247.485 42.8453 250.002 42.248 252.05 42.248L248.978 60.168C244.882 59.656 241.213 60.3387 237.97 62.216C234.727 64.0933 232.125 66.568 230.162 69.64C228.199 72.712 227.005 75.8693 226.578 79.112L223.89 101H206.098L212.882 45.064H229.01ZM297.046 97.416C294.486 99.0373 291.414 100.317 287.83 101.256C284.331 102.195 280.875 102.664 277.462 102.664C275.158 102.664 272.342 102.28 269.014 101.512C265.686 100.829 262.401 99.5493 259.158 97.672C255.915 95.7093 253.185 92.9787 250.966 89.48C248.833 85.896 247.766 81.3307 247.766 75.784C247.766 72.1147 248.406 68.4027 249.686 64.648C250.966 60.8933 252.886 57.4373 255.446 54.28C258.006 51.1227 261.249 48.6053 265.174 46.728C269.099 44.7653 273.75 43.784 279.126 43.784C284.843 43.784 289.622 44.6373 293.462 46.344C297.387 48.0507 300.587 50.1413 303.062 52.616L292.95 63.496C291.841 62.3867 290.219 61.2773 288.086 60.168C285.953 59.0587 283.35 58.504 280.278 58.504C277.803 58.504 275.457 59.1867 273.238 60.552C271.019 61.9173 269.227 63.7947 267.862 66.184C266.497 68.5733 265.814 71.3467 265.814 74.504C265.814 77.064 266.411 79.368 267.606 81.416C268.801 83.464 270.507 85.128 272.726 86.408C274.945 87.6027 277.59 88.2 280.662 88.2C282.369 88.2 283.947 87.9867 285.398 87.56C286.934 87.1333 288.299 86.4933 289.494 85.64L297.046 97.416ZM326.147 54.152C328.536 50.6533 331.694 47.8373 335.619 45.704C339.63 43.4853 344.238 42.376 349.443 42.376C354.734 42.376 358.915 43.9547 361.987 47.112C365.144 50.184 366.51 54.1947 366.083 59.144L360.963 101H343.043L347.267 65.8C347.438 63.3253 347.011 61.3627 345.987 59.912C344.963 58.376 343 57.608 340.099 57.608C337.368 57.608 334.851 58.504 332.547 60.296C330.328 62.088 328.494 64.52 327.043 67.592C325.592 70.664 324.611 74.2053 324.099 78.216L321.283 101H303.363L315.651 0.00799561H333.187L326.275 57.352L326.147 54.152ZM385.76 6.79199H450.016L447.968 24.072H402.912L400.352 45.064H440.16L437.984 62.728H398.176L395.616 83.208H442.464L440.288 101H374.24L385.76 6.79199ZM472.543 45.064L472.799 55.944L472.543 54.152C475.188 50.3973 478.303 47.496 481.887 45.448C485.556 43.3147 489.738 42.248 494.431 42.248C498.954 42.248 502.58 43.144 505.311 44.936C508.127 46.6427 509.748 49.4587 510.175 53.384L509.919 53.512C512.65 50.2693 515.807 47.5813 519.391 45.448C523.06 43.3147 526.73 42.248 530.399 42.248C535.946 42.248 540.17 43.8267 543.071 46.984C545.972 50.056 547.167 54.0667 546.655 59.016L541.535 101H523.743L527.967 66.44C528.138 63.9653 527.967 61.96 527.455 60.424C527.028 58.8027 525.578 57.9067 523.103 57.736C520.202 57.736 517.642 58.76 515.423 60.808C513.204 62.7707 511.412 65.3307 510.047 68.488C508.682 71.56 507.786 74.76 507.359 78.088L504.543 101H486.623L490.847 66.44C491.018 63.9653 490.804 61.96 490.207 60.424C489.61 58.8027 488.074 57.9067 485.599 57.736C482.783 57.736 480.266 58.76 478.047 60.808C475.914 62.7707 474.164 65.288 472.799 68.36C471.519 71.432 470.666 74.5893 470.239 77.832L467.423 101H449.503L456.287 45.064H472.543ZM582.272 102.536C578.944 102.536 575.488 102.024 571.904 101C568.32 99.8907 564.949 98.2267 561.792 96.008C558.72 93.7893 556.203 90.9307 554.24 87.432C552.363 83.9333 551.424 79.752 551.424 74.888C551.424 71.4747 551.979 67.8907 553.088 64.136C554.283 60.3813 556.16 56.8827 558.72 53.64C561.28 50.312 564.693 47.624 568.96 45.576C573.227 43.528 578.432 42.504 584.576 42.504C589.611 42.504 594.432 43.5707 599.04 45.704C603.733 47.752 607.573 50.824 610.56 54.92C613.632 59.016 615.168 64.0933 615.168 70.152C615.168 72.2853 614.869 74.8027 614.272 77.704C613.675 80.52 612.651 83.3787 611.2 86.28C609.749 89.1813 607.787 91.8693 605.312 94.344C602.837 96.7333 599.68 98.696 595.84 100.232C592.085 101.768 587.563 102.536 582.272 102.536ZM582.784 87.816C586.453 87.816 589.312 86.8773 591.36 85C593.408 83.1227 594.859 80.8613 595.712 78.216C596.565 75.5707 596.992 73.1387 596.992 70.92C596.992 67.9333 596.48 65.544 595.456 63.752C594.517 61.8747 593.323 60.4667 591.872 59.528C590.421 58.5893 588.971 57.9493 587.52 57.608C586.069 57.2667 584.875 57.096 583.936 57.096C580.437 57.096 577.621 58.0347 575.488 59.912C573.355 61.704 571.819 63.9227 570.88 66.568C569.941 69.2133 569.472 71.688 569.472 73.992C569.472 77.832 570.24 80.7333 571.776 82.696C573.397 84.6587 575.232 86.024 577.28 86.792C579.413 87.4747 581.248 87.816 582.784 87.816ZM609.695 116.872C612.426 114.995 614.687 112.691 616.479 109.96C618.271 107.229 619.38 103.901 619.807 99.976L626.591 45.064H644.511L637.599 101C636.831 107.144 634.911 112.477 631.839 117C628.852 121.523 624.458 125.192 618.655 128.008L609.695 116.872ZM627.615 25.352C627.615 22.6213 628.554 20.3173 630.431 18.44C632.308 16.5627 634.783 15.624 637.855 15.624C639.988 15.624 642.122 16.264 644.255 17.544C646.388 18.7387 647.455 20.872 647.455 23.944C647.455 26.5893 646.516 28.8933 644.639 30.856C642.762 32.7333 640.287 33.672 637.215 33.672C635.082 33.672 632.948 33.0747 630.815 31.88C628.682 30.6 627.615 28.424 627.615 25.352ZM655.247 45.064H673.167L666.255 101H648.335L655.247 45.064ZM656.399 25.352C656.399 22.6213 657.338 20.3173 659.215 18.44C661.092 16.5627 663.567 15.624 666.639 15.624C668.772 15.624 670.906 16.264 673.039 17.544C675.172 18.7387 676.239 20.872 676.239 23.944C676.239 26.5893 675.3 28.8933 673.423 30.856C671.546 32.7333 669.071 33.672 665.999 33.672C663.866 33.672 661.732 33.0747 659.599 31.88C657.466 30.6 656.399 28.424 656.399 25.352Z" fill="currentColor"></path></svg>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Logo.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$2]]);
const useColorMode = () => {
  return useState("color-mode").value;
};
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "ThemeToggle",
  __ssrInlineRender: true,
  setup(__props) {
    const colorMode = useColorMode();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "ml-4 text-2xl cursor-pointer items-center relative group flex items-center" }, _attrs))}><i style="${ssrRenderStyle(unref(colorMode).value === "system" ? null : { display: "none" })}" class="icon-[solar--display-bold]" role="img" aria-hidden="true"></i><i style="${ssrRenderStyle(unref(colorMode).value === "light" ? null : { display: "none" })}" class="icon-[solar--sun-bold]" role="img" aria-hidden="true"></i><i style="${ssrRenderStyle(unref(colorMode).value === "dark" ? null : { display: "none" })}" class="icon-[solar--moon-stars-bold]" role="img" aria-hidden="true"></i><div role="tooltip" class="absolute top-7 right-0 whitespace-nowrap card rounded-lg p-2 text-sm color-action hidden md:group-hover:block">${ssrInterpolate(unref(colorMode).value === "light" ? _ctx.$t("darkTip") : _ctx.$t("lightTip"))}</div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ThemeToggle.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_ThemeToggle = _sfc_main$3;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_ThemeToggle, null, null, _parent));
  _push(`<a href="https://github.com/rotick/searchemoji" target="_blank" aria-label="Folk on GitHub" class="no-icon text-2xl ml-4 flex items-center"><i class="icon-[mdi--github]" role="img" aria-hidden="true"></i></a></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ToolBar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const isDefer = (dedupe) => dedupe === "defer" || dedupe === false;
function useAsyncData(...args) {
  var _a2, _b, _c, _d, _e, _f, _g, _h, _i;
  var _a;
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  let [key, handler, options = {}] = args;
  if (typeof key !== "string") {
    throw new TypeError("[nuxt] [asyncData] key must be a string.");
  }
  if (typeof handler !== "function") {
    throw new TypeError("[nuxt] [asyncData] handler must be a function.");
  }
  const nuxt = useNuxtApp();
  const getDefault = () => null;
  const getDefaultCachedData = () => nuxt.isHydrating ? nuxt.payload.data[key] : nuxt.static.data[key];
  options.server = (_a2 = options.server) != null ? _a2 : true;
  options.default = (_b = options.default) != null ? _b : getDefault;
  options.getCachedData = (_c = options.getCachedData) != null ? _c : getDefaultCachedData;
  options.lazy = (_d = options.lazy) != null ? _d : false;
  options.immediate = (_e = options.immediate) != null ? _e : true;
  options.deep = (_f = options.deep) != null ? _f : asyncDataDefaults.deep;
  options.dedupe = (_g = options.dedupe) != null ? _g : "cancel";
  const hasCachedData = () => ![null, void 0].includes(options.getCachedData(key));
  if (!nuxt._asyncData[key] || !options.immediate) {
    (_h = (_a = nuxt.payload._errors)[key]) != null ? _h : _a[key] = null;
    const _ref = options.deep ? ref : shallowRef;
    nuxt._asyncData[key] = {
      data: _ref((_i = options.getCachedData(key)) != null ? _i : options.default()),
      pending: ref(!hasCachedData()),
      error: toRef(nuxt.payload._errors, key),
      status: ref("idle")
    };
  }
  const asyncData = { ...nuxt._asyncData[key] };
  asyncData.refresh = asyncData.execute = (opts = {}) => {
    var _a3;
    if (nuxt._asyncDataPromises[key]) {
      if (isDefer((_a3 = opts.dedupe) != null ? _a3 : options.dedupe)) {
        return nuxt._asyncDataPromises[key];
      }
      nuxt._asyncDataPromises[key].cancelled = true;
    }
    if ((opts._initial || nuxt.isHydrating && opts._initial !== false) && hasCachedData()) {
      return Promise.resolve(options.getCachedData(key));
    }
    asyncData.pending.value = true;
    asyncData.status.value = "pending";
    const promise = new Promise(
      (resolve, reject) => {
        try {
          resolve(handler(nuxt));
        } catch (err) {
          reject(err);
        }
      }
    ).then((_result) => {
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      let result = _result;
      if (options.transform) {
        result = options.transform(_result);
      }
      if (options.pick) {
        result = pick(result, options.pick);
      }
      nuxt.payload.data[key] = result;
      asyncData.data.value = result;
      asyncData.error.value = null;
      asyncData.status.value = "success";
    }).catch((error) => {
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      asyncData.error.value = createError(error);
      asyncData.data.value = unref(options.default());
      asyncData.status.value = "error";
    }).finally(() => {
      if (promise.cancelled) {
        return;
      }
      asyncData.pending.value = false;
      delete nuxt._asyncDataPromises[key];
    });
    nuxt._asyncDataPromises[key] = promise;
    return nuxt._asyncDataPromises[key];
  };
  const initialFetch = () => asyncData.refresh({ _initial: true });
  const fetchOnServer = options.server !== false && nuxt.payload.serverRendered;
  if (fetchOnServer && options.immediate) {
    const promise = initialFetch();
    if (getCurrentInstance()) {
      onServerPrefetch(() => promise);
    } else {
      nuxt.hook("app:created", async () => {
        await promise;
      });
    }
  }
  const asyncDataPromise = Promise.resolve(nuxt._asyncDataPromises[key]).then(() => asyncData);
  Object.assign(asyncDataPromise, asyncData);
  return asyncDataPromise;
}
function pick(obj, keys) {
  const newObj = {};
  for (const key of keys) {
    newObj[key] = obj[key];
  }
  return newObj;
}
function useFetch(request, arg1, arg2) {
  const [opts = {}, autoKey] = typeof arg1 === "string" ? [{}, arg1] : [arg1, arg2];
  const _request = computed(() => {
    let r = request;
    if (typeof r === "function") {
      r = r();
    }
    return toValue(r);
  });
  const _key = opts.key || hash([autoKey, typeof _request.value === "string" ? _request.value : "", ...generateOptionSegments(opts)]);
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useFetch] key must be a string: " + _key);
  }
  if (!request) {
    throw new Error("[nuxt] [useFetch] request is missing.");
  }
  const key = _key === autoKey ? "$f" + _key : _key;
  if (!opts.baseURL && typeof _request.value === "string" && (_request.value[0] === "/" && _request.value[1] === "/")) {
    throw new Error('[nuxt] [useFetch] the request URL must not start with "//".');
  }
  const {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    watch,
    immediate,
    getCachedData,
    deep,
    ...fetchOptions
  } = opts;
  const _fetchOptions = reactive({
    ...fetchDefaults,
    ...fetchOptions,
    cache: typeof opts.cache === "boolean" ? void 0 : opts.cache
  });
  const _asyncDataOptions = {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    immediate,
    getCachedData,
    deep,
    watch: watch === false ? [] : [_fetchOptions, _request, ...watch || []]
  };
  let controller;
  const asyncData = useAsyncData(key, () => {
    var _a;
    (_a = controller == null ? void 0 : controller.abort) == null ? void 0 : _a.call(controller);
    controller = typeof AbortController !== "undefined" ? new AbortController() : {};
    const timeoutLength = toValue(opts.timeout);
    if (timeoutLength) {
      setTimeout(() => controller.abort(), timeoutLength);
    }
    let _$fetch = opts.$fetch || globalThis.$fetch;
    if (!opts.$fetch) {
      const isLocalFetch = typeof _request.value === "string" && _request.value[0] === "/" && (!toValue(opts.baseURL) || toValue(opts.baseURL)[0] === "/");
      if (isLocalFetch) {
        _$fetch = useRequestFetch();
      }
    }
    return _$fetch(_request.value, { signal: controller.signal, ..._fetchOptions });
  }, _asyncDataOptions);
  return asyncData;
}
function generateOptionSegments(opts) {
  var _a;
  const segments = [
    ((_a = toValue(opts.method)) == null ? void 0 : _a.toUpperCase()) || "GET",
    toValue(opts.baseURL)
  ];
  for (const _obj of [opts.params || opts.query]) {
    const obj = toValue(_obj);
    if (!obj) {
      continue;
    }
    const unwrapped = {};
    for (const [key, value] of Object.entries(obj)) {
      unwrapped[toValue(key)] = toValue(value);
    }
    segments.push(unwrapped);
  }
  return segments;
}
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Detail",
  __ssrInlineRender: true,
  props: {
    emoji: {
      type: [Object],
      default: null
    }
  },
  setup(__props) {
    var _a, _b, _c, _d, _e, _f;
    const props = __props;
    const route = useRoute();
    const { locale, t } = useI18n();
    const rtl = computed(() => ["ar", "he"].includes(locale.value));
    const defaultData = {
      c: ((_a = props.emoji) == null ? void 0 : _a.c) || "",
      q: "",
      e: ((_b = props.emoji) == null ? void 0 : _b.e) || "",
      v: "",
      n: "",
      g: ((_c = props.emoji) == null ? void 0 : _c.g) || "",
      s: ((_d = props.emoji) == null ? void 0 : _d.s) || "",
      t: ((_e = props.emoji) == null ? void 0 : _e.t) || "",
      k: []
    };
    const id = ((_f = props.emoji) == null ? void 0 : _f.c) || route.params.id;
    const { data: fetchData, error } = useFetch(`/api/emoji/${id}`, { query: { locale: locale.value } }, "$P6DINpTQHI");
    const data = computed(() => fetchData.value || defaultData);
    const title = computed(() => t("seo.detailTitle", { emoji: data.value.e, name: data.value.t }));
    const description = computed(
      () => t("seo.detailDescription", {
        emoji: data.value.e,
        name: data.value.t,
        version: data.value.v,
        group: data.value.g,
        code: `U+${data.value.c.replace(/ /g, " U+")}`,
        oName: data.value.n
      })
    );
    useHead({
      title,
      meta: [{ name: "description", content: description }]
    });
    const source = computed(() => data.value.e);
    const { copy, copied } = useClipboard({ source, legacy: true });
    function handleCopy(e) {
      if ((e.metaKey || e.ctrlKey) && e.key === "c") {
        const selection = (void 0).getSelection();
        if (!(selection == null ? void 0 : selection.toString())) {
          copy(source.value);
        }
      }
    }
    const isMac = ref(false);
    const isAndroidQQ = ref(false);
    onUnmounted(() => {
      (void 0).removeEventListener("keydown", handleCopy);
    });
    const platform = [
      {
        name: "Apple",
        imgPath: "apple"
      },
      {
        name: "Google",
        imgPath: "google"
      },
      {
        name: "Facebook",
        imgPath: "facebook"
      },
      {
        name: "X / Twitter",
        imgPath: "x"
      },
      {
        name: "Microsoft",
        imgPath: "microsoft"
      },
      {
        name: "Samsung",
        imgPath: "samsung"
      },
      {
        name: "Whatsapp",
        imgPath: "whatsapp"
      }
    ];
    const localePath = useLocalePath();
    const schema = computed(() => {
      var _a2, _b2, _c2, _d2, _e2, _f2, _g;
      return [
        // delete when nuxt-schema-org fix the bug, delete defineWebSite and defineWebPage
        // defineWebSite({
        //   '@id': 'https://searchemoji.app/#website',
        //   '@type': 'WebSite',
        //   description: t('seo.title'),
        //   inLanguage: locale.value,
        //   name: 'SearchEmoji',
        //   url: 'https://searchemoji.app',
        //   publisher: {
        //     '@id': 'https://searchemoji.app/#identity'
        //   }
        // }),
        // defineWebPage({
        //   '@id': `https://searchemoji.app${localePath('/' + data.value?.c || '')}/#webpage`,
        //   '@type': 'WebPage',
        //   description: description.value,
        //   name: title.value,
        //   url: localePath('/' + data.value?.c || ''),
        //   about: {
        //     '@id': 'https://searchemoji.app/#identity'
        //   },
        //   isPartOf: {
        //     '@id': 'https://searchemoji.app/#website'
        //   }
        // }),
        {
          "@id": `https://searchemoji.app${localePath("/" + ((_a2 = data.value) == null ? void 0 : _a2.c) || "")}/#VisualArtwork`,
          "@type": "VisualArtwork",
          name: ((_b2 = data.value) == null ? void 0 : _b2.t) || "",
          alternateName: ((_c2 = data.value) == null ? void 0 : _c2.n) || "",
          keywords: ((_d2 = data.value) == null ? void 0 : _d2.k.join(",")) || "",
          url: localePath("/" + ((_e2 = data.value) == null ? void 0 : _e2.c) || ""),
          creator: {
            "@type": "Organization",
            name: "Unicode",
            url: "https://unicode.org/"
          },
          image: {
            "@type": "ImageObject",
            contentUrl: `https://img.searchemoji.app/emoji-images/apple/${(_f2 = data.value) == null ? void 0 : _f2.c.toLowerCase()}.webp`,
            width: 144,
            height: 144
          },
          version: ((_g = data.value) == null ? void 0 : _g.v) || ""
        }
      ];
    });
    useSchemaOrg(schema);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-[680px] mx-auto my-8 px-4" }, _attrs))}>`);
      if (unref(error)) {
        _push(`<div class="text-rose-500 card p-6 mb-6 rounded-2xl">${ssrInterpolate(unref(error))} <button class="border border-rose-500 px-2 rounded-full" onclick="window.location.reload()">${ssrInterpolate(_ctx.$t("refresh"))}</button></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(data)) {
        _push(`<main><div class="flex justify-center items-center mx-auto"><h2 class="text-[128px]">${ssrInterpolate(unref(data).e)}</h2></div><div><h3 class="font-bold text-2xl color-title text-center">${ssrInterpolate(unref(data).t)}</h3><button class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "px-6 h-12 rounded-2xl bg-rose-500 text-white flex items-center mx-auto my-6 md:tooltip"])}"${ssrRenderAttr("data-tip", unref(copied) ? _ctx.$t("copied") : `${unref(isMac) ? "\u2318" : "Ctrl"} + C`)}><i class="${ssrRenderClass([[unref(copied) ? "icon-[material-symbols--check-circle] text-success" : "icon-[material-symbols--content-copy-outline]", unref(rtl) ? "ml-2" : "mr-2"], "text-xl"])}" aria-hidden="true" role="img"></i> ${ssrInterpolate(_ctx.$t("copyBtn"))}</button>`);
        if (unref(isAndroidQQ) && unref(locale) === "zh-hans") {
          _push(`<p class="text-center color-disable text-sm mb-4"> \u70B9\u51FB\u590D\u5236\u529F\u80FD\u5728\u5B89\u5353\u5FAE\u4FE1\u6216 QQ \u6D4F\u89C8\u5668\u4E2D\u53EF\u80FD\u4F1A\u5931\u6548\uFF0C\u5982\u679C\u4E0D\u80FD\u590D\u5236\uFF0C\u53EF\u4EE5\u957F\u6309\u4E0A\u9762\u7684 Emoji \u624B\u52A8\u590D\u5236\u3002\u6216\u8005\u70B9\u51FB\u53F3\u4E0A\u89D2\uFF0C\u5728\u6D4F\u89C8\u5668\u4E2D\u6253\u5F00\u4F7F\u7528\u672C\u7AD9\u3002 </p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex justify-between border-t border-b border-main py-2"])}"><span class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse ml-4" : "mr-4", "shrink-0"])}">${ssrInterpolate(_ctx.$t("unicodeName"))}</span> <span>${ssrInterpolate(unref(data).n)}</span></div><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex justify-between border-b border-main py-2"])}"><span class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse ml-4" : "mr-4", "shrink-0 my-0.5"])}">${ssrInterpolate(_ctx.$t("searchKeyword"))}</span><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex items-center flex-wrap justify-end"])}"><!--[-->`);
        ssrRenderList(unref(data).k, (k) => {
          _push(`<span class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse mr-1" : "ml-1", "card color-action rounded-xl px-2 my-0.5"])}">${ssrInterpolate(k)}</span>`);
        });
        _push(`<!--]--></div></div><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex justify-between border-b border-main py-2"])}"><span class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse ml-4" : "mr-4", "shrink-0"])}">${ssrInterpolate(_ctx.$t("version"))}</span> <span>${ssrInterpolate(unref(data).v)}</span></div><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex justify-between border-b border-main py-2"])}"><span class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse ml-4" : "mr-4", "shrink-0"])}">${ssrInterpolate(_ctx.$t("code"))}</span> <span>U+${ssrInterpolate(unref(data).c.replace(/ /g, " U+"))}</span></div><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex justify-between border-b border-main py-2"])}"><span class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse ml-4" : "mr-4", "shrink-0"])}">${ssrInterpolate(_ctx.$t("inGroup"))}</span><span class="text-right">${ssrInterpolate(unref(data).g)} &gt; ${ssrInterpolate(unref(data).s)}</span></div></div><div class="mt-6"><h4 class="${ssrRenderClass([unref(rtl) ? "text-right" : "", "font-bold color-action"])}">${ssrInterpolate(_ctx.$t("otherPlatform"))}</h4><div class="mt-6 flex justify-between md:block bg-white/90 dark:bg-zinc-800/90 border border-zinc-200/80 dark:border-zinc-700/80 p-4 md:p-0 md:bg-transparent md:dark:bg-transparent md:border-none rounded-2xl"><div class="md:flex md:border-t md:border-b md:border-main md:py-2"><!--[-->`);
        ssrRenderList(platform, (p) => {
          _push(`<div class="md:flex-1 md:text-center h-[72px] leading-[72px] md:h-auto md:leading-normal mb-2 md:mb-0">${ssrInterpolate(p.name)}</div>`);
        });
        _push(`<!--]--></div><div class="md:flex md:mt-2"><!--[-->`);
        ssrRenderList(platform, (p) => {
          _push(`<div class="mb-2 md:flex-1 md:flex md:justify-center md:tooltip"${ssrRenderAttr("data-tip", _ctx.$t("imgCopyTip"))}><img${ssrRenderAttr("src", `https://img.searchemoji.app/emoji-images/${p.imgPath}/${unref(data).c.toLowerCase()}.webp`)} width="72" height="72"${ssrRenderAttr("alt", _ctx.$t("platformImg", { name: unref(data).n, platform: p.name }))}></div>`);
        });
        _push(`<!--]--></div></div></div></main>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Detail.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<footer${ssrRenderAttrs(mergeProps({ class: "py-10 color-secondary text-center text-sm" }, _attrs))}><p class="flex items-center justify-center">Copyright \xA9 ${ssrInterpolate((/* @__PURE__ */ new Date()).getFullYear())} SearchEmoji</p><p class="mt-4">Emojis data comes from <a href="https://unicode.org/" target="_blank">Unicode</a></p></footer>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_8 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
const _imports_0 = "" + publicAssetsURL("logo.png");

export { _imports_0 as _, __nuxt_component_0 as a, __nuxt_component_1 as b, __nuxt_component_3 as c, _sfc_main$1 as d, __nuxt_component_8 as e, useColorMode as f, _export_sfc as g, useFetch as u };
//# sourceMappingURL=logo-LYGTYVwC.mjs.map
