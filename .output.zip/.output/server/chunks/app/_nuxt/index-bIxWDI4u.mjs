import { u as useFetch, _ as _imports_0, f as useColorMode, a as __nuxt_component_0, b as __nuxt_component_1, c as __nuxt_component_3, e as __nuxt_component_8, d as _sfc_main$1$1, g as _export_sfc } from './logo-LYGTYVwC.mjs';
import { useSSRContext, defineComponent, computed, ref, nextTick, watch, onUnmounted, unref, withCtx, createVNode, toDisplayString, createTextVNode, openBlock, createBlock, Fragment, renderList, withDirectives, isRef, vModelCheckbox, createCommentVNode, mergeProps } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderClass, ssrRenderList, ssrIncludeBooleanAttr, ssrLooseContain, ssrRenderStyle, ssrRenderAttrs, ssrRenderSlot, ssrGetDynamicModelProps } from 'vue/server-renderer';
import { watchDebounced, useStorageAsync, useThrottleFn, useClipboard, onClickOutside } from '@vueuse/core';
import { u as useRoute, a as useRouter, b as useI18n, e as useHead, f as useSwitchLocalePath, d as useLocalePath, g as useSchemaOrg, h as defineWebSite } from '../server.mjs';
import { onBeforeRouteLeave } from 'vue-router';
import { Document } from '@akryum/flexsearch-es';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'nitropack/dist/runtime/plugin';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import '../../index.mjs';
import '@unhead/shared';

const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "DropDown",
  __ssrInlineRender: true,
  props: {
    top: {
      type: Number,
      default: 32
    },
    left: {
      type: Number,
      default: void 0
    },
    right: {
      type: Number,
      default: void 0
    }
  },
  setup(__props) {
    const show = ref(false);
    const wrap = ref();
    onClickOutside(wrap, () => {
      show.value = false;
    });
    function closeDropDown() {
      show.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        ref_key: "wrap",
        ref: wrap,
        class: "relative"
      }, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", { active: unref(show) }, null, _push, _parent);
      _push(`<div style="${ssrRenderStyle([
        unref(show) ? null : { display: "none" },
        { top: `${__props.top}px`, left: __props.left !== void 0 ? `${__props.left}px` : void 0, right: __props.right !== void 0 ? `${__props.right}px` : void 0 }
      ])}" class="absolute">`);
      ssrRenderSlot(_ctx.$slots, "content", { close: closeDropDown }, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/DropDown.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<svg${ssrRenderAttrs(mergeProps({
    xmlns: "http://www.w3.org/2000/svg",
    height: "1em",
    viewBox: "0.00 0.00 321.00 39.00"
  }, _attrs))}><path fill="currentColor" d="
  M 181.70 10.80
  A 0.89 0.88 -35.4 0 0 182.73 10.97
  C 188.65 7.98 194.55 4.49 200.92 2.48
  C 211.51 -0.85 215.34 5.41 221.15 12.36
  Q 222.29 13.72 224.69 13.16
  C 231.98 11.47 238.84 8.17 246.13 6.26
  C 254.14 4.17 258.96 7.58 264.05 13.14
  A 1.40 1.39 54.0 0 0 265.76 13.42
  Q 272.50 9.66 279.54 6.30
  C 285.41 3.50 291.04 5.84 296.81 9.37
  Q 301.94 12.50 307.06 15.63
  C 310.68 17.83 313.17 18.73 317.00 17.19
  A 1.34 1.33 82.7 0 1 318.82 18.60
  C 318.44 21.45 313.30 25.08 310.76 25.99
  C 301.28 29.41 290.47 25.53 282.68 20.10
  A 2.41 2.40 -41.7 0 0 280.17 19.96
  C 276.26 22.07 272.19 25.58 268.79 27.09
  Q 257.77 31.99 250.50 20.79
  A 1.65 1.64 -27.2 0 0 248.52 20.16
  Q 242.50 22.52 236.26 25.57
  C 224.62 31.27 211.93 31.43 205.38 18.42
  A 1.36 1.36 0.0 0 0 203.46 17.87
  C 191.51 25.02 176.90 37.57 165.92 19.67
  Q 165.23 18.54 164.01 19.06
  Q 154.69 23.03 146.85 27.55
  C 137.76 32.81 130.65 29.41 124.98 21.59
  A 1.43 1.43 0.0 0 0 123.24 21.12
  Q 115.24 24.67 107.22 28.93
  C 98.59 33.51 88.33 30.40 86.18 20.19
  A 0.85 0.85 0.0 0 0 84.89 19.65
  C 72.98 27.18 61.46 37.24 48.84 22.95
  Q 47.09 20.96 45.70 18.85
  A 0.78 0.78 0.0 0 0 44.61 18.64
  C 38.66 22.70 33.63 28.15 28.05 32.73
  Q 18.24 40.78 10.18 31.33
  C 6.13 26.59 4.22 15.40 3.34 9.00
  C 2.80 5.07 5.66 2.74 9.35 4.63
  Q 11.37 5.66 12.76 9.77
  Q 15.05 16.57 18.38 23.32
  A 1.52 1.52 0.0 0 0 20.77 23.77
  C 27.30 17.89 33.00 11.59 41.02 7.02
  C 49.31 2.31 53.97 6.80 59.45 12.55
  C 62.41 15.65 65.90 14.27 68.93 12.45
  C 78.25 6.85 95.35 -4.75 101.19 12.97
  A 1.10 1.10 0.0 0 0 102.76 13.60
  Q 109.97 9.81 117.40 6.93
  C 127.10 3.16 132.73 3.95 139.56 11.72
  A 1.07 1.07 0.0 0 0 140.83 11.97
  C 148.54 8.09 157.14 3.94 165.77 2.97
  C 173.97 2.05 176.60 5.61 181.70 10.80
  Z"></path></svg>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Underline.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$3 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<span${ssrRenderAttrs(mergeProps({
    class: "flex items-center",
    role: "img"
  }, _attrs))}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="1.333334em" height="1.333334em" role="img" style="${ssrRenderStyle({ "margin-right": "0.3em" })}"><linearGradient id="logo-grad" x1="0" x2="1" y1="0" y2="1"><stop offset="0%" stop-color="#d946ef"></stop><stop offset="30%" stop-color="#d946ef"></stop><stop offset="100%" stop-color="#6366f1"></stop></linearGradient><path fill="url(#logo-grad)" d="M300 150l-.081 17.622-.243 10.335-.406 8.644-.567 7.684-.731 7.018-.892 6.516-1.055 6.108-1.216 5.762-1.38 5.46-1.542 5.19-1.704 4.942-1.868 4.714-2.031 4.499-2.195 4.294-2.359 4.099-2.525 3.909-2.689 3.724-2.858 3.546-3.026 3.369-3.197 3.197-3.369 3.026-3.546 2.858-3.724 2.69-3.91 2.524-4.097 2.36-4.295 2.194-4.499 2.031-4.714 1.868-4.942 1.704-5.19 1.541-5.46 1.38-5.762 1.217-6.108 1.055-6.516.892-7.018.73-7.684.567-8.644.407-10.335.243L150 300l-17.622-.081-10.336-.243-8.644-.406-7.682-.567-7.02-.731-6.515-.892-6.108-1.055-5.761-1.216-5.46-1.38-5.19-1.542-4.944-1.704-4.714-1.868-4.498-2.031-4.294-2.195-4.098-2.359-3.909-2.525-3.725-2.689-3.545-2.858-3.37-3.026-3.197-3.197-3.026-3.369-2.858-3.546-2.69-3.724-2.524-3.91-2.36-4.097-2.194-4.295-2.031-4.499-1.868-4.714-1.704-4.942-1.542-5.19-1.38-5.46-1.216-5.762-1.055-6.108-.892-6.516-.73-7.018L.73 186.6l-.406-8.644-.243-10.335L0 150l.081-17.622.243-10.336.406-8.644.568-7.682.73-7.02.892-6.515 1.055-6.108 1.217-5.761 1.379-5.46 1.542-5.19 1.704-4.944 1.868-4.714 2.031-4.498 2.195-4.294 2.359-4.098 2.524-3.909 2.69-3.725 2.858-3.545 3.026-3.37 3.197-3.197 3.37-3.026 3.545-2.858 3.725-2.69 3.909-2.524 4.098-2.36 4.294-2.194 4.498-2.031 4.714-1.868 4.944-1.704 5.19-1.542 5.46-1.38 5.761-1.216 6.108-1.055 6.515-.892 7.02-.73 7.682-.568 8.644-.406 10.336-.243L150 0l17.622.081 10.335.243 8.644.406 7.684.568 7.018.73 6.516.892 6.108 1.055 5.762 1.217 5.46 1.379 5.19 1.542 4.942 1.704 4.714 1.868 4.499 2.031 4.294 2.195 4.099 2.359 3.909 2.524 3.724 2.69 3.546 2.858 3.369 3.026 3.197 3.197 3.026 3.37 2.858 3.545 2.69 3.725 2.524 3.909 2.36 4.098 2.194 4.294 2.031 4.498 1.868 4.714 1.704 4.944 1.541 5.19 1.38 5.46 1.217 5.761 1.055 6.108.892 6.515.73 7.02.567 7.682.407 8.644.243 10.336z"></path><path fill="#fff" transform="translate(22 22)" d="M232 120v8a104 104 0 0 1-104.37 104c-54-.19-98-42.06-103.12-94.78a4 4 0 0 1 5.56-4A35.94 35.94 0 0 0 72 122.59a35.92 35.92 0 0 0 53.94 2.33a40.36 40.36 0 0 0 12.87 13A47.94 47.94 0 0 0 120 176a8 8 0 0 0 8.67 8a8.21 8.21 0 0 0 7.33-8.26A32 32 0 0 1 168 144a8 8 0 0 0 8-8.53a8.18 8.18 0 0 0-8.25-7.47H160a24 24 0 0 1-24-24V88h64a32 32 0 0 1 32 32Zm-187.27 0C55.57 119.6 64 110.37 64 99.52v-23C64 65.63 55.57 56.4 44.73 56A20 20 0 0 0 24 76v24a20 20 0 0 0 20.73 20Zm56 0c10.84-.39 19.27-9.62 19.27-20.47v-47c0-10.85-8.43-20.08-19.27-20.47A20 20 0 0 0 80 52v48a20 20 0 0 0 20.73 20ZM176 52a20 20 0 0 0-20.73-20c-10.84.4-19.27 9.63-19.27 20.48V72h36a4 4 0 0 0 4-4Z"></path></svg><svg width="3.393em" height="1em" viewBox="0 0 631 186" xmlns="http://www.w3.org/2000/svg" role="img"><path fill="currentColor" d="M105.4 50L23.8 185.8H0.4L33.8 130.4L11.8 50H35L51.6 122.8L41.6 122L81.8 50H105.4Z
          M141.272 144C133.005 144 125.739 142.333 119.472 139C113.339 135.667 108.539 130.867 105.072 124.6C101.605 118.333 99.8719 110.8 99.8719 102C99.8719 94.6667 101.205 87.7333 103.872 81.2C106.539 74.6667 110.272 68.9333 115.072 64C119.872 59.0667 125.539 55.2 132.072 52.4C138.739 49.4667 145.939 48 153.672 48C162.072 48 169.205 49.6 175.072 52.8C180.939 55.8667 185.405 60.4 188.472 66.4C191.672 72.4 193.272 79.7333 193.272 88.4C193.272 90.5333 193.072 92.8 192.672 95.2C192.272 97.6 191.739 99.5333 191.072 101H111.872V86.2H175.272L168.672 95.4C169.339 93.8 169.939 92.2 170.472 90.6C171.005 88.8667 171.272 87.2 171.272 85.6C171.272 81.2 170.539 77.4667 169.072 74.4C167.739 71.2 165.605 68.7333 162.672 67C159.872 65.2667 156.339 64.4 152.072 64.4C147.539 64.4 143.405 65.3333 139.672 67.2C136.072 68.9333 132.939 71.4 130.272 74.6C127.605 77.8 125.539 81.6 124.072 86C122.605 90.2667 121.739 94.8667 121.472 99.8C121.205 105 121.805 109.6 123.272 113.6C124.739 117.6 127.072 120.733 130.272 123C133.605 125.133 137.872 126.2 143.072 126.2C148.805 126.2 153.939 124.867 158.472 122.2C163.139 119.4 167.005 115.867 170.072 111.6L188.072 119.2C183.139 126.667 176.739 132.667 168.872 137.2C161.005 141.733 151.805 144 141.272 144Z
          M213.959 112C216.359 114.933 218.893 117.6 221.559 120C224.359 122.267 227.293 124.067 230.359 125.4C233.426 126.733 236.626 127.333 239.959 127.2C243.826 127.2 246.959 126.2 249.359 124.2C251.893 122.067 253.159 119.467 253.159 116.4C253.159 113.6 252.293 111.267 250.559 109.4C248.959 107.533 246.759 105.933 243.959 104.6C241.293 103.267 238.493 102 235.559 100.8C231.826 99.3333 228.159 97.5333 224.559 95.4C221.093 93.1333 218.226 90.3333 215.959 87C213.693 83.5333 212.626 79.2 212.759 74C212.893 68.1333 214.493 63.3333 217.559 59.6C220.759 55.7333 224.759 52.8667 229.559 51C234.493 49 239.693 48 245.159 48C252.493 48 259.026 49.6 264.759 52.8C270.626 55.8667 275.426 59.6667 279.159 64.2L267.159 76.6C264.226 73.1333 260.826 70.2667 256.959 68C253.226 65.6 249.226 64.4 244.959 64.4C241.359 64.4 238.426 65.2 236.159 66.8C234.026 68.4 232.959 70.4667 232.959 73C232.826 75.2667 233.493 77.2667 234.959 79C236.559 80.6 238.693 82 241.359 83.2C244.026 84.4 246.826 85.6667 249.759 87C254.293 88.8667 258.426 91 262.159 93.4C265.893 95.6667 268.826 98.5333 270.959 102C273.226 105.467 274.293 109.867 274.159 115.2C274.026 120.933 272.493 126.067 269.559 130.6C266.626 135 262.626 138.467 257.559 141C252.626 143.4 246.893 144.6 240.359 144.6C234.093 144.6 228.426 143.667 223.359 141.8C218.293 139.8 213.826 137.267 209.959 134.2C206.093 131 202.826 127.667 200.159 124.2L213.959 112Z
          M303.181 50H324.581L308.981 142H287.981L303.181 50Z
          M360.144 96C359.477 101.067 359.877 105.867 361.344 110.4C362.944 114.8 365.544 118.333 369.144 121C372.877 123.667 377.41 125.067 382.744 125.2C389.277 125.333 395.344 123.867 400.944 120.8C406.677 117.733 411.277 114.133 414.744 110L411.544 133.6C407.41 136.667 402.677 139.133 397.344 141C392.01 142.867 386.277 143.8 380.144 143.8C370.944 143.8 363.01 141.667 356.344 137.4C349.677 133.133 344.744 127.4 341.544 120.2C338.344 112.867 337.277 104.8 338.344 96C339.544 86.8 342.744 78.6 347.944 71.4C353.144 64.2 359.677 58.5333 367.544 54.4C375.544 50.1333 384.21 48 393.544 48C399.544 48 405.01 48.9333 409.944 50.8C415.01 52.5333 419.277 55.0667 422.744 58.4L419.544 82.2C417.277 77.4 413.744 73.6 408.944 70.8C404.277 68 398.944 66.6 392.944 66.6C387.477 66.6 382.344 67.9333 377.544 70.6C372.877 73.2667 369.01 76.8 365.944 81.2C363.01 85.6 361.077 90.5333 360.144 96Z
          M433.098 96C434.298 86.8 437.432 78.6 442.498 71.4C447.698 64.2 454.232 58.5333 462.098 54.4C470.098 50.1333 478.765 48 488.098 48C497.298 48 505.165 50.2 511.698 54.6C518.365 58.8667 523.298 64.6667 526.498 72C529.698 79.2 530.698 87.2 529.498 96C528.298 105.067 525.098 113.2 519.898 120.4C514.698 127.6 508.165 133.333 500.298 137.6C492.432 141.733 483.832 143.8 474.498 143.8C465.432 143.8 457.565 141.667 450.898 137.4C444.232 133.133 439.298 127.4 436.098 120.2C432.898 112.867 431.898 104.8 433.098 96Z
          M454.698 96C454.032 100.933 454.432 105.6 455.898 110C457.365 114.4 459.765 118 463.098 120.8C466.565 123.467 470.898 124.8 476.098 124.8C481.432 124.8 486.365 123.533 490.898 121C495.432 118.467 499.165 115 502.098 110.6C505.165 106.067 507.098 101.2 507.898 96C508.565 90.9333 508.165 86.2667 506.698 82C505.232 77.6 502.765 74 499.298 71.2C495.832 68.4 491.498 67 486.298 67C481.098 66.8667 476.232 68.1333 471.698 70.8C467.165 73.4667 463.365 77 460.298 81.4C457.365 85.8 455.498 90.6667 454.698 96Z
          M607.273 86C607.807 82.4 607.807 79.0667 607.273 76C606.74 72.8 605.473 70.2667 603.473 68.4C601.473 66.4 598.473 65.4 594.473 65.4C590.473 65.4 586.807 66.2667 583.473 68C580.273 69.7333 577.607 72.0667 575.473 75C573.34 77.9333 572.007 81.4 571.473 85.4L561.473 142H539.873L555.873 50H577.273L575.073 63.4C578.54 58.6 582.54 54.8667 587.073 52.2C591.74 49.4 597.207 48 603.473 48C610.54 48 616.073 49.6 620.073 52.8C624.207 56 627.007 60.3333 628.473 65.8C630.073 71.1333 630.407 77.0667 629.473 83.6L619.473 142H597.673L607.273 86Z
"></path><path fill="url(#logo-grad)" d="M306.781 13.4C306.781 9.66667 308.048 6.53333 310.581 3.99999C313.248 1.46666 316.448 0.19999 320.181 0.19999C323.915 0.19999 327.115 1.46666 329.781 3.99999C332.448 6.53333 333.781 9.66667 333.781 13.4C333.781 17 332.448 20.0667 329.781 22.6C327.115 25.1333 323.915 26.4 320.181 26.4C316.448 26.4 313.248 25.1333 310.581 22.6C308.048 20.0667 306.781 17 306.781 13.4Z"></path></svg></span>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Yesicon.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Toggle",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: Boolean,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const value = computed({
      get() {
        return props.modelValue;
      },
      set(value2) {
        emit("update:modelValue", value2);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<label${ssrRenderAttrs(mergeProps({ class: "relative inline-flex items-center cursor-default" }, _attrs))}><input${ssrIncludeBooleanAttr(Array.isArray(value.value) ? ssrLooseContain(value.value, null) : value.value) ? " checked" : ""} type="checkbox" class="sr-only peer"><span class="w-9 h-5 bg-zinc-200 peer-focus:outline-none rounded-full peer dark:bg-zinc-700 peer-checked:after:translate-x-full after:content-[&#39;&#39;] after:absolute after:top-0.5 after:left-[2px] after:bg-white dark:after:bg-zinc-300 after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-rose-500"></span></label>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Toggle.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Range",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: Number,
      default: 24
    },
    min: {
      type: Number,
      default: 0
    },
    max: {
      type: Number,
      default: 100
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const value = computed({
      get() {
        return props.modelValue;
      },
      set(value2) {
        emit("update:modelValue", Number(value2));
      }
    });
    const colorMode = useColorMode();
    const progress = computed(() => (value.value - props.min) / (props.max - props.min) * 100);
    const bgColor = ref("#d4d4d8");
    watch(
      () => colorMode.value,
      () => {
        bgColor.value = colorMode.value === "dark" ? "#3f3f46" : "#d4d4d8";
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      let _temp0;
      _push(`<input${ssrRenderAttrs((_temp0 = mergeProps({
        value: unref(value),
        class: "range",
        type: "range",
        min: __props.min,
        max: __props.max,
        style: {
          "--thumb-rotate": `${unref(value) / 48 * 2160}deg`,
          background: `linear-gradient(to right, #f43f5e ${unref(progress)}%, ${unref(bgColor)} ${unref(progress)}% 100%)`
        }
      }, _attrs), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(value)))))} data-v-1d1dd296>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Range.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_7 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-1d1dd296"]]);
const qualityMap = {
  "fully-qualified": "f",
  "minimally-qualified": "m",
  unqualified: "u",
  component: "c"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const { locale, locales } = useI18n();
    const rtl = computed(() => ["ar", "he"].includes(locale.value));
    const flexSearch = new Document({
      document: {
        id: "c",
        index: [
          // {
          //   field: 'e',
          //   tokenize: 'forward',
          //   resolution: 9
          // },
          {
            field: "n",
            tokenize: "forward",
            resolution: 9
          },
          ["zh-hans", "zh-hant", "ja", "ko"].includes(locale.value) ? {
            field: "t",
            tokenize: "forward",
            encode: (str) => str.replace(/[\x00-\x7F]/g, "").split(""),
            resolution: 9
          } : ["ar", "he"].includes(locale.value) ? {
            field: "t",
            encode: false,
            tokenize: "forward",
            // @ts-expect-error wtf
            rtl: true,
            split: /\s+/,
            resolution: 9
          } : {
            field: "t",
            tokenize: "forward",
            resolution: 9
          },
          // {
          //   field: 'k:en',
          //   tokenize: 'forward',
          //   resolution: 8
          // },
          ["zh-hans", "zh-hant", "ja", "ko"].includes(locale.value) ? {
            field: "k",
            tokenize: "forward",
            encode: (str) => str.replace(/[\x00-\x7F]/g, "").split(""),
            resolution: 8
          } : ["ar", "he"].includes(locale.value) ? {
            field: "k",
            encode: false,
            tokenize: "forward",
            // @ts-expect-error wtf
            rtl: true,
            split: /\s+/,
            resolution: 8
          } : {
            field: "k",
            tokenize: "forward",
            resolution: 8
          }
        ],
        store: true,
        worker: true
      }
    });
    const quality = ref(["fully-qualified"]);
    const transformQuality = computed(() => {
      return quality.value.map((q) => qualityMap[q]).join(",");
    });
    const skinTone = ref([]);
    const fullSkinTone = computed(() => skinTone.value.map((st) => `${st} skin tone`).join(","));
    useFetch("/api/emojis", {
      query: {
        locale: locale.value,
        quality: transformQuality,
        skinTone: fullSkinTone
      },
      server: false,
      onResponse({ response }) {
        for (const item of response._data) {
          flexSearch.add(item);
        }
        nextTick(() => {
          if (keyword.value) {
            search();
          }
        });
      }
    }, "$pqtWcjQkdb");
    const { data, error, pending } = useFetch("/api/home", {
      query: {
        locale: locale.value,
        quality: transformQuality,
        skinTone: fullSkinTone
      }
    }, "$cmRBlMwAGX");
    const keyword = ref(route.query.q || "");
    const searchResult = ref([]);
    const searching = ref(!!keyword.value);
    function search() {
      const result = flexSearch.search(keyword.value, { limit: 1e4, enrich: true });
      searchResult.value = result.map((item) => {
        return item.result.map((r) => r.doc);
      }).flat();
      searching.value = false;
      router.replace({ path: route.path, query: { q: keyword.value || void 0 } });
      useHead({
        title: keyword.value ? `\u{1F50D} ${keyword.value}` : ""
      });
    }
    watchDebounced(
      keyword,
      () => {
        search();
      },
      { debounce: 300, maxWait: 1e3 }
    );
    const loading = computed(() => searching.value || pending.value);
    const switchLocalePath = useSwitchLocalePath();
    const localePath = useLocalePath();
    const currentLocale = computed(() => {
      return locales.value.find((i) => i.code === locale.value);
    });
    const groupBySubGroup = useStorageAsync("groupBySubGroup", false);
    const qualityOptions = Object.keys(qualityMap);
    const skinToneOptions = [
      {
        name: "light",
        emoji: "\u{1F3FB}"
      },
      {
        name: "medium-light",
        emoji: "\u{1F3FC}"
      },
      {
        name: "medium",
        emoji: "\u{1F3FD}"
      },
      {
        name: "medium-dark",
        emoji: "\u{1F3FE}"
      },
      {
        name: "dark",
        emoji: "\u{1F3FF}"
      }
    ];
    const emojiCount = ref(0);
    const groupData = computed(() => {
      var _a;
      let list = ((_a = data.value) == null ? void 0 : _a.emojis) || [];
      if (keyword.value) {
        list = list.filter((emoji2) => {
          return !!searchResult.value.find((item) => item.c === emoji2.c);
        });
      }
      emojiCount.value = list.length;
      const group = [];
      list.forEach((d) => {
        var _a2, _b;
        const groupName = (_a2 = data.value) == null ? void 0 : _a2.groups[d.g];
        const subGroupName = (_b = data.value) == null ? void 0 : _b.groups[d.s];
        const item = {
          ...d,
          g: groupName.nt,
          s: subGroupName.nt
        };
        const inGroup = group.find((g) => g.name === groupName.n);
        if (!inGroup) {
          group.push({
            name: groupName.n,
            localeName: groupName.nt,
            hash: encodeURIComponent(groupName.n),
            icon: item.e,
            children: [
              {
                name: subGroupName.n,
                localeName: subGroupName.nt,
                data: [item]
              }
            ]
          });
        } else {
          if (groupBySubGroup.value) {
            const inSubGroup = inGroup.children.find((g) => g.name === subGroupName.n);
            if (!inSubGroup) {
              inGroup.children.push({
                name: subGroupName.n,
                localeName: subGroupName.nt,
                data: [item]
              });
            } else {
              inSubGroup.data.push(item);
            }
          } else {
            inGroup.children[0].data.push(item);
          }
        }
      });
      return group;
    });
    const emojiSize = useStorageAsync("emojiSize", 24);
    const renderEmojiSize = ref(24);
    watchDebounced(
      emojiSize,
      () => {
        renderEmojiSize.value = emojiSize.value;
      },
      { debounce: 400 }
    );
    const activeNav = ref("");
    function navClick(name) {
      var _a;
      if (name === ((_a = groupData.value[0]) == null ? void 0 : _a.name)) {
        router.replace({ path: route.path, query: route.query });
        (void 0).scrollTo({ top: 0, left: 0, behavior: "smooth" });
      }
    }
    const doms = ref([]);
    const horizontalScroller = ref();
    const isMobile = ref(false);
    watch(activeNav, () => {
      var _a, _b;
      if (isMobile.value) {
        const target = (void 0).getElementById(`nav-${activeNav.value.replace(/ /g, "-")}`);
        const left = target ? (((_a = horizontalScroller.value) == null ? void 0 : _a.scrollLeft) || 0) + target.getBoundingClientRect().left - 72 : 0;
        (_b = horizontalScroller.value) == null ? void 0 : _b.scrollTo({ left, top: 0, behavior: "smooth" });
      }
    });
    const y = ref(0);
    const handleScroll = useThrottleFn(() => {
      y.value = (void 0).documentElement.scrollTop;
      doms.value.forEach((tag) => {
        const top = tag == null ? void 0 : tag.getBoundingClientRect().top;
        const triggerScrollTop = isMobile.value ? 148 + 10 : 96 + 10;
        if (top <= triggerScrollTop) {
          activeNav.value = decodeURIComponent(tag.id);
        }
      });
    }, 20);
    const searchInputRef = ref();
    function handleKeydown(e) {
      var _a, _b;
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        (_a = searchInputRef.value) == null ? void 0 : _a.focus();
        (_b = searchInputRef.value) == null ? void 0 : _b.select();
      }
    }
    const isMac = ref(false);
    onUnmounted(() => {
      (void 0).removeEventListener("scroll", handleScroll);
      (void 0).removeEventListener("keydown", handleKeydown);
    });
    const clickTo = useStorageAsync("clickTo", "detail");
    const clickToOptions = ["detail", "copy"];
    function setClickTo(opt, close) {
      clickTo.value = opt;
      close();
    }
    const source = ref("");
    const { copy, copied } = useClipboard({ source, legacy: true });
    const showDetail = ref(false);
    const emoji = ref();
    onBeforeRouteLeave((to) => {
      var _a, _b, _c;
      if (to.name.startsWith("id__")) {
        const emojiId = to.params.id;
        const target = (_a = data.value) == null ? void 0 : _a.emojis.find((d) => d.c === emojiId);
        if (target) {
          const groupName = (_b = data.value) == null ? void 0 : _b.groups[target.g];
          const subGroupName = (_c = data.value) == null ? void 0 : _c.groups[target.s];
          emoji.value = {
            ...target,
            g: groupName.nt,
            s: subGroupName.nt
          };
        }
        showDetail.value = true;
        (void 0).history.pushState("detailPage", "", to.path);
        return false;
      } else {
        return true;
      }
    });
    const { t } = useI18n();
    useHead({
      title: t("seo.title")
    });
    const itemList = computed(() => {
      var _a, _b;
      return {
        "@type": "ItemList",
        name: "Emojis",
        sameAs: "https://en.wikipedia.org/wiki/Emoji",
        numberOfItems: ((_a = data.value) == null ? void 0 : _a.emojis.length) || 0,
        itemListElement: (((_b = data.value) == null ? void 0 : _b.emojis) || []).map((d, i) => ({
          "@type": "ListItem",
          url: localePath(`/${d.c}`),
          position: i
        }))
      };
    });
    useSchemaOrg([
      defineWebSite({
        // delete when nuxt-schema-org fix the bug
        // '@id': 'https://searchemoji.app/#website',
        // '@type': 'WebSite',
        // description: t('seo.title'),
        // inLanguage: locale.value,
        // name: 'SearchEmoji',
        // url: 'https://searchemoji.app',
        // publisher: {
        //   '@id': 'https://searchemoji.app/#identity'
        // },
        potentialAction: {
          "@type": "SearchAction",
          target: {
            "@type": "EntryPoint",
            urlTemplate: `https://searchemoji.app${localePath("/")}?q={search_term_string}`
          },
          "query-input": "required name=search_term_string"
        }
      }),
      // defineWebPage({
      //   '@id': `https://searchemoji.app${localePath('/')}/#webpage`,
      //   '@type': 'WebPage',
      //   description: t('seo.description'),
      //   name: t('seo.title'),
      //   url: `https://searchemoji.app${localePath('/')}`,
      //   about: {
      //     '@id': 'https://searchemoji.app/#identity'
      //   },
      //   isPartOf: {
      //     '@id': 'https://searchemoji.app/#website'
      //   }
      // }),
      itemList
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Logo = __nuxt_component_1;
      const _component_DropDown = _sfc_main$5;
      const _component_ToolBar = __nuxt_component_3;
      const _component_Underline = __nuxt_component_4;
      const _component_Yesicon = __nuxt_component_5;
      const _component_Toggle = _sfc_main$2;
      const _component_Range = __nuxt_component_7;
      const _component_Footer = __nuxt_component_8;
      const _component_Detail = _sfc_main$1$1;
      _push(`<!--[--><header class="flex justify-between items-start md:items-center h-24 px-4 md:h-20 md:px-6 z-[11] sticky top-0 bg-zinc-50/80 md:shadow-sm dark:bg-zinc-900/80 backdrop-blur-md border-b-0 md:border-b border-zinc-200/80 dark:border-zinc-800/80"><div class="flex items-center md:items-center flex-wrap w-full md:w-auto">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "flex items-center h-14 md:h-20 w-[168px] md:w-[256px]",
        to: unref(localePath)("/"),
        title: "SearchEmoji"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} class="w-9 h-9 mr-2 md:w-11 md:h-11 md:mr-3" alt="SearchEmoji"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Logo, { class: "text-lg md:text-2xl color-title mt-0.5" }, null, _parent2, _scopeId));
            _push2(`<h1 class="w-0 h-0 overflow-hidden"${_scopeId}>${ssrInterpolate(_ctx.$t("logoTips"))}</h1>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                class: "w-9 h-9 mr-2 md:w-11 md:h-11 md:mr-3",
                alt: "SearchEmoji"
              }),
              createVNode(_component_Logo, { class: "text-lg md:text-2xl color-title mt-0.5" }),
              createVNode("h1", { class: "w-0 h-0 overflow-hidden" }, toDisplayString(_ctx.$t("logoTips")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="items-center card rounded-2xl w-full md:w-[360px] lg:w-[420px] xl:w-[560px] h-9 md:h-10 flex flex-grow">`);
      _push(ssrRenderComponent(_component_DropDown, {
        class: ["flex items-center relative border-r border-zinc-200/80 dark:border-zinc-700/80 cursor-default shrink-0", unref(rtl) ? "flex-row-reverse pr-2 pl-2" : "pl-4"],
        top: 30,
        left: 0
      }, {
        default: withCtx(({ active }, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<i class="${ssrRenderClass([unref(rtl) ? "ml-1" : "mr-1", "icon-[ph--translate-bold] text-xl color-action shrink-0"])}" role="img" aria-hidden="true"${_scopeId}></i><span class="color-action shrink-0 select-none"${_scopeId}>${ssrInterpolate((_a = unref(currentLocale)) == null ? void 0 : _a.name)}</span><i role="img" class="${ssrRenderClass([{ "rotate-180": active }, "icon-[material-symbols--arrow-drop-down-rounded] text-2xl color-action transition-all shrink-0"])}" aria-hidden="true"${_scopeId}></i>`);
          } else {
            return [
              createVNode("i", {
                class: ["icon-[ph--translate-bold] text-xl color-action shrink-0", unref(rtl) ? "ml-1" : "mr-1"],
                role: "img",
                "aria-hidden": "true"
              }, null, 2),
              createVNode("span", { class: "color-action shrink-0 select-none" }, toDisplayString((_b = unref(currentLocale)) == null ? void 0 : _b.name), 1),
              createVNode("i", {
                class: ["icon-[material-symbols--arrow-drop-down-rounded] text-2xl color-action transition-all shrink-0", { "rotate-180": active }],
                role: "img",
                "aria-hidden": "true"
              }, null, 2)
            ];
          }
        }),
        content: withCtx(({ close }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="card w-[264px] p-2 rounded-2xl flex flex-wrap"${_scopeId}><!--[-->`);
            ssrRenderList(unref(locales), (l) => {
              _push2(ssrRenderComponent(_component_NuxtLink, {
                key: l.code,
                to: unref(switchLocalePath)(l.code),
                class: ["h-8 px-2 rounded-xl w-[122px] line-clamp-1 break-all leading-8", l.code === unref(locale) ? "color-disable cursor-default" : "hover:bg-zinc-100 dark:hover:bg-zinc-700 hover:color-action"],
                onClick: ($event) => close()
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(l.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(l.name), 1)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]--></div>`);
          } else {
            return [
              createVNode("div", { class: "card w-[264px] p-2 rounded-2xl flex flex-wrap" }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(locales), (l) => {
                  return openBlock(), createBlock(_component_NuxtLink, {
                    key: l.code,
                    to: unref(switchLocalePath)(l.code),
                    class: ["h-8 px-2 rounded-xl w-[122px] line-clamp-1 break-all leading-8", l.code === unref(locale) ? "color-disable cursor-default" : "hover:bg-zinc-100 dark:hover:bg-zinc-700 hover:color-action"],
                    onClick: ($event) => close()
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(l.name), 1)
                    ]),
                    _: 2
                  }, 1032, ["to", "class", "onClick"]);
                }), 128))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<input${ssrRenderAttr("value", unref(keyword))} type="search" enterkeyhint="search" class="${ssrRenderClass([unref(rtl) ? "text-right" : "", "bg-transparent flex-grow outline-none px-2 color-title min-w-0"])}"${ssrRenderAttr("placeholder", `${_ctx.$t("placeholder")}${unref(isMobile) ? "" : "(" + (unref(isMac) ? "\u2318" : "Ctrl") + "+ K)"}`)}><button class="bg-zinc-200/80 dark:bg-zinc-700/80 h-full w-12 rounded-r-2xl flex justify-center items-center" aria-label="Search"><i class="icon-[solar--magnifer-linear] text-lg md:text-2xl color-secondary shrink-0" role="img" aria-hidden="true"></i></button></div><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "items-center ml-6 hidden lg:flex"])}">${ssrInterpolate(_ctx.$t("clickTo"))} `);
      _push(ssrRenderComponent(_component_DropDown, {
        class: ["flex items-center color-action relative cursor-default select-none", unref(rtl) ? "flex-row-reverse mr-2" : "ml-2"],
        top: 24
      }, {
        default: withCtx(({ active }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(_ctx.$t(unref(clickTo)))} <i class="${ssrRenderClass([{ "rotate-180": active }, "icon-[material-symbols--arrow-drop-down-rounded] text-2xl transition-all"])}" role="img" aria-hidden="true"${_scopeId}></i>`);
          } else {
            return [
              createTextVNode(toDisplayString(_ctx.$t(unref(clickTo))) + " ", 1),
              createVNode("i", {
                class: ["icon-[material-symbols--arrow-drop-down-rounded] text-2xl transition-all", { "rotate-180": active }],
                role: "img",
                "aria-hidden": "true"
              }, null, 2)
            ];
          }
        }),
        content: withCtx(({ close }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<ul class="card px-4 py-2 rounded-2xl"${_scopeId}><!--[-->`);
            ssrRenderList(clickToOptions, (opt) => {
              _push2(`<li class="${ssrRenderClass([unref(clickTo) === opt ? "color-secondary" : "hover:text-rose-500", "py-2 whitespace-nowrap cursor-pointer"])}"${_scopeId}>${ssrInterpolate(_ctx.$t(opt))}</li>`);
            });
            _push2(`<!--]--></ul>`);
          } else {
            return [
              createVNode("ul", { class: "card px-4 py-2 rounded-2xl" }, [
                (openBlock(), createBlock(Fragment, null, renderList(clickToOptions, (opt) => {
                  return createVNode("li", {
                    key: opt,
                    class: ["py-2 whitespace-nowrap cursor-pointer", unref(clickTo) === opt ? "color-secondary" : "hover:text-rose-500"],
                    onClick: ($event) => setClickTo(opt, close)
                  }, toDisplayString(_ctx.$t(opt)), 11, ["onClick"]);
                }), 64))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_ToolBar, { class: "absolute right-4 top-0 h-14 md:static" }, null, _parent));
      _push(`</header><aside class="flex-shrink-0 sticky md:fixed md:pr-3 md:w-[268px] top-24 md:top-20 left-0 bottom-0 overflow-auto z-10 bg-zinc-50/80 dark:bg-zinc-900/80 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800/80 md:bg-transparent md:dark:bg-transparent md:backdrop-blur-none md:border-b-0"><div class="h-[72px] hidden md:flex items-center pl-6">`);
      _push(ssrRenderComponent(_component_DropDown, {
        class: "w-full z-10 select-none",
        top: 39,
        left: 0,
        right: 0
      }, {
        default: withCtx(({ active }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="${ssrRenderClass([[active ? "rounded-b-none border-b-transparent" : "rounded-b-2xl", unref(rtl) ? "flex-row-reverse pl-2 pr-4" : "pl-4 pr-2"], "flex items-center justify-between h-10 card rounded-t-2xl cursor-default"])}"${_scopeId}><span${_scopeId}>${ssrInterpolate(_ctx.$t("qualified"))}</span><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex items-center"])}"${_scopeId}><div class="text-sm color-secondary shrink-0"${_scopeId}>${ssrInterpolate(unref(quality).length)} / 4</div><i class="${ssrRenderClass([{ "rotate-180": active }, "icon-[material-symbols--arrow-drop-down-rounded] text-2xl color-secondary transition-all shrink-0"])}" role="img" aria-hidden="true"${_scopeId}></i></div></div>`);
          } else {
            return [
              createVNode("div", {
                class: ["flex items-center justify-between h-10 card rounded-t-2xl cursor-default", [active ? "rounded-b-none border-b-transparent" : "rounded-b-2xl", unref(rtl) ? "flex-row-reverse pl-2 pr-4" : "pl-4 pr-2"]]
              }, [
                createVNode("span", null, toDisplayString(_ctx.$t("qualified")), 1),
                createVNode("div", {
                  class: ["flex items-center", unref(rtl) ? "flex-row-reverse" : ""]
                }, [
                  createVNode("div", { class: "text-sm color-secondary shrink-0" }, toDisplayString(unref(quality).length) + " / 4", 1),
                  createVNode("i", {
                    class: ["icon-[material-symbols--arrow-drop-down-rounded] text-2xl color-secondary transition-all shrink-0", { "rotate-180": active }],
                    role: "img",
                    "aria-hidden": "true"
                  }, null, 2)
                ], 2)
              ], 2)
            ];
          }
        }),
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<ul class="card p-4 rounded-b-2xl w-full border-t-0"${_scopeId}><!--[-->`);
            ssrRenderList(unref(qualityOptions), (q) => {
              _push2(`<li class="h-7 whitespace-nowrap"${_scopeId}><label class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex items-center color-action"])}"${_scopeId}><input${ssrIncludeBooleanAttr(Array.isArray(unref(quality)) ? ssrLooseContain(unref(quality), q) : unref(quality)) ? " checked" : ""} type="checkbox"${ssrRenderAttr("value", q)} class="${ssrRenderClass(unref(rtl) ? "ml-2" : "mr-2")}"${_scopeId}> ${ssrInterpolate(_ctx.$t(q))}</label></li>`);
            });
            _push2(`<!--]--></ul>`);
          } else {
            return [
              createVNode("ul", { class: "card p-4 rounded-b-2xl w-full border-t-0" }, [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(qualityOptions), (q) => {
                  return openBlock(), createBlock("li", {
                    key: q,
                    class: "h-7 whitespace-nowrap"
                  }, [
                    createVNode("label", {
                      class: ["flex items-center color-action", unref(rtl) ? "flex-row-reverse" : ""]
                    }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => isRef(quality) ? quality.value = $event : null,
                        type: "checkbox",
                        value: q,
                        class: unref(rtl) ? "ml-2" : "mr-2"
                      }, null, 10, ["onUpdate:modelValue", "value"]), [
                        [vModelCheckbox, unref(quality)]
                      ]),
                      createTextVNode(" " + toDisplayString(_ctx.$t(q)), 1)
                    ], 2)
                  ]);
                }), 128))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><nav class="px-4 md:pl-6 flex md:block w-auto"><!--[-->`);
      ssrRenderList(unref(groupData), (g, i) => {
        _push(ssrRenderComponent(_component_NuxtLink, {
          id: `nav-${g.name.replace(/ /g, "-")}`,
          key: g.name,
          to: { path: unref(route).path, query: unref(route).query, hash: i === 0 ? "" : `#${g.hash}` },
          replace: "",
          class: ["flex items-center h-10 pr-4 md:pr-0 md:mb-2 relative cursor-pointer", [unref(activeNav) === g.name ? "text-rose-500 font-bold" : "md:hover:color-action", unref(rtl) ? "flex-row-reverse" : ""]],
          onClick: ($event) => navClick(g.name)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="${ssrRenderClass([unref(rtl) ? "ml-2" : "mr-2", "hidden text-2xl w-8 md:inline-block text-center"])}"${_scopeId}>${ssrInterpolate(g.icon)}</span><span class="whitespace-nowrap"${_scopeId}>${ssrInterpolate(g.localeName)}</span>`);
              if (unref(activeNav) === g.name) {
                _push2(ssrRenderComponent(_component_Underline, {
                  class: ["absolute bottom-0 text-[8px] md:text-xs text-rose-500", unref(rtl) ? "right-4 md:right-10" : "left-0 md:left-10"]
                }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                createVNode("span", {
                  class: ["hidden text-2xl w-8 md:inline-block text-center", unref(rtl) ? "ml-2" : "mr-2"]
                }, toDisplayString(g.icon), 3),
                createVNode("span", { class: "whitespace-nowrap" }, toDisplayString(g.localeName), 1),
                unref(activeNav) === g.name ? (openBlock(), createBlock(_component_Underline, {
                  key: 0,
                  class: ["absolute bottom-0 text-[8px] md:text-xs text-rose-500", unref(rtl) ? "right-4 md:right-10" : "left-0 md:left-10"]
                }, null, 8, ["class"])) : createCommentVNode("", true)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></nav><a href="https://yesicon.app" target="_blank" class="no-icon hidden md:block ml-6 mt-6 mb-6 card p-4 rounded-2xl opacity-30 hover:opacity-100 transition-all"><div class="flex justify-between items-center">`);
      _push(ssrRenderComponent(_component_Yesicon, { class: "color-action text-2xl" }, null, _parent));
      _push(`<span class="text-xl">\u{1F448}</span></div><p class="mt-3 text-sm">${ssrInterpolate(_ctx.$t("yesicon"))}</p></a></aside><main class="mx-4 md:ml-[280px] md:mr-6"><div class="flex items-center md:justify-between h-11 md:h-[72px]"><div class="flex items-center flex-grow justify-between md:justify-start"><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex items-center"])}"><span class="mr-1">${ssrInterpolate(_ctx.$t("skinTone"))}</span><!--[-->`);
      ssrRenderList(skinToneOptions, (st) => {
        _push(`<div class="${ssrRenderClass([unref(skinTone).includes(st.name) ? "border-rose-500" : "border-transparent", "border border-1 cursor-default flex justify-center items-center mr-1 w-5 h-5 md:tooltip relative"])}"${ssrRenderAttr("data-tip", _ctx.$t(st.name))}>${ssrInterpolate(st.emoji)} `);
        if (unref(skinTone).includes(st.name)) {
          _push(`<span class="absolute left-0 top-0 w-full h-full flex justify-center items-center text-rose-500"><i class="icon-[carbon--checkmark]" role="img" aria-hidden="true"></i></span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div><div class="ml-4">${ssrInterpolate(unref(emojiCount))} ${ssrInterpolate(_ctx.$t("emojis"))}</div></div><div class="md:flex items-center hidden"><div class="${ssrRenderClass([unref(rtl) ? "flex-row-reverse" : "", "flex items-center"])}">${ssrInterpolate(_ctx.$t("group"))} `);
      _push(ssrRenderComponent(_component_Toggle, {
        modelValue: unref(groupBySubGroup),
        "onUpdate:modelValue": ($event) => isRef(groupBySubGroup) ? groupBySubGroup.value = $event : null,
        class: unref(rtl) ? "flex-row-reverse mr-1" : "ml-1"
      }, null, _parent));
      _push(`</div><div class="items-center hidden lg:flex ml-6"><span class="shrink-0 mr-4">${ssrInterpolate(_ctx.$t("size"))} ${ssrInterpolate(unref(emojiSize))}</span>`);
      _push(ssrRenderComponent(_component_Range, {
        modelValue: unref(emojiSize),
        "onUpdate:modelValue": ($event) => isRef(emojiSize) ? emojiSize.value = $event : null,
        min: 16,
        max: 48
      }, null, _parent));
      _push(`</div></div></div>`);
      if (!unref(loading) && unref(error)) {
        _push(`<div class="text-rose-500 card p-6 mb-6 rounded-2xl">${ssrInterpolate(unref(error))} <button class="border border-rose-500 px-2 rounded-full" onclick="window.location.reload()">${ssrInterpolate(_ctx.$t("refresh"))}</button></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(loading)) {
        _push(`<div class="flex justify-center items-center h-24"><i class="icon-[svg-spinners--ring-resize] text-lg" role="img" aria-hidden="true"></i></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(loading) && !unref(error) && !unref(groupData).length) {
        _push(`<div class="card p-6 rounded-2xl">\u26A0\uFE0F ${ssrInterpolate(_ctx.$t("noResults", { keyword: unref(keyword) }))}</div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(loading)) {
        _push(`<!--[-->`);
        ssrRenderList(unref(groupData), (g, i) => {
          _push(`<div${ssrRenderAttr("id", g.hash)} class="card no-backdrop p-2 md:p-4 mb-6 rounded-2xl"><!--[-->`);
          ssrRenderList(g.children, (sg) => {
            _push(`<div>`);
            if (unref(groupBySubGroup)) {
              _push(`<h3 class="pl-2 mb-2 mt-4">${ssrInterpolate(sg.localeName)}</h3>`);
            } else {
              _push(`<!---->`);
            }
            _push(`<div class="grid flex-wrap gap-1 emoji-box" style="${ssrRenderStyle([{ "grid-template-columns": "repeat(auto-fill, minmax(72px, 1fr))" }, { fontSize: `${unref(renderEmojiSize)}px` }])}">`);
            if (unref(clickTo) === "detail") {
              _push(`<!--[-->`);
              ssrRenderList(sg.data, (d) => {
                _push(ssrRenderComponent(_component_NuxtLink, {
                  key: d.e,
                  to: unref(localePath)(`/${d.c}`)
                }, {
                  default: withCtx((_, _push2, _parent2, _scopeId) => {
                    if (_push2) {
                      _push2(`<h4${_scopeId}>${ssrInterpolate(d.e)}</h4><p${_scopeId}>${ssrInterpolate(d.t)}</p>`);
                    } else {
                      return [
                        createVNode("h4", null, toDisplayString(d.e), 1),
                        createVNode("p", null, toDisplayString(d.t), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent));
              });
              _push(`<!--]-->`);
            } else {
              _push(`<!---->`);
            }
            if (unref(clickTo) === "copy") {
              _push(`<!--[-->`);
              ssrRenderList(sg.data, (d) => {
                _push(`<a href="javascript:;"><h4>${ssrInterpolate(d.e)}</h4><p>${ssrInterpolate(_ctx.$t("clickToCopy") + d.t)}</p>`);
                if (unref(source) === d.e && unref(copied)) {
                  _push(`<div class="absolute left-0 top-0 w-full h-full rounded-2xl bg-black/50 flex justify-center items-center"><i class="icon-[material-symbols--check-circle] text-xl text-green-500" aria-hidden="true" role="img"></i></div>`);
                } else {
                  _push(`<!---->`);
                }
                _push(`</a>`);
              });
              _push(`<!--]-->`);
            } else {
              _push(`<!---->`);
            }
            _push(`</div></div>`);
          });
          _push(`<!--]--></div>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</main>`);
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`<div style="${ssrRenderStyle(unref(y) > 400 ? null : { display: "none" })}" class="cursor-pointer !fixed right-4 bottom-4 card w-12 h-12 rounded-2xl flex justify-center items-center shadow-2xl md:tooltip"${ssrRenderAttr("data-tip", _ctx.$t("backTop"))}><i class="icon-[material-symbols--rocket] text-rose-500 text-2xl" role="img" aria-hidden="true"></i></div>`);
      if (unref(showDetail)) {
        _push(`<div class="fixed z-20 top-0 left-0 w-full h-full bg-black/50 dark:bg-black/80 backdrop-blur-sm flex"><div class="inner bg-body h-[90vh] !h-[90dvh] w-[100vw] md:w-[760px] rounded-t-3xl shadow-2xl absolute bottom-0 left-0 md:left-1/2 md:-ml-[380px]"><a href="javascript:;" class="absolute z-20 card top-4 right-4 md:top-6 md:right-6 w-8 h-8 rounded-xl text-2xl flex justify-center items-center hover:bg-rose-500 hover:border-rose-500 hover:text-white"><i class="icon-[material-symbols--close]" role="img" aria-hidden="true"></i></a><div class="h-full overflow-y-auto overscroll-contain">`);
        _push(ssrRenderComponent(_component_Detail, { emoji: unref(emoji) }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-bIxWDI4u.mjs.map
