const i18n_config = () => ({
  legacy: false,
  locale: "en",
  fallbackLocale: "en",
  globalInjection: true
});

export { i18n_config as default };
//# sourceMappingURL=i18n.config-XEhn4iF_.mjs.map
