import { _ as _imports_0, a as __nuxt_component_0, b as __nuxt_component_1, c as __nuxt_component_3, d as _sfc_main$1, e as __nuxt_component_8 } from './logo-LYGTYVwC.mjs';
import { u as useRoute, a as useRouter, b as useI18n, d as useLocalePath } from '../server.mjs';
import { defineComponent, computed, ref, onUnmounted, withCtx, createVNode, unref, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'nitropack/dist/runtime/plugin';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import '../../index.mjs';
import '@unhead/shared';
import '@vueuse/core';
import 'vue-router';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    const { locale } = useI18n();
    useLocalePath();
    const rtl = computed(() => ["ar", "he"].includes(locale.value));
    const keyword = ref(route.query.q || "");
    const isMobile = ref(false);
    const isMac = ref(false);
    onUnmounted(() => {
      (void 0).removeEventListener("keydown", handleKeydown);
    });
    const searchInputRef = ref();
    function handleKeydown(e) {
      var _a, _b;
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        (_a = searchInputRef.value) == null ? void 0 : _a.focus();
        (_b = searchInputRef.value) == null ? void 0 : _b.select();
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Logo = __nuxt_component_1;
      const _component_ToolBar = __nuxt_component_3;
      const _component_Detail = _sfc_main$1;
      const _component_Footer = __nuxt_component_8;
      _push(`<!--[--><header class="h-20 px-6 z-10 sticky top-0 bg-zinc-50/80 dark:bg-zinc-900/80 backdrop-blur-md border-b border-zinc-200/80 dark:border-zinc-800/80"><div class="flex justify-between items-center h-full max-w-[680px] mx-auto">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "flex items-center w-[256px]",
        to: "/",
        title: "SearchEmoji"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} class="w-11 h-11 mr-3" alt="SearchEmoji"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Logo, { class: "text-2xl color-title mt-0.5" }, null, _parent2, _scopeId));
            _push2(`<h1 class="w-0 h-0 overflow-hidden"${_scopeId}>Search for Emoji, Click to Copy</h1>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                class: "w-11 h-11 mr-3",
                alt: "SearchEmoji"
              }),
              createVNode(_component_Logo, { class: "text-2xl color-title mt-0.5" }),
              createVNode("h1", { class: "w-0 h-0 overflow-hidden" }, "Search for Emoji, Click to Copy")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_ToolBar, null, null, _parent));
      _push(`</div></header><div class="items-center card rounded-2xl max-w-[680px] mt-6 mx-4 md:mx-auto h-9 md:h-10 flex flex-grow"><input${ssrRenderAttr("value", unref(keyword))} type="search" enterkeyhint="search" class="${ssrRenderClass([unref(rtl) ? "text-right" : "", "bg-transparent flex-grow outline-none px-3 color-title min-w-0"])}"${ssrRenderAttr("placeholder", `${_ctx.$t("placeholder")}${unref(isMobile) ? "" : "(" + (unref(isMac) ? "\u2318" : "Ctrl") + "+ K)"}`)}><button class="bg-zinc-200/80 dark:bg-zinc-700/80 h-full w-12 rounded-r-2xl flex justify-center items-center" aria-label="Search"><i class="icon-[solar--magnifer-linear] text-lg md:text-2xl color-secondary shrink-0" role="img" aria-hidden="true"></i></button></div>`);
      _push(ssrRenderComponent(_component_Detail, null, null, _parent));
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-xxKRvCPl.mjs.map
