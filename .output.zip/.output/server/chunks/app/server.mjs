import { hasInjectionContext, getCurrentInstance, version, ref, watchEffect, watch, inject, toRef, isRef, defineComponent, h, onUnmounted, provide, shallowReactive, Suspense, nextTick, Transition, useSSRContext, unref, computed, Fragment, createApp, effectScope, reactive, defineAsyncComponent, onErrorCaptured, onServerPrefetch, createVNode, resolveDynamicComponent, shallowRef, isReadonly, toValue, Text, isShallow, isReactive, toRaw, mergeProps } from 'vue';
import { i as useRuntimeConfig$1, $ as $fetch, c as createError$1, P as defu, Q as sanitizeStatusCode, O as createHooks, R as getRequestURL, B as toRouteMatcher, C as createRouter$1, S as getRequestHeaders, T as klona, U as parse$1, V as getRequestHeader, q as destr, W as isEqual$1, X as setCookie, Y as getCookie, Z as deleteCookie } from '../nitro/node-server.mjs';
import { g as getActiveHead } from '../index.mjs';
import { RouterView, useRouter as useRouter$1, useRoute as useRoute$1, createMemoryHistory, createRouter, START_LOCATION } from 'vue-router';
import { ssrRenderComponent, ssrRenderSuspense, ssrRenderVNode, ssrRenderAttrs, ssrInterpolate } from 'vue/server-renderer';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'nitropack/dist/runtime/plugin';
import 'node:fs';
import 'node:url';
import '@unhead/shared';

function createContext$1(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als && currentInstance === void 0) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers$1.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers$1.delete(onLeave);
      }
    }
  };
}
function createNamespace$1(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext$1({ ...defaultOpts, ...opts });
      }
      contexts[key];
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey$2 = "__unctx__";
const defaultNamespace = _globalThis[globalKey$2] || (_globalThis[globalKey$2] = createNamespace$1());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey$1 = "__unctx_async_handlers__";
const asyncHandlers$1 = _globalThis[asyncHandlersKey$1] || (_globalThis[asyncHandlersKey$1] = /* @__PURE__ */ new Set());

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const EQUAL_RE = /=/g;
const PLUS_RE$1 = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE$1, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodeQueryKey$1(text) {
  return decode$1(text.replace(PLUS_RE$1, " "));
}
function decodeQueryValue$1(text) {
  return decode$1(text.replace(PLUS_RE$1, " "));
}
function parseQuery$1(parametersString = "") {
  const object = {};
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey$1(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue$1(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map((_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k2) => query[k2] !== void 0).map((k2) => encodeQueryItem(k2, query[k2])).filter(Boolean).join("&");
}
const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
const TRAILING_SLASH_RE$1 = /\/$|\/\?|\/#/;
function hasTrailingSlash$1(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE$1.test(input);
}
function withoutTrailingSlash$1(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash$1(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash$1(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  return (s0.slice(0, -1) || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash$1(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash$1(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash$1(base);
  if (input.startsWith(_base)) {
    return input;
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash$1(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery$1(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash$1(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function isEqual(a, b, options2 = {}) {
  if (!options2.trailingSlash) {
    a = withTrailingSlash$1(a);
    b = withTrailingSlash$1(b);
  }
  if (!options2.leadingSlash) {
    a = withLeadingSlash(a);
    b = withLeadingSlash(b);
  }
  if (!options2.encoding) {
    a = decode$1(a);
    b = decode$1(b);
  }
  return a === b;
}
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return defaultProto ? parseURL(defaultProto + input) : parsePath$1(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  const [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  const { pathname, search, hash: hash2 } = parsePath$1(
    path.replace(/\/(?=[A-Za-z]:)/, "")
  );
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash: hash2
  };
}
function parsePath$1(input = "") {
  const [pathname = "", search = "", hash2 = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash: hash2
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash2 = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol ? parsed.protocol + "//" : "";
  return proto + auth + host + pathname + search + hash2;
}
const appConfig = useRuntimeConfig$1().app;
const baseURL = () => appConfig.baseURL;
if (!globalThis.$fetch) {
  globalThis.$fetch = $fetch.create({
    baseURL: baseURL()
  });
}
const nuxtAppCtx = /* @__PURE__ */ getContext("nuxt-app", {
  asyncContext: false
});
const NuxtPluginIndicator = "__nuxt_plugin";
function createNuxtApp(options2) {
  let hydratingCount = 0;
  const nuxtApp = {
    _scope: effectScope(),
    provide: void 0,
    globalName: "nuxt",
    versions: {
      get nuxt() {
        return "3.9.1";
      },
      get vue() {
        return nuxtApp.vueApp.version;
      }
    },
    payload: reactive({
      data: {},
      state: {},
      once: /* @__PURE__ */ new Set(),
      _errors: {},
      ...{ serverRendered: true }
    }),
    static: {
      data: {}
    },
    runWithContext: (fn) => nuxtApp._scope.run(() => callWithNuxt(nuxtApp, fn)),
    isHydrating: false,
    deferHydration() {
      if (!nuxtApp.isHydrating) {
        return () => {
        };
      }
      hydratingCount++;
      let called = false;
      return () => {
        if (called) {
          return;
        }
        called = true;
        hydratingCount--;
        if (hydratingCount === 0) {
          nuxtApp.isHydrating = false;
          return nuxtApp.callHook("app:suspense:resolve");
        }
      };
    },
    _asyncDataPromises: {},
    _asyncData: {},
    _payloadRevivers: {},
    ...options2
  };
  nuxtApp.hooks = createHooks();
  nuxtApp.hook = nuxtApp.hooks.hook;
  {
    const contextCaller = async function(hooks, args) {
      for (const hook of hooks) {
        await nuxtApp.runWithContext(() => hook(...args));
      }
    };
    nuxtApp.hooks.callHook = (name, ...args) => nuxtApp.hooks.callHookWith(contextCaller, name, ...args);
  }
  nuxtApp.callHook = nuxtApp.hooks.callHook;
  nuxtApp.provide = (name, value) => {
    const $name = "$" + name;
    defineGetter$1(nuxtApp, $name, value);
    defineGetter$1(nuxtApp.vueApp.config.globalProperties, $name, value);
  };
  defineGetter$1(nuxtApp.vueApp, "$nuxt", nuxtApp);
  defineGetter$1(nuxtApp.vueApp.config.globalProperties, "$nuxt", nuxtApp);
  {
    if (nuxtApp.ssrContext) {
      nuxtApp.ssrContext.nuxt = nuxtApp;
      nuxtApp.ssrContext._payloadReducers = {};
      nuxtApp.payload.path = nuxtApp.ssrContext.url;
    }
    nuxtApp.ssrContext = nuxtApp.ssrContext || {};
    if (nuxtApp.ssrContext.payload) {
      Object.assign(nuxtApp.payload, nuxtApp.ssrContext.payload);
    }
    nuxtApp.ssrContext.payload = nuxtApp.payload;
    nuxtApp.ssrContext.config = {
      public: options2.ssrContext.runtimeConfig.public,
      app: options2.ssrContext.runtimeConfig.app
    };
  }
  const runtimeConfig = options2.ssrContext.runtimeConfig;
  nuxtApp.provide("config", runtimeConfig);
  return nuxtApp;
}
async function applyPlugin(nuxtApp, plugin2) {
  if (plugin2.hooks) {
    nuxtApp.hooks.addHooks(plugin2.hooks);
  }
  if (typeof plugin2 === "function") {
    const { provide: provide2 } = await nuxtApp.runWithContext(() => plugin2(nuxtApp)) || {};
    if (provide2 && typeof provide2 === "object") {
      for (const key in provide2) {
        nuxtApp.provide(key, provide2[key]);
      }
    }
  }
}
async function applyPlugins(nuxtApp, plugins2) {
  var _a, _b;
  const resolvedPlugins = [];
  const unresolvedPlugins = [];
  const parallels = [];
  const errors = [];
  let promiseDepth = 0;
  async function executePlugin(plugin2) {
    if (plugin2.dependsOn && !plugin2.dependsOn.every((name) => resolvedPlugins.includes(name))) {
      unresolvedPlugins.push([new Set(plugin2.dependsOn), plugin2]);
    } else {
      const promise = applyPlugin(nuxtApp, plugin2).then(async () => {
        if (plugin2._name) {
          resolvedPlugins.push(plugin2._name);
          await Promise.all(unresolvedPlugins.map(async ([dependsOn, unexecutedPlugin]) => {
            if (dependsOn.has(plugin2._name)) {
              dependsOn.delete(plugin2._name);
              if (dependsOn.size === 0) {
                promiseDepth++;
                await executePlugin(unexecutedPlugin);
              }
            }
          }));
        }
      });
      if (plugin2.parallel) {
        parallels.push(promise.catch((e) => errors.push(e)));
      } else {
        await promise;
      }
    }
  }
  for (const plugin2 of plugins2) {
    if (((_a = nuxtApp.ssrContext) == null ? void 0 : _a.islandContext) && ((_b = plugin2.env) == null ? void 0 : _b.islands) === false) {
      continue;
    }
    await executePlugin(plugin2);
  }
  await Promise.all(parallels);
  if (promiseDepth) {
    for (let i = 0; i < promiseDepth; i++) {
      await Promise.all(parallels);
    }
  }
  if (errors.length) {
    throw errors[0];
  }
}
// @__NO_SIDE_EFFECTS__
function defineNuxtPlugin(plugin2) {
  if (typeof plugin2 === "function") {
    return plugin2;
  }
  const _name = plugin2._name || plugin2.name;
  delete plugin2.name;
  return Object.assign(plugin2.setup || (() => {
  }), plugin2, { [NuxtPluginIndicator]: true, _name });
}
function callWithNuxt(nuxt, setup, args) {
  const fn = () => args ? setup(...args) : setup();
  {
    return nuxt.vueApp.runWithContext(() => nuxtAppCtx.callAsync(nuxt, fn));
  }
}
// @__NO_SIDE_EFFECTS__
function useNuxtApp() {
  var _a;
  let nuxtAppInstance;
  if (hasInjectionContext()) {
    nuxtAppInstance = (_a = getCurrentInstance()) == null ? void 0 : _a.appContext.app.$nuxt;
  }
  nuxtAppInstance = nuxtAppInstance || nuxtAppCtx.tryUse();
  if (!nuxtAppInstance) {
    {
      throw new Error("[nuxt] instance unavailable");
    }
  }
  return nuxtAppInstance;
}
// @__NO_SIDE_EFFECTS__
function useRuntimeConfig() {
  return (/* @__PURE__ */ useNuxtApp()).$config;
}
function defineGetter$1(obj, key, val) {
  Object.defineProperty(obj, key, { get: () => val });
}
function defineHeadPlugin(plugin2) {
  return plugin2;
}
function hashCode(s) {
  let h2 = 9;
  for (let i = 0; i < s.length; )
    h2 = Math.imul(h2 ^ s.charCodeAt(i++), 9 ** 9);
  return ((h2 ^ h2 >>> 9) + 65536).toString(16).substring(1, 8).toLowerCase();
}
function resolveTitleTemplate(template, title) {
  if (template == null)
    return title || null;
  if (typeof template === "function")
    return template(title);
  return template;
}
function unpackToArray(input, options2) {
  const unpacked = [];
  const kFn = options2.resolveKeyData || ((ctx) => ctx.key);
  const vFn = options2.resolveValueData || ((ctx) => ctx.value);
  for (const [k2, v] of Object.entries(input)) {
    unpacked.push(...(Array.isArray(v) ? v : [v]).map((i) => {
      const ctx = { key: k2, value: i };
      const val = vFn(ctx);
      if (typeof val === "object")
        return unpackToArray(val, options2);
      if (Array.isArray(val))
        return val;
      return {
        [typeof options2.key === "function" ? options2.key(ctx) : options2.key]: kFn(ctx),
        [typeof options2.value === "function" ? options2.value(ctx) : options2.value]: val
      };
    }).flat());
  }
  return unpacked;
}
function unpackToString(value, options2) {
  return Object.entries(value).map(([key, value2]) => {
    if (typeof value2 === "object")
      value2 = unpackToString(value2, options2);
    if (options2.resolve) {
      const resolved = options2.resolve({ key, value: value2 });
      if (resolved)
        return resolved;
    }
    if (typeof value2 === "number")
      value2 = value2.toString();
    if (typeof value2 === "string" && options2.wrapValue) {
      value2 = value2.replace(new RegExp(options2.wrapValue, "g"), `\\${options2.wrapValue}`);
      value2 = `${options2.wrapValue}${value2}${options2.wrapValue}`;
    }
    return `${key}${options2.keyValueSeparator || ""}${value2}`;
  }).join(options2.entrySeparator || "");
}
const p = (p2) => ({ keyValue: p2, metaKey: "property" });
const k = (p2) => ({ keyValue: p2 });
const MetaPackingSchema = {
  appleItunesApp: {
    unpack: {
      entrySeparator: ", ",
      resolve({ key, value }) {
        return `${fixKeyCase(key)}=${value}`;
      }
    }
  },
  articleExpirationTime: p("article:expiration_time"),
  articleModifiedTime: p("article:modified_time"),
  articlePublishedTime: p("article:published_time"),
  bookReleaseDate: p("book:release_date"),
  charset: {
    metaKey: "charset"
  },
  contentSecurityPolicy: {
    unpack: {
      entrySeparator: "; ",
      resolve({ key, value }) {
        return `${fixKeyCase(key)} ${value}`;
      }
    },
    metaKey: "http-equiv"
  },
  contentType: {
    metaKey: "http-equiv"
  },
  defaultStyle: {
    metaKey: "http-equiv"
  },
  fbAppId: p("fb:app_id"),
  msapplicationConfig: k("msapplication-Config"),
  msapplicationTileColor: k("msapplication-TileColor"),
  msapplicationTileImage: k("msapplication-TileImage"),
  ogAudioSecureUrl: p("og:audio:secure_url"),
  ogAudioUrl: p("og:audio"),
  ogImageSecureUrl: p("og:image:secure_url"),
  ogImageUrl: p("og:image"),
  ogSiteName: p("og:site_name"),
  ogVideoSecureUrl: p("og:video:secure_url"),
  ogVideoUrl: p("og:video"),
  profileFirstName: p("profile:first_name"),
  profileLastName: p("profile:last_name"),
  profileUsername: p("profile:username"),
  refresh: {
    metaKey: "http-equiv",
    unpack: {
      entrySeparator: ";",
      resolve({ key, value }) {
        if (key === "seconds")
          return `${value}`;
      }
    }
  },
  robots: {
    unpack: {
      entrySeparator: ", ",
      resolve({ key, value }) {
        if (typeof value === "boolean")
          return `${fixKeyCase(key)}`;
        else
          return `${fixKeyCase(key)}:${value}`;
      }
    }
  },
  xUaCompatible: {
    metaKey: "http-equiv"
  }
};
const openGraphNamespaces = [
  "og",
  "book",
  "article",
  "profile"
];
function resolveMetaKeyType(key) {
  var _a;
  const fKey = fixKeyCase(key).split(":")[0];
  if (openGraphNamespaces.includes(fKey))
    return "property";
  return ((_a = MetaPackingSchema[key]) == null ? void 0 : _a.metaKey) || "name";
}
function resolveMetaKeyValue(key) {
  var _a;
  return ((_a = MetaPackingSchema[key]) == null ? void 0 : _a.keyValue) || fixKeyCase(key);
}
function fixKeyCase(key) {
  const updated = key.replace(/([A-Z])/g, "-$1").toLowerCase();
  const fKey = updated.split("-")[0];
  if (openGraphNamespaces.includes(fKey) || fKey === "twitter")
    return key.replace(/([A-Z])/g, ":$1").toLowerCase();
  return updated;
}
function changeKeyCasingDeep(input) {
  if (Array.isArray(input)) {
    return input.map((entry2) => changeKeyCasingDeep(entry2));
  }
  if (typeof input !== "object" || Array.isArray(input))
    return input;
  const output = {};
  for (const [key, value] of Object.entries(input))
    output[fixKeyCase(key)] = changeKeyCasingDeep(value);
  return output;
}
function resolvePackedMetaObjectValue(value, key) {
  const definition = MetaPackingSchema[key];
  if (key === "refresh")
    return `${value.seconds};url=${value.url}`;
  return unpackToString(
    changeKeyCasingDeep(value),
    {
      keyValueSeparator: "=",
      entrySeparator: ", ",
      resolve({ value: value2, key: key2 }) {
        if (value2 === null)
          return "";
        if (typeof value2 === "boolean")
          return `${key2}`;
      },
      ...definition == null ? void 0 : definition.unpack
    }
  );
}
const ObjectArrayEntries = ["og:image", "og:video", "og:audio", "twitter:image"];
function sanitize(input) {
  const out = {};
  Object.entries(input).forEach(([k2, v]) => {
    if (String(v) !== "false" && k2)
      out[k2] = v;
  });
  return out;
}
function handleObjectEntry(key, v) {
  const value = sanitize(v);
  const fKey = fixKeyCase(key);
  const attr = resolveMetaKeyType(fKey);
  if (ObjectArrayEntries.includes(fKey)) {
    const input = {};
    Object.entries(value).forEach(([k2, v2]) => {
      input[`${key}${k2 === "url" ? "" : `${k2.charAt(0).toUpperCase()}${k2.slice(1)}`}`] = v2;
    });
    return unpackMeta(input).sort((a, b) => {
      var _a, _b;
      return (((_a = a[attr]) == null ? void 0 : _a.length) || 0) - (((_b = b[attr]) == null ? void 0 : _b.length) || 0);
    });
  }
  return [{ [attr]: fKey, ...value }];
}
function unpackMeta(input) {
  const extras = [];
  const primitives = {};
  Object.entries(input).forEach(([key, value]) => {
    if (!Array.isArray(value)) {
      if (typeof value === "object" && value) {
        if (ObjectArrayEntries.includes(fixKeyCase(key))) {
          extras.push(...handleObjectEntry(key, value));
          return;
        }
        primitives[key] = sanitize(value);
      } else {
        primitives[key] = value;
      }
      return;
    }
    value.forEach((v) => {
      extras.push(...typeof v === "string" ? unpackMeta({ [key]: v }) : handleObjectEntry(key, v));
    });
  });
  const meta = unpackToArray(primitives, {
    key({ key }) {
      return resolveMetaKeyType(key);
    },
    value({ key }) {
      return key === "charset" ? "charset" : "content";
    },
    resolveKeyData({ key }) {
      return resolveMetaKeyValue(key);
    },
    resolveValueData({ value, key }) {
      if (value === null)
        return "_null";
      if (typeof value === "object")
        return resolvePackedMetaObjectValue(value, key);
      return typeof value === "number" ? value.toString() : value;
    }
  });
  return [...extras, ...meta].map((m) => {
    if (m.content === "_null")
      m.content = null;
    return m;
  });
}
const sepSub = "%separator";
function processTemplateParams(s, p2, sep) {
  if (typeof s !== "string" || !s.includes("%"))
    return s;
  function sub(token) {
    let val;
    if (["s", "pageTitle"].includes(token)) {
      val = p2.pageTitle;
    } else if (token.includes(".")) {
      val = token.split(".").reduce((acc, key) => acc ? acc[key] || void 0 : void 0, p2);
    } else {
      val = p2[token];
    }
    return typeof val !== "undefined" ? (val || "").replace(/"/g, '\\"') : false;
  }
  let decoded = s;
  try {
    decoded = decodeURI(s);
  } catch {
  }
  const tokens = (decoded.match(/%(\w+\.+\w+)|%(\w+)/g) || []).sort().reverse();
  tokens.forEach((token) => {
    const re = sub(token.slice(1));
    if (typeof re === "string") {
      s = s.replace(new RegExp(`\\${token}(\\W|$)`, "g"), (_, args) => `${re}${args}`).trim();
    }
  });
  if (s.includes(sepSub)) {
    if (s.endsWith(sepSub))
      s = s.slice(0, -sepSub.length).trim();
    if (s.startsWith(sepSub))
      s = s.slice(sepSub.length).trim();
    s = s.replace(new RegExp(`\\${sepSub}\\s*\\${sepSub}`, "g"), sepSub);
    s = processTemplateParams(s, { separator: sep }, sep);
  }
  return s;
}
version.startsWith("3");
function resolveUnref(r) {
  return typeof r === "function" ? r() : unref(r);
}
function resolveUnrefHeadInput(ref2, lastKey = "") {
  if (ref2 instanceof Promise)
    return ref2;
  const root = resolveUnref(ref2);
  if (!ref2 || !root)
    return root;
  if (Array.isArray(root))
    return root.map((r) => resolveUnrefHeadInput(r, lastKey));
  if (typeof root === "object") {
    return Object.fromEntries(
      Object.entries(root).map(([k2, v]) => {
        if (k2 === "titleTemplate" || k2.startsWith("on"))
          return [k2, unref(v)];
        return [k2, resolveUnrefHeadInput(v, k2)];
      })
    );
  }
  return root;
}
const headSymbol = "usehead";
const _global = typeof globalThis !== "undefined" ? globalThis : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
const globalKey$1 = "__unhead_injection_handler__";
function setHeadInjectionHandler(handler) {
  _global[globalKey$1] = handler;
}
function injectHead() {
  if (globalKey$1 in _global) {
    return _global[globalKey$1]();
  }
  const head = inject(headSymbol);
  if (!head && "production" !== "production")
    console.warn("Unhead is missing Vue context, falling back to shared context. This may have unexpected results.");
  return head || getActiveHead();
}
function useHead(input, options2 = {}) {
  const head = options2.head || injectHead();
  if (head) {
    if (!head.ssr)
      return clientUseHead(head, input, options2);
    return head.push(input, options2);
  }
}
function clientUseHead(head, input, options2 = {}) {
  const deactivated = ref(false);
  const resolvedInput = ref({});
  watchEffect(() => {
    resolvedInput.value = deactivated.value ? {} : resolveUnrefHeadInput(input);
  });
  const entry2 = head.push(resolvedInput.value, options2);
  watch(resolvedInput, (e) => {
    entry2.patch(e);
  });
  getCurrentInstance();
  return entry2;
}
function useSeoMeta(input, options2) {
  const { title, titleTemplate, ...meta } = input;
  return useHead({
    title,
    titleTemplate,
    // @ts-expect-error runtime type
    _flatMeta: meta
  }, {
    ...options2,
    transform(t) {
      const meta2 = unpackMeta({ ...t._flatMeta });
      delete t._flatMeta;
      return {
        // @ts-expect-error runtime type
        ...t,
        meta: meta2
      };
    }
  });
}
function useServerHead(input, options2 = {}) {
  const head = options2.head || injectHead();
  delete options2.head;
  if (head)
    return head.push(input, { ...options2, mode: "server" });
}
const unhead_uGsi8HO7ef = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:head",
  enforce: "pre",
  setup(nuxtApp) {
    const head = nuxtApp.ssrContext.head;
    setHeadInjectionHandler(
      // need a fresh instance of the nuxt app to avoid parallel requests interfering with each other
      () => (/* @__PURE__ */ useNuxtApp()).vueApp._context.provides.usehead
    );
    nuxtApp.vueApp.use(head);
  }
});
function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als && currentInstance === void 0) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      contexts[key];
      return contexts[key];
    }
  };
}
const _globalThis$1 = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
_globalThis$1[globalKey] || (_globalThis$1[globalKey] = createNamespace());
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis$1[asyncHandlersKey] || (_globalThis$1[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}
const interpolatePath = (route, match) => {
  return match.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
    var _a;
    return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
  });
};
const generateRouteKey$1 = (routeProps, override) => {
  const matchedRoute = routeProps.route.matched.find((m) => {
    var _a;
    return ((_a = m.components) == null ? void 0 : _a.default) === routeProps.Component.type;
  });
  const source = override ?? (matchedRoute == null ? void 0 : matchedRoute.meta.key) ?? (matchedRoute && interpolatePath(routeProps.route, matchedRoute));
  return typeof source === "function" ? source(routeProps.route) : source;
};
const wrapInKeepAlive = (props, children) => {
  return { default: () => children };
};
function toArray(value) {
  return Array.isArray(value) ? value : [value];
}
const LayoutMetaSymbol = Symbol("layout-meta");
const PageRouteSymbol = Symbol("route");
const useRouter = () => {
  var _a;
  return (_a = /* @__PURE__ */ useNuxtApp()) == null ? void 0 : _a.$router;
};
const useRoute = () => {
  if (hasInjectionContext()) {
    return inject(PageRouteSymbol, (/* @__PURE__ */ useNuxtApp())._route);
  }
  return (/* @__PURE__ */ useNuxtApp())._route;
};
// @__NO_SIDE_EFFECTS__
function defineNuxtRouteMiddleware(middleware) {
  return middleware;
}
const addRouteMiddleware = (name, middleware, options2 = {}) => {
  const nuxtApp = /* @__PURE__ */ useNuxtApp();
  const global2 = options2.global || typeof name !== "string";
  const mw = typeof name !== "string" ? name : middleware;
  if (!mw) {
    console.warn("[nuxt] No route middleware passed to `addRouteMiddleware`.", name);
    return;
  }
  if (global2) {
    nuxtApp._middleware.global.push(mw);
  } else {
    nuxtApp._middleware.named[name] = mw;
  }
};
const isProcessingMiddleware = () => {
  try {
    if ((/* @__PURE__ */ useNuxtApp())._processingMiddleware) {
      return true;
    }
  } catch {
    return true;
  }
  return false;
};
const navigateTo = (to, options2) => {
  if (!to) {
    to = "/";
  }
  const toPath = typeof to === "string" ? to : withQuery(to.path || "/", to.query || {}) + (to.hash || "");
  if (options2 == null ? void 0 : options2.open) {
    return Promise.resolve();
  }
  const isExternal = (options2 == null ? void 0 : options2.external) || hasProtocol(toPath, { acceptRelative: true });
  if (isExternal) {
    if (!(options2 == null ? void 0 : options2.external)) {
      throw new Error("Navigating to an external URL is not allowed by default. Use `navigateTo(url, { external: true })`.");
    }
    const protocol = parseURL(toPath).protocol;
    if (protocol && isScriptProtocol(protocol)) {
      throw new Error(`Cannot navigate to a URL with '${protocol}' protocol.`);
    }
  }
  const inMiddleware = isProcessingMiddleware();
  const router = useRouter();
  const nuxtApp = /* @__PURE__ */ useNuxtApp();
  {
    if (nuxtApp.ssrContext) {
      const fullPath = typeof to === "string" || isExternal ? toPath : router.resolve(to).fullPath || "/";
      const location2 = isExternal ? toPath : joinURL((/* @__PURE__ */ useRuntimeConfig()).app.baseURL, fullPath);
      const redirect = async function(response) {
        await nuxtApp.callHook("app:redirected");
        const encodedLoc = location2.replace(/"/g, "%22");
        nuxtApp.ssrContext._renderResponse = {
          statusCode: sanitizeStatusCode((options2 == null ? void 0 : options2.redirectCode) || 302, 302),
          body: `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`,
          headers: { location: location2 }
        };
        return response;
      };
      if (!isExternal && inMiddleware) {
        router.afterEach((final) => final.fullPath === fullPath ? redirect(false) : void 0);
        return to;
      }
      return redirect(!inMiddleware ? void 0 : (
        /* abort route navigation */
        false
      ));
    }
  }
  if (isExternal) {
    nuxtApp._scope.stop();
    if (options2 == null ? void 0 : options2.replace) {
      (void 0).replace(toPath);
    } else {
      (void 0).href = toPath;
    }
    if (inMiddleware) {
      if (!nuxtApp.isHydrating) {
        return false;
      }
      return new Promise(() => {
      });
    }
    return Promise.resolve();
  }
  return (options2 == null ? void 0 : options2.replace) ? router.replace(to) : router.push(to);
};
const NUXT_ERROR_SIGNATURE = "__nuxt_error";
const useError = () => toRef((/* @__PURE__ */ useNuxtApp()).payload, "error");
const showError = (error) => {
  const nuxtError = createError(error);
  try {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const error2 = useError();
    if (false)
      ;
    error2.value = error2.value || nuxtError;
  } catch {
    throw nuxtError;
  }
  return nuxtError;
};
const isNuxtError = (error) => !!error && typeof error === "object" && NUXT_ERROR_SIGNATURE in error;
const createError = (error) => {
  const nuxtError = createError$1(error);
  Object.defineProperty(nuxtError, NUXT_ERROR_SIGNATURE, {
    value: true,
    configurable: false,
    writable: false
  });
  return nuxtError;
};
const _routes = [
  {
    name: "id___en",
    path: "/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___zh-hans",
    path: "/zh-hans/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___es",
    path: "/es/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___zh-hant",
    path: "/zh-hant/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___de",
    path: "/de/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___ja",
    path: "/ja/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___fr",
    path: "/fr/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___ko",
    path: "/ko/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___pt",
    path: "/pt/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___ru",
    path: "/ru/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___tr",
    path: "/tr/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___ar",
    path: "/ar/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___it",
    path: "/it/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___hi",
    path: "/hi/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___pl",
    path: "/pl/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___bn",
    path: "/bn/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___nl",
    path: "/nl/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___uk",
    path: "/uk/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___id",
    path: "/id/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___ms",
    path: "/ms/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___vi",
    path: "/vi/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___th",
    path: "/th/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___sv",
    path: "/sv/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___el",
    path: "/el/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___he",
    path: "/he/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___fi",
    path: "/fi/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___no",
    path: "/no/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___da",
    path: "/da/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___ro",
    path: "/ro/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "id___hu",
    path: "/hu/:id()",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/_id_-xxKRvCPl.mjs').then((m) => m.default || m)
  },
  {
    name: "index___en",
    path: "/",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___zh-hans",
    path: "/zh-hans",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___es",
    path: "/es",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___zh-hant",
    path: "/zh-hant",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___de",
    path: "/de",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___ja",
    path: "/ja",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___fr",
    path: "/fr",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___ko",
    path: "/ko",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___pt",
    path: "/pt",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___ru",
    path: "/ru",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___tr",
    path: "/tr",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___ar",
    path: "/ar",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___it",
    path: "/it",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___hi",
    path: "/hi",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___pl",
    path: "/pl",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___bn",
    path: "/bn",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___nl",
    path: "/nl",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___uk",
    path: "/uk",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___id",
    path: "/id",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___ms",
    path: "/ms",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___vi",
    path: "/vi",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___th",
    path: "/th",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___sv",
    path: "/sv",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___el",
    path: "/el",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___he",
    path: "/he",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___fi",
    path: "/fi",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___no",
    path: "/no",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___da",
    path: "/da",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___ro",
    path: "/ro",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  },
  {
    name: "index___hu",
    path: "/hu",
    meta: {},
    alias: [],
    redirect: void 0,
    component: () => import('./_nuxt/index-bIxWDI4u.mjs').then((m) => m.default || m)
  }
];
const options = {
  scrollBehavior(_to, _from, savedPosition) {
    if (_to.hash) {
      if (_from.hash && savedPosition) {
        return savedPosition;
      }
      return {
        el: _to.hash,
        top: (void 0).innerWidth <= 768 ? 148 : 96,
        behavior: "smooth"
      };
    }
  }
};
const _wrapIf = (component, props, slots) => {
  props = props === true ? {} : props;
  return { default: () => {
    var _a;
    return props ? h(component, props, slots) : (_a = slots.default) == null ? void 0 : _a.call(slots);
  } };
};
function generateRouteKey(route) {
  const source = (route == null ? void 0 : route.meta.key) ?? route.path.replace(/(:\w+)\([^)]+\)/g, "$1").replace(/(:\w+)[?+*]/g, "$1").replace(/:\w+/g, (r) => {
    var _a;
    return ((_a = route.params[r.slice(1)]) == null ? void 0 : _a.toString()) || "";
  });
  return typeof source === "function" ? source(route) : source;
}
function isChangingPage(to, from) {
  if (to === from || from === START_LOCATION) {
    return false;
  }
  if (generateRouteKey(to) !== generateRouteKey(from)) {
    return true;
  }
  const areComponentsSame = to.matched.every(
    (comp, index) => {
      var _a, _b;
      return comp.components && comp.components.default === ((_b = (_a = from.matched[index]) == null ? void 0 : _a.components) == null ? void 0 : _b.default);
    }
  );
  if (areComponentsSame) {
    return false;
  }
  return true;
}
const appPageTransition = false;
const appKeepalive = false;
const nuxtLinkDefaults = { "componentName": "NuxtLink" };
const asyncDataDefaults = { "deep": true };
const fetchDefaults = {};
const routerOptions1 = {
  scrollBehavior(to, from, savedPosition) {
    var _a;
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const behavior = ((_a = useRouter().options) == null ? void 0 : _a.scrollBehaviorType) ?? "auto";
    let position = savedPosition || void 0;
    const routeAllowsScrollToTop = typeof to.meta.scrollToTop === "function" ? to.meta.scrollToTop(to, from) : to.meta.scrollToTop;
    if (!position && from && to && routeAllowsScrollToTop !== false && isChangingPage(to, from)) {
      position = { left: 0, top: 0 };
    }
    if (to.path === from.path) {
      if (from.hash && !to.hash) {
        return { left: 0, top: 0 };
      }
      if (to.hash) {
        return { el: to.hash, top: _getHashElementScrollMarginTop(to.hash), behavior };
      }
    }
    const hasTransition = (route) => !!(route.meta.pageTransition ?? appPageTransition);
    const hookToWait = hasTransition(from) && hasTransition(to) ? "page:transition:finish" : "page:finish";
    return new Promise((resolve2) => {
      nuxtApp.hooks.hookOnce(hookToWait, async () => {
        await nextTick();
        if (to.hash) {
          position = { el: to.hash, top: _getHashElementScrollMarginTop(to.hash), behavior };
        }
        resolve2(position);
      });
    });
  }
};
function _getHashElementScrollMarginTop(selector) {
  try {
    const elem = (void 0).querySelector(selector);
    if (elem) {
      return parseFloat(getComputedStyle(elem).scrollMarginTop);
    }
  } catch {
  }
  return 0;
}
const configRouterOptions = {
  hashMode: false,
  scrollBehaviorType: "auto"
};
const routerOptions = {
  ...configRouterOptions,
  ...routerOptions1,
  ...options
};
const validate = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to) => {
  var _a;
  let __temp, __restore;
  if (!((_a = to.meta) == null ? void 0 : _a.validate)) {
    return;
  }
  useRouter();
  const result = ([__temp, __restore] = executeAsync(() => Promise.resolve(to.meta.validate(to))), __temp = await __temp, __restore(), __temp);
  if (result === true) {
    return;
  }
  {
    return result;
  }
});
const manifest_45route_45rule = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to) => {
  {
    return;
  }
});
const globalMiddleware = [
  validate,
  manifest_45route_45rule
];
const namedMiddleware = {};
const plugin = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:router",
  enforce: "pre",
  async setup(nuxtApp) {
    var _a, _b, _c;
    let __temp, __restore;
    let routerBase = (/* @__PURE__ */ useRuntimeConfig()).app.baseURL;
    if (routerOptions.hashMode && !routerBase.includes("#")) {
      routerBase += "#";
    }
    const history = ((_a = routerOptions.history) == null ? void 0 : _a.call(routerOptions, routerBase)) ?? createMemoryHistory(routerBase);
    const routes = ((_b = routerOptions.routes) == null ? void 0 : _b.call(routerOptions, _routes)) ?? _routes;
    let startPosition;
    const initialURL = nuxtApp.ssrContext.url;
    const router = createRouter({
      ...routerOptions,
      scrollBehavior: (to, from, savedPosition) => {
        var _a2;
        if (from === START_LOCATION) {
          startPosition = savedPosition;
          return;
        }
        router.options.scrollBehavior = routerOptions.scrollBehavior;
        return (_a2 = routerOptions.scrollBehavior) == null ? void 0 : _a2.call(routerOptions, to, START_LOCATION, startPosition || savedPosition);
      },
      history,
      routes
    });
    nuxtApp.vueApp.use(router);
    const previousRoute = shallowRef(router.currentRoute.value);
    router.afterEach((_to, from) => {
      previousRoute.value = from;
    });
    Object.defineProperty(nuxtApp.vueApp.config.globalProperties, "previousRoute", {
      get: () => previousRoute.value
    });
    const _route = shallowRef(router.resolve(initialURL));
    const syncCurrentRoute = () => {
      _route.value = router.currentRoute.value;
    };
    nuxtApp.hook("page:finish", syncCurrentRoute);
    router.afterEach((to, from) => {
      var _a2, _b2, _c2, _d;
      if (((_b2 = (_a2 = to.matched[0]) == null ? void 0 : _a2.components) == null ? void 0 : _b2.default) === ((_d = (_c2 = from.matched[0]) == null ? void 0 : _c2.components) == null ? void 0 : _d.default)) {
        syncCurrentRoute();
      }
    });
    const route = {};
    for (const key in _route.value) {
      Object.defineProperty(route, key, {
        get: () => _route.value[key]
      });
    }
    nuxtApp._route = shallowReactive(route);
    nuxtApp._middleware = nuxtApp._middleware || {
      global: [],
      named: {}
    };
    useError();
    try {
      if (true) {
        ;
        [__temp, __restore] = executeAsync(() => router.push(initialURL)), await __temp, __restore();
        ;
      }
      ;
      [__temp, __restore] = executeAsync(() => router.isReady()), await __temp, __restore();
      ;
    } catch (error2) {
      [__temp, __restore] = executeAsync(() => nuxtApp.runWithContext(() => showError(error2))), await __temp, __restore();
    }
    if ((_c = nuxtApp.ssrContext) == null ? void 0 : _c.islandContext) {
      return { provide: { router } };
    }
    const initialLayout = nuxtApp.payload.state._layout;
    router.beforeEach(async (to, from) => {
      var _a2, _b2;
      await nuxtApp.callHook("page:loading:start");
      to.meta = reactive(to.meta);
      if (nuxtApp.isHydrating && initialLayout && !isReadonly(to.meta.layout)) {
        to.meta.layout = initialLayout;
      }
      nuxtApp._processingMiddleware = true;
      if (!((_a2 = nuxtApp.ssrContext) == null ? void 0 : _a2.islandContext)) {
        const middlewareEntries = /* @__PURE__ */ new Set([...globalMiddleware, ...nuxtApp._middleware.global]);
        for (const component of to.matched) {
          const componentMiddleware = component.meta.middleware;
          if (!componentMiddleware) {
            continue;
          }
          for (const entry2 of toArray(componentMiddleware)) {
            middlewareEntries.add(entry2);
          }
        }
        for (const entry2 of middlewareEntries) {
          const middleware = typeof entry2 === "string" ? nuxtApp._middleware.named[entry2] || await ((_b2 = namedMiddleware[entry2]) == null ? void 0 : _b2.call(namedMiddleware).then((r) => r.default || r)) : entry2;
          if (!middleware) {
            throw new Error(`Unknown route middleware: '${entry2}'.`);
          }
          const result = await nuxtApp.runWithContext(() => middleware(to, from));
          {
            if (result === false || result instanceof Error) {
              const error2 = result || createError$1({
                statusCode: 404,
                statusMessage: `Page Not Found: ${initialURL}`
              });
              await nuxtApp.runWithContext(() => showError(error2));
              return false;
            }
          }
          if (result === true) {
            continue;
          }
          if (result || result === false) {
            return result;
          }
        }
      }
    });
    router.onError(async () => {
      delete nuxtApp._processingMiddleware;
      await nuxtApp.callHook("page:loading:end");
    });
    router.afterEach(async (to, _from, failure) => {
      delete nuxtApp._processingMiddleware;
      if (failure) {
        await nuxtApp.callHook("page:loading:end");
      }
      if ((failure == null ? void 0 : failure.type) === 4) {
        return;
      }
      if (to.matched.length === 0) {
        await nuxtApp.runWithContext(() => showError(createError$1({
          statusCode: 404,
          fatal: false,
          statusMessage: `Page not found: ${to.fullPath}`,
          data: {
            path: to.fullPath
          }
        })));
      } else if (to.redirectedFrom && to.fullPath !== initialURL) {
        await nuxtApp.runWithContext(() => navigateTo(to.fullPath || "/"));
      }
    });
    nuxtApp.hooks.hookOnce("app:created", async () => {
      try {
        await router.replace({
          ...router.resolve(initialURL),
          name: void 0,
          // #4920, #4982
          force: true
        });
        router.options.scrollBehavior = routerOptions.scrollBehavior;
      } catch (error2) {
        await nuxtApp.runWithContext(() => showError(error2));
      }
    });
    return { provide: { router } };
  }
});
function useRequestEvent(nuxtApp = /* @__PURE__ */ useNuxtApp()) {
  var _a;
  return (_a = nuxtApp.ssrContext) == null ? void 0 : _a.event;
}
function useRequestHeaders(include) {
  const event = useRequestEvent();
  const _headers = event ? getRequestHeaders(event) : {};
  if (!include || !event) {
    return _headers;
  }
  const headers = /* @__PURE__ */ Object.create(null);
  for (const _key of include) {
    const key = _key.toLowerCase();
    const header = _headers[key];
    if (header) {
      headers[key] = header;
    }
  }
  return headers;
}
function useRequestFetch() {
  var _a;
  return ((_a = useRequestEvent()) == null ? void 0 : _a.$fetch) || globalThis.$fetch;
}
const useStateKeyPrefix = "$s";
function useState(...args) {
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  const [_key, init] = args;
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useState] key must be a string: " + _key);
  }
  if (init !== void 0 && typeof init !== "function") {
    throw new Error("[nuxt] [useState] init must be a function: " + init);
  }
  const key = useStateKeyPrefix + _key;
  const nuxt = /* @__PURE__ */ useNuxtApp();
  const state = toRef(nuxt.payload.state, key);
  if (state.value === void 0 && init) {
    const initialValue = init();
    if (isRef(initialValue)) {
      nuxt.payload.state[key] = initialValue;
      return initialValue;
    }
    state.value = initialValue;
  }
  return state;
}
const _0_siteConfig_PmgwD9dYJy = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt-site-config:init",
  enforce: "pre",
  async setup(nuxtApp) {
    const state = useState("site-config");
    {
      const { context } = useRequestEvent();
      nuxtApp.hooks.hook("app:rendered", () => {
        state.value = context.siteConfig.get({
          debug: (/* @__PURE__ */ useRuntimeConfig())["nuxt-site-config"].debug,
          resolveRefs: true
        });
      });
    }
    let stack = {};
    return {
      provide: {
        nuxtSiteConfig: stack
      }
    };
  }
});
function definePayloadReducer(name, reduce) {
  {
    (/* @__PURE__ */ useNuxtApp()).ssrContext._payloadReducers[name] = reduce;
  }
}
const reducers = {
  NuxtError: (data) => isNuxtError(data) && data.toJSON(),
  EmptyShallowRef: (data) => isRef(data) && isShallow(data) && !data.value && (typeof data.value === "bigint" ? "0n" : JSON.stringify(data.value) || "_"),
  EmptyRef: (data) => isRef(data) && !data.value && (typeof data.value === "bigint" ? "0n" : JSON.stringify(data.value) || "_"),
  ShallowRef: (data) => isRef(data) && isShallow(data) && data.value,
  ShallowReactive: (data) => isReactive(data) && isShallow(data) && toRaw(data),
  Ref: (data) => isRef(data) && data.value,
  Reactive: (data) => isReactive(data) && toRaw(data)
};
{
  reducers.Island = (data) => data && (data == null ? void 0 : data.__nuxt_island);
}
const revive_payload_server_lq8NAzC4IZ = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:revive-payload:server",
  setup() {
    for (const reducer in reducers) {
      definePayloadReducer(reducer, reducers[reducer]);
    }
  }
});
const components_plugin_KR1HBZs4kY = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt:global-components"
});
function titleCase(s) {
  return s.replaceAll("-", " ").replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.substr(1).toLowerCase());
}
const titles_CZZrVZoIyy = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt-seo:fallback-titles",
  setup() {
    const route = useRoute();
    const title = computed(() => {
      var _a, _b;
      if (typeof ((_a = route.meta) == null ? void 0 : _a.title) === "string")
        return (_b = route.meta) == null ? void 0 : _b.title;
      const path = withoutTrailingSlash$1(route.path || "/");
      const lastSegment = path.split("/").pop();
      return lastSegment ? titleCase(lastSegment) : null;
    });
    const minimalPriority = {
      // give nuxt.config values higher priority
      tagPriority: 101
    };
    useHead({ title: () => title.value }, minimalPriority);
  }
});
function useNitroOrigin(e) {
  {
    e = e || useRequestEvent();
    return e.context.siteConfigNitroOrigin;
  }
}
function useSiteConfig(options2) {
  let stack;
  stack = useRequestEvent().context.siteConfig.get(defu({ resolveRefs: true }, options2));
  return stack || {};
}
function resolveSitePath(pathOrUrl, options2) {
  let path = pathOrUrl;
  if (hasProtocol(pathOrUrl, { strict: false, acceptRelative: true })) {
    const parsed = parseURL(pathOrUrl);
    path = parsed.pathname;
  }
  const base = withLeadingSlash(options2.base || "/");
  if (base !== "/" && path.startsWith(base)) {
    path = path.slice(base.length);
  }
  const origin = options2.absolute ? options2.siteUrl : "";
  const baseWithOrigin = options2.withBase ? withBase(base, origin || "/") : origin;
  const resolvedUrl = withBase(path, baseWithOrigin);
  return path === "/" && !options2.withBase ? withTrailingSlash$1(resolvedUrl) : fixSlashes(options2.trailingSlash, resolvedUrl);
}
function fixSlashes(trailingSlash, pathOrUrl) {
  const $url = parseURL(pathOrUrl);
  const isFileUrl = $url.pathname.includes(".");
  if (isFileUrl)
    return pathOrUrl;
  const fixedPath = trailingSlash ? withTrailingSlash$1($url.pathname) : withoutTrailingSlash$1($url.pathname);
  return `${$url.protocol ? `${$url.protocol}//` : ""}${$url.host || ""}${fixedPath}${$url.search || ""}${$url.hash || ""}`;
}
function createSitePathResolver(options2 = {}) {
  const siteConfig = useSiteConfig();
  const nitroOrigin = useNitroOrigin();
  const nuxtBase = (/* @__PURE__ */ useRuntimeConfig()).app.baseURL || "/";
  return (path) => {
    return computed(() => resolveSitePath(unref(path), {
      absolute: unref(options2.absolute),
      withBase: unref(options2.withBase),
      siteUrl: unref(options2.canonical) !== false || false ? siteConfig.url : nitroOrigin,
      trailingSlash: siteConfig.trailingSlash,
      base: nuxtBase
    }));
  };
}
function withSiteUrl(path, options2 = {}) {
  const siteConfig = useSiteConfig();
  const nitroOrigin = useNitroOrigin();
  const base = (/* @__PURE__ */ useRuntimeConfig()).app.baseURL || "/";
  return computed(() => {
    return resolveSitePath(unref(path), {
      absolute: true,
      siteUrl: unref(options2.canonical) !== false || false ? siteConfig.url : nitroOrigin,
      trailingSlash: siteConfig.trailingSlash,
      base,
      withBase: unref(options2.withBase)
    });
  });
}
const defaults_oYhGr5yYt9 = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt-seo:defaults",
  setup() {
    const siteConfig = useSiteConfig();
    const route = useRoute();
    const resolveUrl = createSitePathResolver({ withBase: true, absolute: true });
    const canonicalUrl = computed(() => resolveUrl(route.path || "/").value || route.path);
    const minimalPriority = {
      // give nuxt.config values higher priority
      tagPriority: 101
    };
    useHead({
      link: [{ rel: "canonical", href: () => canonicalUrl.value }]
    });
    const locale = siteConfig.currentLocale || siteConfig.defaultLocale;
    if (locale) {
      useServerHead({
        htmlAttrs: { lang: locale }
      });
    }
    useHead({
      templateParams: { site: siteConfig, siteName: siteConfig.name || "" },
      titleTemplate: "%s %separator %siteName"
    }, minimalPriority);
    const seoMeta = {
      ogType: "website",
      ogUrl: () => canonicalUrl.value,
      ogLocale: locale,
      ogSiteName: siteConfig.name
    };
    if (siteConfig.description)
      seoMeta.description = siteConfig.description;
    if (siteConfig.twitter) {
      const id = siteConfig.twitter.startsWith("@") ? siteConfig.twitter : `@${siteConfig.twitter}`;
      seoMeta.twitterCreator = id;
      seoMeta.twitterSite = id;
    }
    useSeoMeta(seoMeta, minimalPriority);
  }
});
const siteConfig_JLt9UuYZxZ = /* @__PURE__ */ defineNuxtPlugin(() => {
  const head = injectHead();
  if (!head)
    return;
  const siteConfig = useSiteConfig();
  const input = {
    meta: [],
    templateParams: {
      site: siteConfig,
      // support legacy
      siteUrl: siteConfig.url,
      siteName: siteConfig.name
    }
  };
  if (siteConfig.separator)
    input.templateParams.separator = siteConfig.separator;
  if (siteConfig.titleSeparator)
    input.templateParams.titleSeparator = siteConfig.titleSeparator;
  if (siteConfig.description) {
    input.templateParams.siteDescription = siteConfig.description;
    input.meta.push(
      {
        name: "description",
        content: "%site.description"
      }
    );
  }
  head.push(input, { tagPriority: 150 });
});
// @__NO_SIDE_EFFECTS__
function InferSeoMetaPlugin(options2 = {}) {
  return defineHeadPlugin({
    hooks: {
      entries: {
        resolve({ entries }) {
          var _a;
          let titleTemplate = null;
          for (const entry2 of entries) {
            const inputKey = entry2.resolvedInput ? "resolvedInput" : "input";
            const input = entry2[inputKey];
            if (typeof input.titleTemplate !== "undefined")
              titleTemplate = input.titleTemplate;
          }
          for (const entry2 of entries) {
            const inputKey = entry2.resolvedInput ? "resolvedInput" : "input";
            const input = entry2[inputKey];
            const resolvedMeta = input.meta || [];
            titleTemplate = resolveTitleTemplate(titleTemplate, input.title);
            const title = input.title;
            const description = (_a = resolvedMeta.find((meta) => meta.name === "description")) == null ? void 0 : _a.content;
            const hasOgTitle = resolvedMeta.some((meta) => meta.property === "og:title");
            const hasOgImage = resolvedMeta.some((meta) => meta.property === "og:image");
            const hasTwitterCard = resolvedMeta.some((meta) => meta.name === "twitter:card");
            const hasOgDescription = resolvedMeta.some((meta) => meta.property === "og:description");
            entry2[inputKey].meta = input.meta || [];
            if (!hasOgTitle && (input.titleTemplate || input.title)) {
              let newOgTitle = (options2 == null ? void 0 : options2.ogTitle) || titleTemplate || input.title;
              if (typeof newOgTitle === "function")
                newOgTitle = newOgTitle(title);
              if (newOgTitle) {
                entry2[inputKey].meta.push({
                  property: "og:title",
                  // have the og:title be removed if we don't have a title
                  content: String(newOgTitle)
                });
              }
            }
            if (description && !hasOgDescription) {
              let newOgDescription = (options2 == null ? void 0 : options2.ogDescription) || description;
              if (typeof newOgDescription === "function")
                newOgDescription = newOgDescription(title);
              if (newOgDescription) {
                entry2[inputKey].meta.push({
                  property: "og:description",
                  content: String(newOgDescription)
                });
              }
            }
            if (hasOgImage && !hasTwitterCard) {
              entry2[inputKey].meta.push({
                name: "twitter:card",
                content: (options2 == null ? void 0 : options2.twitterCard) || "summary_large_image"
              });
            }
          }
        }
      }
    }
  });
}
const inferSeoMetaPlugin_hZhhlDCNd2 = /* @__PURE__ */ defineNuxtPlugin(() => {
  const head = injectHead();
  if (!head)
    return;
  head.use(/* @__PURE__ */ InferSeoMetaPlugin());
});
function defineSchemaOrgResolver(schema) {
  return schema;
}
function idReference(node) {
  return {
    "@id": typeof node !== "string" ? node["@id"] : node
  };
}
function resolvableDateToDate(val) {
  try {
    const date = val instanceof Date ? val : new Date(Date.parse(val));
    return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
  } catch (e) {
  }
  return typeof val === "string" ? val : val.toString();
}
function resolvableDateToIso(val) {
  if (!val)
    return val;
  try {
    if (val instanceof Date)
      return val.toISOString();
    else
      return new Date(Date.parse(val)).toISOString();
  } catch (e) {
  }
  return typeof val === "string" ? val : val.toString();
}
const IdentityId = "#identity";
function setIfEmpty(node, field, value) {
  if (!(node == null ? void 0 : node[field]) && value)
    node[field] = value;
}
function asArray(input) {
  return Array.isArray(input) ? input : [input];
}
function dedupeMerge(node, field, value) {
  const dedupeMerge2 = [];
  const input = asArray(node[field]);
  dedupeMerge2.push(...input);
  const data = new Set(dedupeMerge2);
  data.add(value);
  node[field] = [...data.values()].filter(Boolean);
}
function prefixId(url, id) {
  if (hasProtocol(id))
    return id;
  if (!id.startsWith("#"))
    id = `#${id}`;
  return withBase(id, url);
}
function trimLength(val, length) {
  if (!val)
    return val;
  if (val.length > length) {
    const trimmedString = val.substring(0, length);
    return trimmedString.substring(0, Math.min(trimmedString.length, trimmedString.lastIndexOf(" ")));
  }
  return val;
}
function resolveDefaultType(node, defaultType) {
  const val = node["@type"];
  if (val === defaultType)
    return;
  const types = /* @__PURE__ */ new Set([
    ...asArray(defaultType),
    ...asArray(val)
  ]);
  node["@type"] = types.size === 1 ? val : [...types.values()];
}
function resolveWithBase(base, urlOrPath) {
  if (!urlOrPath || hasProtocol(urlOrPath) || !urlOrPath.startsWith("/") && !urlOrPath.startsWith("#"))
    return urlOrPath;
  return withBase(urlOrPath, base);
}
function resolveAsGraphKey(key) {
  if (!key)
    return key;
  return key.substring(key.lastIndexOf("#"));
}
function stripEmptyProperties(obj) {
  Object.keys(obj).forEach((k2) => {
    if (obj[k2] && typeof obj[k2] === "object") {
      if (obj[k2].__v_isReadonly || obj[k2].__v_isRef)
        return;
      stripEmptyProperties(obj[k2]);
      return;
    }
    if (obj[k2] === "" || obj[k2] === null || typeof obj[k2] === "undefined")
      delete obj[k2];
  });
  return obj;
}
const offerResolver = defineSchemaOrgResolver({
  cast(node) {
    if (typeof node === "number" || typeof node === "string") {
      return {
        price: node
      };
    }
    return node;
  },
  defaults: {
    "@type": "Offer",
    "availability": "InStock"
  },
  resolve(node, ctx) {
    setIfEmpty(node, "priceCurrency", ctx.meta.currency);
    setIfEmpty(node, "priceValidUntil", new Date(Date.UTC((/* @__PURE__ */ new Date()).getFullYear() + 1, 12, -1, 0, 0, 0)));
    if (node.url)
      resolveWithBase(ctx.meta.host, node.url);
    if (node.availability)
      node.availability = withBase(node.availability, "https://schema.org/");
    if (node.priceValidUntil)
      node.priceValidUntil = resolvableDateToIso(node.priceValidUntil);
    return node;
  }
});
const aggregateOfferResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "AggregateOffer"
  },
  inheritMeta: [
    { meta: "currency", key: "priceCurrency" }
  ],
  resolve(node, ctx) {
    node.offers = resolveRelation(node.offers, ctx, offerResolver);
    if (node.offers)
      setIfEmpty(node, "offerCount", asArray(node.offers).length);
    return node;
  }
});
const aggregateRatingResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "AggregateRating"
  }
});
const searchActionResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "SearchAction",
    "target": {
      "@type": "EntryPoint"
    },
    "query-input": {
      "@type": "PropertyValueSpecification",
      "valueRequired": true,
      "valueName": "search_term_string"
    }
  },
  resolve(node, ctx) {
    if (typeof node.target === "string") {
      node.target = {
        "@type": "EntryPoint",
        "urlTemplate": resolveWithBase(ctx.meta.host, node.target)
      };
    }
    return node;
  }
});
const PrimaryWebSiteId = "#website";
const webSiteResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "WebSite"
  },
  inheritMeta: [
    "inLanguage",
    { meta: "host", key: "url" }
  ],
  idPrefix: ["host", PrimaryWebSiteId],
  resolve(node, ctx) {
    node.potentialAction = resolveRelation(node.potentialAction, ctx, searchActionResolver, {
      array: true
    });
    node.publisher = resolveRelation(node.publisher, ctx);
    return node;
  },
  resolveRootNode(node, { find }) {
    if (resolveAsGraphKey(node["@id"]) === PrimaryWebSiteId) {
      const identity = find(IdentityId);
      if (identity)
        setIfEmpty(node, "publisher", idReference(identity));
      const webPage = find(PrimaryWebPageId);
      if (webPage)
        setIfEmpty(webPage, "isPartOf", idReference(node));
    }
    return node;
  }
});
const listItemResolver = defineSchemaOrgResolver({
  cast(node) {
    if (typeof node === "string") {
      node = {
        name: node
      };
    }
    return node;
  },
  defaults: {
    "@type": "ListItem"
  },
  resolve(node, ctx) {
    if (typeof node.item === "string")
      node.item = resolveWithBase(ctx.meta.host, node.item);
    else if (typeof node.item === "object")
      node.item = resolveRelation(node.item, ctx);
    return node;
  }
});
const PrimaryBreadcrumbId = "#breadcrumb";
const breadcrumbResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "BreadcrumbList"
  },
  idPrefix: ["url", PrimaryBreadcrumbId],
  resolve(breadcrumb, ctx) {
    if (breadcrumb.itemListElement) {
      let index = 1;
      breadcrumb.itemListElement = resolveRelation(breadcrumb.itemListElement, ctx, listItemResolver, {
        array: true,
        afterResolve(node) {
          setIfEmpty(node, "position", index++);
        }
      });
    }
    return breadcrumb;
  },
  resolveRootNode(node, { find }) {
    const webPage = find(PrimaryWebPageId);
    if (webPage)
      setIfEmpty(webPage, "breadcrumb", idReference(node));
  }
});
const imageResolver = defineSchemaOrgResolver({
  alias: "image",
  cast(input) {
    if (typeof input === "string") {
      input = {
        url: input
      };
    }
    return input;
  },
  defaults: {
    "@type": "ImageObject"
  },
  inheritMeta: [
    // @todo possibly only do if there's a caption
    "inLanguage"
  ],
  idPrefix: "host",
  resolve(image, { meta }) {
    image.url = resolveWithBase(meta.host, image.url);
    setIfEmpty(image, "contentUrl", image.url);
    if (image.height && !image.width)
      delete image.height;
    if (image.width && !image.height)
      delete image.width;
    return image;
  }
});
const addressResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "PostalAddress"
  }
});
const organizationResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Organization"
  },
  idPrefix: ["host", IdentityId],
  inheritMeta: [
    { meta: "host", key: "url" }
  ],
  resolve(node, ctx) {
    resolveDefaultType(node, "Organization");
    node.address = resolveRelation(node.address, ctx, addressResolver);
    return node;
  },
  resolveRootNode(node, ctx) {
    const isIdentity = resolveAsGraphKey(node["@id"]) === IdentityId;
    const webPage = ctx.find(PrimaryWebPageId);
    if (node.logo && isIdentity) {
      if (!ctx.find("#organization")) {
        const logoNode = resolveRelation(node.logo, ctx, imageResolver, {
          root: true,
          afterResolve(logo) {
            logo["@id"] = prefixId(ctx.meta.host, "#logo");
            setIfEmpty(logo, "caption", node.name);
          }
        });
        if (webPage && logoNode)
          setIfEmpty(webPage, "primaryImageOfPage", idReference(logoNode));
        ctx.nodes.push({
          // we want to make a simple node that has the essentials, this will allow parent nodes to inject
          // as well without inserting invalid data (i.e LocalBusiness operatingHours)
          "@type": "Organization",
          "name": node.name,
          "url": node.url,
          "sameAs": node.sameAs,
          // 'image': idReference(logoNode),
          "address": node.address,
          // needs to be a URL
          "logo": resolveRelation(node.logo, ctx, imageResolver, { root: false }).url,
          "_priority": -1,
          "@id": prefixId(ctx.meta.host, "#organization")
          // avoid the id so nothing can link to it
        });
      }
      delete node.logo;
    }
    if (isIdentity && webPage)
      setIfEmpty(webPage, "about", idReference(node));
    const webSite = ctx.find(PrimaryWebSiteId);
    if (webSite)
      setIfEmpty(webSite, "publisher", idReference(node));
  }
});
const personResolver = defineSchemaOrgResolver({
  cast(node) {
    if (typeof node === "string") {
      return {
        name: node
      };
    }
    return node;
  },
  defaults: {
    "@type": "Person"
  },
  idPrefix: ["host", IdentityId],
  resolve(node, ctx) {
    if (node.url)
      node.url = resolveWithBase(ctx.meta.host, node.url);
    return node;
  },
  resolveRootNode(node, { find, meta }) {
    if (resolveAsGraphKey(node["@id"]) === IdentityId) {
      setIfEmpty(node, "url", meta.host);
      const webPage = find(PrimaryWebPageId);
      if (webPage)
        setIfEmpty(webPage, "about", idReference(node));
      const webSite = find(PrimaryWebSiteId);
      if (webSite)
        setIfEmpty(webSite, "publisher", idReference(node));
    }
    const article = find(PrimaryArticleId);
    if (article)
      setIfEmpty(article, "author", idReference(node));
  }
});
const readActionResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "ReadAction"
  },
  resolve(node, ctx) {
    if (!node.target.includes(ctx.meta.url))
      node.target.unshift(ctx.meta.url);
    return node;
  }
});
const PrimaryWebPageId = "#webpage";
const webPageResolver = defineSchemaOrgResolver({
  defaults({ meta }) {
    const endPath = withoutTrailingSlash$1(meta.url.substring(meta.url.lastIndexOf("/") + 1));
    let type = "WebPage";
    switch (endPath) {
      case "about":
      case "about-us":
        type = "AboutPage";
        break;
      case "search":
        type = "SearchResultsPage";
        break;
      case "checkout":
        type = "CheckoutPage";
        break;
      case "contact":
      case "get-in-touch":
      case "contact-us":
        type = "ContactPage";
        break;
      case "faq":
        type = "FAQPage";
        break;
    }
    const defaults2 = {
      "@type": type
    };
    return defaults2;
  },
  idPrefix: ["url", PrimaryWebPageId],
  inheritMeta: [
    { meta: "title", key: "name" },
    "description",
    "datePublished",
    "dateModified",
    "url"
  ],
  resolve(node, ctx) {
    node.dateModified = resolvableDateToIso(node.dateModified);
    node.datePublished = resolvableDateToIso(node.datePublished);
    resolveDefaultType(node, "WebPage");
    node.about = resolveRelation(node.about, ctx, organizationResolver);
    node.breadcrumb = resolveRelation(node.breadcrumb, ctx, breadcrumbResolver);
    node.author = resolveRelation(node.author, ctx, personResolver);
    node.primaryImageOfPage = resolveRelation(node.primaryImageOfPage, ctx, imageResolver);
    node.potentialAction = resolveRelation(node.potentialAction, ctx, readActionResolver);
    if (node["@type"] === "WebPage" && ctx.meta.url) {
      setIfEmpty(node, "potentialAction", [
        {
          "@type": "ReadAction",
          "target": [ctx.meta.url]
        }
      ]);
    }
    return node;
  },
  resolveRootNode(webPage, { find, meta }) {
    const identity = find(IdentityId);
    const webSite = find(PrimaryWebSiteId);
    const logo = find("#logo");
    if (identity && meta.url === meta.host)
      setIfEmpty(webPage, "about", idReference(identity));
    if (logo)
      setIfEmpty(webPage, "primaryImageOfPage", idReference(logo));
    if (webSite)
      setIfEmpty(webPage, "isPartOf", idReference(webSite));
    const breadcrumb = find(PrimaryBreadcrumbId);
    if (breadcrumb)
      setIfEmpty(webPage, "breadcrumb", idReference(breadcrumb));
    return webPage;
  }
});
const PrimaryArticleId = "#article";
const articleResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Article"
  },
  inheritMeta: [
    "inLanguage",
    "description",
    "image",
    "dateModified",
    "datePublished",
    { meta: "title", key: "headline" }
  ],
  idPrefix: ["url", PrimaryArticleId],
  resolve(node, ctx) {
    node.author = resolveRelation(node.author, ctx, personResolver, {
      root: true
    });
    node.publisher = resolveRelation(node.publisher, ctx);
    node.dateModified = resolvableDateToIso(node.dateModified);
    node.datePublished = resolvableDateToIso(node.datePublished);
    resolveDefaultType(node, "Article");
    node.headline = trimLength(node.headline, 110);
    return node;
  },
  resolveRootNode(node, { find, meta }) {
    var _a;
    const webPage = find(PrimaryWebPageId);
    const identity = find(IdentityId);
    if (node.image && !node.thumbnailUrl) {
      const firstImage = asArray(node.image)[0];
      if (typeof firstImage === "string")
        setIfEmpty(node, "thumbnailUrl", resolveWithBase(meta.host, firstImage));
      else if (firstImage == null ? void 0 : firstImage["@id"])
        setIfEmpty(node, "thumbnailUrl", (_a = find(firstImage["@id"])) == null ? void 0 : _a.url);
    }
    if (identity) {
      setIfEmpty(node, "publisher", idReference(identity));
      setIfEmpty(node, "author", idReference(identity));
    }
    if (webPage) {
      setIfEmpty(node, "isPartOf", idReference(webPage));
      setIfEmpty(node, "mainEntityOfPage", idReference(webPage));
      setIfEmpty(webPage, "potentialAction", [
        {
          "@type": "ReadAction",
          "target": [meta.url]
        }
      ]);
      setIfEmpty(webPage, "dateModified", node.dateModified);
      setIfEmpty(webPage, "datePublished", node.datePublished);
    }
    return node;
  }
});
const bookEditionResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Book"
  },
  inheritMeta: [
    "inLanguage"
  ],
  resolve(node, ctx) {
    if (node.bookFormat)
      node.bookFormat = withBase(node.bookFormat, "https://schema.org/");
    if (node.datePublished)
      node.datePublished = resolvableDateToDate(node.datePublished);
    node.author = resolveRelation(node.author, ctx);
    return node;
  },
  resolveRootNode(node, { find }) {
    const identity = find(IdentityId);
    if (identity)
      setIfEmpty(node, "provider", idReference(identity));
    return node;
  }
});
const PrimaryBookId = "#book";
const bookResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Book"
  },
  inheritMeta: [
    "description",
    "url",
    { meta: "title", key: "name" }
  ],
  idPrefix: ["url", PrimaryBookId],
  resolve(node, ctx) {
    node.workExample = resolveRelation(node.workExample, ctx, bookEditionResolver);
    node.author = resolveRelation(node.author, ctx);
    if (node.url)
      withBase(node.url, ctx.meta.host);
    return node;
  },
  resolveRootNode(node, { find }) {
    const identity = find(IdentityId);
    if (identity)
      setIfEmpty(node, "author", idReference(identity));
    return node;
  }
});
const commentResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Comment"
  },
  idPrefix: "url",
  resolve(node, ctx) {
    node.author = resolveRelation(node.author, ctx, personResolver, {
      root: true
    });
    return node;
  },
  resolveRootNode(node, { find }) {
    const article = find(PrimaryArticleId);
    if (article)
      setIfEmpty(node, "about", idReference(article));
  }
});
const courseResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Course"
  },
  resolve(node, ctx) {
    node.provider = resolveRelation(node.provider, ctx, organizationResolver, {
      root: true
    });
    return node;
  },
  resolveRootNode(node, { find }) {
    const identity = find(IdentityId);
    if (identity)
      setIfEmpty(node, "provider", idReference(identity));
    return node;
  }
});
const placeResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Place"
  },
  resolve(node, ctx) {
    if (typeof node.address !== "string")
      node.address = resolveRelation(node.address, ctx, addressResolver);
    return node;
  }
});
const virtualLocationResolver = defineSchemaOrgResolver({
  cast(node) {
    if (typeof node === "string") {
      return {
        url: node
      };
    }
    return node;
  },
  defaults: {
    "@type": "VirtualLocation"
  }
});
const PrimaryEventId = "#event";
const eventResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Event"
  },
  inheritMeta: [
    "inLanguage",
    "description",
    "image",
    { meta: "title", key: "name" }
  ],
  idPrefix: ["url", PrimaryEventId],
  resolve(node, ctx) {
    var _a;
    if (node.location) {
      const isVirtual = node.location === "string" || ((_a = node.location) == null ? void 0 : _a.url) !== "undefined";
      node.location = resolveRelation(node.location, ctx, isVirtual ? virtualLocationResolver : placeResolver);
    }
    node.performer = resolveRelation(node.performer, ctx, personResolver, {
      root: true
    });
    node.organizer = resolveRelation(node.organizer, ctx, organizationResolver, {
      root: true
    });
    node.offers = resolveRelation(node.offers, ctx, offerResolver);
    if (node.eventAttendanceMode)
      node.eventAttendanceMode = withBase(node.eventAttendanceMode, "https://schema.org/");
    if (node.eventStatus)
      node.eventStatus = withBase(node.eventStatus, "https://schema.org/");
    const isOnline = node.eventStatus === "https://schema.org/EventMovedOnline";
    const dates = ["startDate", "previousStartDate", "endDate"];
    dates.forEach((date) => {
      if (!isOnline) {
        if (node[date] instanceof Date && node[date].getHours() === 0 && node[date].getMinutes() === 0)
          node[date] = resolvableDateToDate(node[date]);
      } else {
        node[date] = resolvableDateToIso(node[date]);
      }
    });
    setIfEmpty(node, "endDate", node.startDate);
    return node;
  },
  resolveRootNode(node, { find }) {
    const identity = find(IdentityId);
    if (identity)
      setIfEmpty(node, "organizer", idReference(identity));
  }
});
const ratingResolver = defineSchemaOrgResolver({
  cast(node) {
    if (node === "number") {
      return {
        ratingValue: node
      };
    }
    return node;
  },
  defaults: {
    "@type": "Rating",
    "bestRating": 5,
    "worstRating": 1
  }
});
const openingHoursResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "OpeningHoursSpecification",
    "opens": "00:00",
    "closes": "23:59"
  }
});
const localBusinessResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": ["Organization", "LocalBusiness"]
  },
  inheritMeta: [
    { key: "url", meta: "host" },
    { key: "currenciesAccepted", meta: "currency" }
  ],
  idPrefix: ["host", IdentityId],
  resolve(node, ctx) {
    resolveDefaultType(node, ["Organization", "LocalBusiness"]);
    node.address = resolveRelation(node.address, ctx, addressResolver);
    node.openingHoursSpecification = resolveRelation(node.openingHoursSpecification, ctx, openingHoursResolver);
    node = resolveNode({ ...node }, ctx, organizationResolver);
    return node;
  },
  resolveRootNode(node, ctx) {
    organizationResolver.resolveRootNode(node, ctx);
    return node;
  }
});
const foodEstablishmentResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": ["Organization", "LocalBusiness", "FoodEstablishment"]
  },
  inheritMeta: [
    { key: "url", meta: "host" },
    { key: "currenciesAccepted", meta: "currency" }
  ],
  idPrefix: ["host", IdentityId],
  resolve(node, ctx) {
    resolveDefaultType(node, ["Organization", "LocalBusiness", "FoodEstablishment"]);
    node.starRating = resolveRelation(node.starRating, ctx, ratingResolver);
    node = resolveNode(node, ctx, localBusinessResolver);
    return node;
  },
  resolveRootNode(node, ctx) {
    localBusinessResolver.resolveRootNode(node, ctx);
    return node;
  }
});
const howToStepDirectionResolver = defineSchemaOrgResolver({
  cast(node) {
    if (typeof node === "string") {
      return {
        text: node
      };
    }
    return node;
  },
  defaults: {
    "@type": "HowToDirection"
  }
});
const howToStepResolver = defineSchemaOrgResolver({
  cast(node) {
    if (typeof node === "string") {
      return {
        text: node
      };
    }
    return node;
  },
  defaults: {
    "@type": "HowToStep"
  },
  resolve(step, ctx) {
    if (step.url)
      step.url = resolveWithBase(ctx.meta.url, step.url);
    if (step.image) {
      step.image = resolveRelation(step.image, ctx, imageResolver, {
        root: true
      });
    }
    if (step.itemListElement)
      step.itemListElement = resolveRelation(step.itemListElement, ctx, howToStepDirectionResolver);
    return step;
  }
});
const HowToId = "#howto";
const howToResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "HowTo"
  },
  inheritMeta: [
    "description",
    "image",
    "inLanguage",
    { meta: "title", key: "name" }
  ],
  idPrefix: ["url", HowToId],
  resolve(node, ctx) {
    node.step = resolveRelation(node.step, ctx, howToStepResolver);
    return node;
  },
  resolveRootNode(node, { find }) {
    const webPage = find(PrimaryWebPageId);
    if (webPage)
      setIfEmpty(node, "mainEntityOfPage", idReference(webPage));
  }
});
const itemListResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "ItemList"
  },
  resolve(node, ctx) {
    if (node.itemListElement) {
      let index = 1;
      node.itemListElement = resolveRelation(node.itemListElement, ctx, listItemResolver, {
        array: true,
        afterResolve(node2) {
          setIfEmpty(node2, "position", index++);
        }
      });
    }
    return node;
  }
});
const quantitativeValueResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "QuantitativeValue"
  }
});
const monetaryAmountResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "MonetaryAmount"
  },
  resolve(node, ctx) {
    node.value = resolveRelation(node.value, ctx, quantitativeValueResolver);
    return node;
  }
});
const jobPostingResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "JobPosting"
  },
  idPrefix: ["url", "#job-posting"],
  resolve(node, ctx) {
    node.datePosted = resolvableDateToIso(node.datePosted);
    node.hiringOrganization = resolveRelation(node.hiringOrganization, ctx, organizationResolver);
    node.jobLocation = resolveRelation(node.jobLocation, ctx, placeResolver);
    node.baseSalary = resolveRelation(node.baseSalary, ctx, monetaryAmountResolver);
    node.validThrough = resolvableDateToIso(node.validThrough);
    return node;
  },
  resolveRootNode(jobPosting, { find }) {
    const webPage = find(PrimaryWebPageId);
    const identity = find(IdentityId);
    if (identity)
      setIfEmpty(jobPosting, "hiringOrganization", idReference(identity));
    if (webPage)
      setIfEmpty(jobPosting, "mainEntityOfPage", idReference(webPage));
    return jobPosting;
  }
});
const reviewResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Review"
  },
  inheritMeta: [
    "inLanguage"
  ],
  resolve(review, ctx) {
    review.reviewRating = resolveRelation(review.reviewRating, ctx, ratingResolver);
    review.author = resolveRelation(review.author, ctx, personResolver);
    return review;
  }
});
const videoResolver = defineSchemaOrgResolver({
  cast(input) {
    if (typeof input === "string") {
      input = {
        url: input
      };
    }
    return input;
  },
  alias: "video",
  defaults: {
    "@type": "VideoObject"
  },
  inheritMeta: [
    { meta: "title", key: "name" },
    "description",
    "image",
    "inLanguage",
    { meta: "datePublished", key: "uploadDate" }
  ],
  idPrefix: "host",
  resolve(video, ctx) {
    if (video.uploadDate)
      video.uploadDate = resolvableDateToIso(video.uploadDate);
    video.url = resolveWithBase(ctx.meta.host, video.url);
    if (video.caption && !video.description)
      video.description = video.caption;
    if (!video.description)
      video.description = "No description";
    if (video.thumbnailUrl)
      video.thumbnailUrl = resolveRelation(video.thumbnailUrl, ctx, imageResolver);
    return video;
  },
  resolveRootNode(video, { find }) {
    var _a;
    if (video.image && !video.thumbnailUrl) {
      const firstImage = asArray(video.image)[0];
      setIfEmpty(video, "thumbnailUrl", (_a = find(firstImage["@id"])) == null ? void 0 : _a.url);
    }
  }
});
const movieResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Movie"
  },
  resolve(node, ctx) {
    node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
    node.review = resolveRelation(node.review, ctx, reviewResolver);
    node.director = resolveRelation(node.director, ctx, personResolver);
    node.actor = resolveRelation(node.actor, ctx, personResolver);
    node.trailer = resolveRelation(node.trailer, ctx, videoResolver);
    if (node.dateCreated)
      node.dateCreated = resolvableDateToDate(node.dateCreated);
    return node;
  }
});
const defaults = Object.freeze({
  ignoreUnknown: false,
  respectType: false,
  respectFunctionNames: false,
  respectFunctionProperties: false,
  unorderedObjects: true,
  unorderedArrays: false,
  unorderedSets: false,
  excludeKeys: void 0,
  excludeValues: void 0,
  replacer: void 0
});
function objectHash(object, options2) {
  if (options2) {
    options2 = { ...defaults, ...options2 };
  } else {
    options2 = defaults;
  }
  const hasher = createHasher(options2);
  hasher.dispatch(object);
  return hasher.toString();
}
const defaultPrototypesKeys = Object.freeze([
  "prototype",
  "__proto__",
  "constructor"
]);
function createHasher(options2) {
  let buff = "";
  let context = /* @__PURE__ */ new Map();
  const write = (str) => {
    buff += str;
  };
  return {
    toString() {
      return buff;
    },
    getContext() {
      return context;
    },
    dispatch(value) {
      if (options2.replacer) {
        value = options2.replacer(value);
      }
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    },
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      if (objectLength < 10) {
        objType = "unknown:[" + objString + "]";
      } else {
        objType = objString.slice(8, objectLength - 1);
      }
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = context.get(object)) === void 0) {
        context.set(object, context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        write("buffer:");
        return write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else if (!options2.ignoreUnknown) {
          this.unkown(object, objType);
        }
      } else {
        let keys = Object.keys(object);
        if (options2.unorderedObjects) {
          keys = keys.sort();
        }
        let extraKeys = [];
        if (options2.respectType !== false && !isNativeFunction(object)) {
          extraKeys = defaultPrototypesKeys;
        }
        if (options2.excludeKeys) {
          keys = keys.filter((key) => {
            return !options2.excludeKeys(key);
          });
          extraKeys = extraKeys.filter((key) => {
            return !options2.excludeKeys(key);
          });
        }
        write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          write(":");
          if (!options2.excludeValues) {
            this.dispatch(object[key]);
          }
          write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    },
    array(arr, unordered) {
      unordered = unordered === void 0 ? options2.unorderedArrays !== false : unordered;
      write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry2 of arr) {
          this.dispatch(entry2);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry2) => {
        const hasher = createHasher(options2);
        hasher.dispatch(entry2);
        for (const [key, value] of hasher.getContext()) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    },
    date(date) {
      return write("date:" + date.toJSON());
    },
    symbol(sym) {
      return write("symbol:" + sym.toString());
    },
    unkown(value, type) {
      write(type);
      if (!value) {
        return;
      }
      write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          Array.from(value.entries()),
          true
          /* ordered */
        );
      }
    },
    error(err) {
      return write("error:" + err.toString());
    },
    boolean(bool) {
      return write("bool:" + bool);
    },
    string(string) {
      write("string:" + string.length + ":");
      write(string);
    },
    function(fn) {
      write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
      if (options2.respectFunctionNames !== false) {
        this.dispatch("function-name:" + String(fn.name));
      }
      if (options2.respectFunctionProperties) {
        this.object(fn);
      }
    },
    number(number2) {
      return write("number:" + number2);
    },
    xml(xml) {
      return write("xml:" + xml.toString());
    },
    null() {
      return write("Null");
    },
    undefined() {
      return write("Undefined");
    },
    regexp(regex) {
      return write("regex:" + regex.toString());
    },
    uint8array(arr) {
      write("uint8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint8clampedarray(arr) {
      write("uint8clampedarray:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int8array(arr) {
      write("int8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint16array(arr) {
      write("uint16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int16array(arr) {
      write("int16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint32array(arr) {
      write("uint32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int32array(arr) {
      write("int32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    float32array(arr) {
      write("float32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    float64array(arr) {
      write("float64array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    arraybuffer(arr) {
      write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    },
    url(url) {
      return write("url:" + url.toString());
    },
    map(map) {
      write("map:");
      const arr = [...map];
      return this.array(arr, options2.unorderedSets !== false);
    },
    set(set) {
      write("set:");
      const arr = [...set];
      return this.array(arr, options2.unorderedSets !== false);
    },
    file(file) {
      write("file:");
      return this.dispatch([file.name, file.size, file.type, file.lastModfied]);
    },
    blob() {
      if (options2.ignoreUnknown) {
        return write("[blob]");
      }
      throw new Error(
        'Hashing Blob objects is currently not supported\nUse "options.replacer" or "options.ignoreUnknown"\n'
      );
    },
    domwindow() {
      return write("domwindow");
    },
    bigint(number2) {
      return write("bigint:" + number2.toString());
    },
    /* Node.js standard native objects */
    process() {
      return write("process");
    },
    timer() {
      return write("timer");
    },
    pipe() {
      return write("pipe");
    },
    tcp() {
      return write("tcp");
    },
    udp() {
      return write("udp");
    },
    tty() {
      return write("tty");
    },
    statwatcher() {
      return write("statwatcher");
    },
    securecontext() {
      return write("securecontext");
    },
    connection() {
      return write("connection");
    },
    zlib() {
      return write("zlib");
    },
    context() {
      return write("context");
    },
    nodescript() {
      return write("nodescript");
    },
    httpparser() {
      return write("httpparser");
    },
    dataview() {
      return write("dataview");
    },
    signal() {
      return write("signal");
    },
    fsevent() {
      return write("fsevent");
    },
    tlswrap() {
      return write("tlswrap");
    }
  };
}
const nativeFunc = "[native code] }";
const nativeFuncLength = nativeFunc.length;
function isNativeFunction(f) {
  if (typeof f !== "function") {
    return false;
  }
  return Function.prototype.toString.call(f).slice(-nativeFuncLength) === nativeFunc;
}
class WordArray {
  constructor(words, sigBytes) {
    words = this.words = words || [];
    this.sigBytes = sigBytes === void 0 ? words.length * 4 : sigBytes;
  }
  toString(encoder) {
    return (encoder || Hex).stringify(this);
  }
  concat(wordArray) {
    this.clamp();
    if (this.sigBytes % 4) {
      for (let i = 0; i < wordArray.sigBytes; i++) {
        const thatByte = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
        this.words[this.sigBytes + i >>> 2] |= thatByte << 24 - (this.sigBytes + i) % 4 * 8;
      }
    } else {
      for (let j = 0; j < wordArray.sigBytes; j += 4) {
        this.words[this.sigBytes + j >>> 2] = wordArray.words[j >>> 2];
      }
    }
    this.sigBytes += wordArray.sigBytes;
    return this;
  }
  clamp() {
    this.words[this.sigBytes >>> 2] &= 4294967295 << 32 - this.sigBytes % 4 * 8;
    this.words.length = Math.ceil(this.sigBytes / 4);
  }
  clone() {
    return new WordArray([...this.words]);
  }
}
const Hex = {
  stringify(wordArray) {
    const hexChars = [];
    for (let i = 0; i < wordArray.sigBytes; i++) {
      const bite = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
      hexChars.push((bite >>> 4).toString(16), (bite & 15).toString(16));
    }
    return hexChars.join("");
  }
};
const Base64 = {
  stringify(wordArray) {
    const keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const base64Chars = [];
    for (let i = 0; i < wordArray.sigBytes; i += 3) {
      const byte1 = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
      const byte2 = wordArray.words[i + 1 >>> 2] >>> 24 - (i + 1) % 4 * 8 & 255;
      const byte3 = wordArray.words[i + 2 >>> 2] >>> 24 - (i + 2) % 4 * 8 & 255;
      const triplet = byte1 << 16 | byte2 << 8 | byte3;
      for (let j = 0; j < 4 && i * 8 + j * 6 < wordArray.sigBytes * 8; j++) {
        base64Chars.push(keyStr.charAt(triplet >>> 6 * (3 - j) & 63));
      }
    }
    return base64Chars.join("");
  }
};
const Latin1 = {
  parse(latin1Str) {
    const latin1StrLength = latin1Str.length;
    const words = [];
    for (let i = 0; i < latin1StrLength; i++) {
      words[i >>> 2] |= (latin1Str.charCodeAt(i) & 255) << 24 - i % 4 * 8;
    }
    return new WordArray(words, latin1StrLength);
  }
};
const Utf8 = {
  parse(utf8Str) {
    return Latin1.parse(unescape(encodeURIComponent(utf8Str)));
  }
};
class BufferedBlockAlgorithm {
  constructor() {
    this._data = new WordArray();
    this._nDataBytes = 0;
    this._minBufferSize = 0;
    this.blockSize = 512 / 32;
  }
  reset() {
    this._data = new WordArray();
    this._nDataBytes = 0;
  }
  _append(data) {
    if (typeof data === "string") {
      data = Utf8.parse(data);
    }
    this._data.concat(data);
    this._nDataBytes += data.sigBytes;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _doProcessBlock(_dataWords, _offset) {
  }
  _process(doFlush) {
    let processedWords;
    let nBlocksReady = this._data.sigBytes / (this.blockSize * 4);
    if (doFlush) {
      nBlocksReady = Math.ceil(nBlocksReady);
    } else {
      nBlocksReady = Math.max((nBlocksReady | 0) - this._minBufferSize, 0);
    }
    const nWordsReady = nBlocksReady * this.blockSize;
    const nBytesReady = Math.min(nWordsReady * 4, this._data.sigBytes);
    if (nWordsReady) {
      for (let offset = 0; offset < nWordsReady; offset += this.blockSize) {
        this._doProcessBlock(this._data.words, offset);
      }
      processedWords = this._data.words.splice(0, nWordsReady);
      this._data.sigBytes -= nBytesReady;
    }
    return new WordArray(processedWords, nBytesReady);
  }
}
class Hasher extends BufferedBlockAlgorithm {
  update(messageUpdate) {
    this._append(messageUpdate);
    this._process();
    return this;
  }
  finalize(messageUpdate) {
    if (messageUpdate) {
      this._append(messageUpdate);
    }
  }
}
const H = [
  1779033703,
  -1150833019,
  1013904242,
  -1521486534,
  1359893119,
  -1694144372,
  528734635,
  1541459225
];
const K = [
  1116352408,
  1899447441,
  -1245643825,
  -373957723,
  961987163,
  1508970993,
  -1841331548,
  -1424204075,
  -670586216,
  310598401,
  607225278,
  1426881987,
  1925078388,
  -2132889090,
  -1680079193,
  -1046744716,
  -459576895,
  -272742522,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  -1740746414,
  -1473132947,
  -1341970488,
  -1084653625,
  -958395405,
  -710438585,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  -2117940946,
  -1838011259,
  -1564481375,
  -1474664885,
  -1035236496,
  -949202525,
  -778901479,
  -694614492,
  -200395387,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  -2067236844,
  -1933114872,
  -1866530822,
  -1538233109,
  -1090935817,
  -965641998
];
const W = [];
class SHA256 extends Hasher {
  constructor() {
    super(...arguments);
    this._hash = new WordArray([...H]);
  }
  reset() {
    super.reset();
    this._hash = new WordArray([...H]);
  }
  _doProcessBlock(M, offset) {
    const H2 = this._hash.words;
    let a = H2[0];
    let b = H2[1];
    let c = H2[2];
    let d = H2[3];
    let e = H2[4];
    let f = H2[5];
    let g = H2[6];
    let h2 = H2[7];
    for (let i = 0; i < 64; i++) {
      if (i < 16) {
        W[i] = M[offset + i] | 0;
      } else {
        const gamma0x = W[i - 15];
        const gamma0 = (gamma0x << 25 | gamma0x >>> 7) ^ (gamma0x << 14 | gamma0x >>> 18) ^ gamma0x >>> 3;
        const gamma1x = W[i - 2];
        const gamma1 = (gamma1x << 15 | gamma1x >>> 17) ^ (gamma1x << 13 | gamma1x >>> 19) ^ gamma1x >>> 10;
        W[i] = gamma0 + W[i - 7] + gamma1 + W[i - 16];
      }
      const ch = e & f ^ ~e & g;
      const maj = a & b ^ a & c ^ b & c;
      const sigma0 = (a << 30 | a >>> 2) ^ (a << 19 | a >>> 13) ^ (a << 10 | a >>> 22);
      const sigma1 = (e << 26 | e >>> 6) ^ (e << 21 | e >>> 11) ^ (e << 7 | e >>> 25);
      const t1 = h2 + sigma1 + ch + K[i] + W[i];
      const t2 = sigma0 + maj;
      h2 = g;
      g = f;
      f = e;
      e = d + t1 | 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 | 0;
    }
    H2[0] = H2[0] + a | 0;
    H2[1] = H2[1] + b | 0;
    H2[2] = H2[2] + c | 0;
    H2[3] = H2[3] + d | 0;
    H2[4] = H2[4] + e | 0;
    H2[5] = H2[5] + f | 0;
    H2[6] = H2[6] + g | 0;
    H2[7] = H2[7] + h2 | 0;
  }
  finalize(messageUpdate) {
    super.finalize(messageUpdate);
    const nBitsTotal = this._nDataBytes * 8;
    const nBitsLeft = this._data.sigBytes * 8;
    this._data.words[nBitsLeft >>> 5] |= 128 << 24 - nBitsLeft % 32;
    this._data.words[(nBitsLeft + 64 >>> 9 << 4) + 14] = Math.floor(
      nBitsTotal / 4294967296
    );
    this._data.words[(nBitsLeft + 64 >>> 9 << 4) + 15] = nBitsTotal;
    this._data.sigBytes = this._data.words.length * 4;
    this._process();
    return this._hash;
  }
}
function sha256base64(message) {
  return new SHA256().finalize(message).toString(Base64);
}
function hash(object, options2 = {}) {
  const hashed = typeof object === "string" ? object : objectHash(object, options2);
  return sha256base64(hashed).slice(0, 10);
}
const ProductId = "#product";
const productResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Product"
  },
  inheritMeta: [
    "description",
    "image",
    { meta: "title", key: "name" }
  ],
  idPrefix: ["url", ProductId],
  resolve(node, ctx) {
    setIfEmpty(node, "sku", hash(node.name));
    node.aggregateOffer = resolveRelation(node.aggregateOffer, ctx, aggregateOfferResolver);
    node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
    node.offers = resolveRelation(node.offers, ctx, offerResolver);
    node.review = resolveRelation(node.review, ctx, reviewResolver);
    return node;
  },
  resolveRootNode(product, { find }) {
    const webPage = find(PrimaryWebPageId);
    const identity = find(IdentityId);
    if (identity)
      setIfEmpty(product, "brand", idReference(identity));
    if (webPage)
      setIfEmpty(product, "mainEntityOfPage", idReference(webPage));
    return product;
  }
});
const answerResolver = defineSchemaOrgResolver({
  cast(node) {
    if (typeof node === "string") {
      return {
        text: node
      };
    }
    return node;
  },
  defaults: {
    "@type": "Answer"
  }
});
const questionResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Question"
  },
  inheritMeta: [
    "inLanguage"
  ],
  idPrefix: "url",
  resolve(question, ctx) {
    if (question.question) {
      question.name = question.question;
      delete question.question;
    }
    if (question.answer) {
      question.acceptedAnswer = question.answer;
      delete question.answer;
    }
    question.acceptedAnswer = resolveRelation(question.acceptedAnswer, ctx, answerResolver);
    return question;
  },
  resolveRootNode(question, { find }) {
    const webPage = find(PrimaryWebPageId);
    if (webPage && asArray(webPage["@type"]).includes("FAQPage"))
      dedupeMerge(webPage, "mainEntity", idReference(question));
  }
});
const RecipeId = "#recipe";
const recipeResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "Recipe"
  },
  inheritMeta: [
    { meta: "title", key: "name" },
    "description",
    "image",
    "datePublished"
  ],
  idPrefix: ["url", RecipeId],
  resolve(node, ctx) {
    node.recipeInstructions = resolveRelation(node.recipeInstructions, ctx, howToStepResolver);
    return node;
  },
  resolveRootNode(node, { find }) {
    const article = find(PrimaryArticleId);
    const webPage = find(PrimaryWebPageId);
    if (article)
      setIfEmpty(node, "mainEntityOfPage", idReference(article));
    else if (webPage)
      setIfEmpty(node, "mainEntityOfPage", idReference(webPage));
    if (article == null ? void 0 : article.author)
      setIfEmpty(node, "author", article.author);
    return node;
  }
});
const softwareAppResolver = defineSchemaOrgResolver({
  defaults: {
    "@type": "SoftwareApplication"
  },
  resolve(node, ctx) {
    resolveDefaultType(node, "SoftwareApplication");
    node.offers = resolveRelation(node.offers, ctx, offerResolver);
    node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
    node.review = resolveRelation(node.review, ctx, reviewResolver);
    return node;
  }
});
function loadResolver(resolver2) {
  switch (resolver2) {
    case "address":
      return addressResolver;
    case "aggregateOffer":
      return aggregateOfferResolver;
    case "aggregateRating":
      return aggregateRatingResolver;
    case "article":
      return articleResolver;
    case "breadcrumb":
      return breadcrumbResolver;
    case "comment":
      return commentResolver;
    case "event":
      return eventResolver;
    case "foodEstablishment":
      return foodEstablishmentResolver;
    case "virtualLocation":
      return virtualLocationResolver;
    case "place":
      return placeResolver;
    case "howTo":
      return howToResolver;
    case "howToStep":
      return howToStepResolver;
    case "image":
      return imageResolver;
    case "localBusiness":
      return localBusinessResolver;
    case "offer":
      return offerResolver;
    case "openingHours":
      return openingHoursResolver;
    case "organization":
      return organizationResolver;
    case "person":
      return personResolver;
    case "product":
      return productResolver;
    case "question":
      return questionResolver;
    case "recipe":
      return recipeResolver;
    case "review":
      return reviewResolver;
    case "video":
      return videoResolver;
    case "webPage":
      return webPageResolver;
    case "webSite":
      return webSiteResolver;
    case "book":
      return bookResolver;
    case "course":
      return courseResolver;
    case "itemList":
      return itemListResolver;
    case "jobPosting":
      return jobPostingResolver;
    case "listItem":
      return listItemResolver;
    case "movie":
      return movieResolver;
    case "searchAction":
      return searchActionResolver;
    case "readAction":
      return readActionResolver;
    case "softwareApp":
      return softwareAppResolver;
    case "bookEdition":
      return bookEditionResolver;
  }
  return null;
}
const resolver = {
  __proto__: null,
  loadResolver
};
function resolveMeta(meta) {
  if (!meta.host && meta.canonicalHost)
    meta.host = meta.canonicalHost;
  if (!meta.tagPosition && meta.position)
    meta.tagPosition = meta.position;
  if (!meta.currency && meta.defaultCurrency)
    meta.currency = meta.defaultCurrency;
  if (!meta.inLanguage && meta.defaultLanguage)
    meta.inLanguage = meta.defaultLanguage;
  if (!meta.path)
    meta.path = "/";
  if (!meta.host && false)
    meta.host = (void 0).location.host;
  if (!meta.url && meta.canonicalUrl)
    meta.url = meta.canonicalUrl;
  if (meta.path !== "/") {
    if (meta.trailingSlash && !hasTrailingSlash$1(meta.path))
      meta.path = withTrailingSlash$1(meta.path);
    else if (!meta.trailingSlash && hasTrailingSlash$1(meta.path))
      meta.path = withoutTrailingSlash$1(meta.path);
  }
  meta.url = joinURL(meta.host || "", meta.path);
  return {
    ...meta,
    host: meta.host,
    url: meta.url,
    currency: meta.currency,
    image: meta.image,
    inLanguage: meta.inLanguage,
    title: meta.title,
    description: meta.description,
    datePublished: meta.datePublished,
    dateModified: meta.dateModified
  };
}
function resolveNode(node, ctx, resolver2) {
  var _a;
  if (resolver2 == null ? void 0 : resolver2.cast)
    node = resolver2.cast(node, ctx);
  if (resolver2 == null ? void 0 : resolver2.defaults) {
    let defaults2 = resolver2.defaults || {};
    if (typeof defaults2 === "function")
      defaults2 = defaults2(ctx);
    node = {
      ...defaults2,
      ...node
    };
  }
  (_a = resolver2.inheritMeta) == null ? void 0 : _a.forEach((entry2) => {
    if (typeof entry2 === "string")
      setIfEmpty(node, entry2, ctx.meta[entry2]);
    else
      setIfEmpty(node, entry2.key, ctx.meta[entry2.meta]);
  });
  if (resolver2 == null ? void 0 : resolver2.resolve)
    node = resolver2.resolve(node, ctx);
  for (const k2 in node) {
    const v = node[k2];
    if (typeof v === "object" && (v == null ? void 0 : v._resolver))
      node[k2] = resolveRelation(v, ctx, v._resolver);
  }
  stripEmptyProperties(node);
  return node;
}
function resolveNodeId(node, ctx, resolver2, resolveAsRoot = false) {
  var _a, _b, _c;
  if (node["@id"] && node["@id"].startsWith("http"))
    return node;
  const prefix = (Array.isArray(resolver2.idPrefix) ? resolver2.idPrefix[0] : resolver2.idPrefix) || "url";
  const rootId = node["@id"] || (Array.isArray(resolver2.idPrefix) ? (_a = resolver2.idPrefix) == null ? void 0 : _a[1] : void 0);
  if (!node["@id"] && resolveAsRoot && rootId) {
    node["@id"] = prefixId(ctx.meta[prefix], rootId);
    return node;
  }
  if ((_b = node["@id"]) == null ? void 0 : _b.startsWith("#/schema/")) {
    node["@id"] = prefixId(ctx.meta[prefix], node["@id"]);
    return node;
  }
  let alias = resolver2 == null ? void 0 : resolver2.alias;
  if (!alias) {
    const type = ((_c = asArray(node["@type"])) == null ? void 0 : _c[0]) || "";
    alias = type.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
  }
  const hashNodeData = {};
  Object.entries(node).forEach(([key, val]) => {
    if (!key.startsWith("_"))
      hashNodeData[key] = val;
  });
  node["@id"] = prefixId(ctx.meta[prefix], `#/schema/${alias}/${node["@id"] || hashCode(JSON.stringify(hashNodeData))}`);
  return node;
}
function resolveRelation(input, ctx, fallbackResolver, options2 = {}) {
  if (!input)
    return input;
  const ids = asArray(input).map((a) => {
    var _a;
    const keys = Object.keys(a).length;
    if (keys === 1 && a["@id"] || keys === 2 && a["@id"] && a["@type"]) {
      return {
        // we drop @type
        "@id": ((_a = ctx.find(a["@id"])) == null ? void 0 : _a["@id"]) || a["@id"]
      };
    }
    let resolver2 = fallbackResolver;
    if (a._resolver) {
      resolver2 = a._resolver;
      if (typeof resolver2 === "string")
        resolver2 = loadResolver(resolver2);
      delete a._resolver;
    }
    if (!resolver2)
      return a;
    let node = resolveNode(a, ctx, resolver2);
    if (options2.afterResolve)
      options2.afterResolve(node);
    if (options2.generateId || options2.root)
      node = resolveNodeId(node, ctx, resolver2, false);
    if (options2.root) {
      if (resolver2.resolveRootNode)
        resolver2.resolveRootNode(node, ctx);
      ctx.push(node);
      return idReference(node["@id"]);
    }
    return node;
  });
  if (!options2.array && ids.length === 1)
    return ids[0];
  return ids;
}
function _defu(baseObject, defaults2, namespace = ".", merger) {
  if (!_isPlainObject(defaults2)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = Object.assign({}, defaults2);
  for (const key in baseObject) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (_isPlainObject(value) && _isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function _isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  return (prototype === null || prototype === Object.prototype || Object.getPrototypeOf(prototype) === null) && !(Symbol.toStringTag in value) && !(Symbol.iterator in value);
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p2, c) => _defu(p2, c, "", merger), {})
  );
}
function groupBy(array, predicate) {
  return array.reduce((acc, value, index, array2) => {
    const key = predicate(value, index, array2);
    if (!acc[key])
      acc[key] = [];
    acc[key].push(value);
    return acc;
  }, {});
}
function uniqueBy(array, predicate) {
  return Object.values(groupBy(array, predicate)).map((a) => a[a.length - 1]);
}
const merge = createDefu((object, key, value) => {
  if (Array.isArray(object[key])) {
    object[key] = [.../* @__PURE__ */ new Set([...object[key], ...value])];
    if (key === "itemListElement") {
      object[key] = [...uniqueBy(object[key], (item) => item.position)];
    }
    return true;
  }
});
function dedupeNodes(nodes) {
  const dedupedNodes = {};
  for (const key of nodes.keys()) {
    const n = nodes[key];
    const nodeKey = resolveAsGraphKey(n["@id"] || hash(n));
    if (dedupedNodes[nodeKey])
      dedupedNodes[nodeKey] = merge(nodes[key], dedupedNodes[nodeKey]);
    else
      dedupedNodes[nodeKey] = nodes[key];
  }
  return Object.values(dedupedNodes);
}
function normaliseNodes(nodes) {
  const sortedNodeKeys = nodes.keys();
  const dedupedNodes = {};
  for (const key of sortedNodeKeys) {
    const n = nodes[key];
    const nodeKey = resolveAsGraphKey(n["@id"] || hash(n));
    const groupedKeys = groupBy(Object.keys(n), (key2) => {
      const val = n[key2];
      if (key2.startsWith("_"))
        return "ignored";
      if (Array.isArray(val) || typeof val === "object")
        return "relations";
      return "primitives";
    });
    const keys = [
      ...(groupedKeys.primitives || []).sort(),
      ...(groupedKeys.relations || []).sort()
    ];
    let newNode = {};
    for (const key2 of keys)
      newNode[key2] = n[key2];
    if (dedupedNodes[nodeKey])
      newNode = merge(newNode, dedupedNodes[nodeKey]);
    dedupedNodes[nodeKey] = newNode;
  }
  return Object.values(dedupedNodes);
}
function createSchemaOrgGraph() {
  const ctx = {
    find(id) {
      const key = resolveAsGraphKey(id);
      return ctx.nodes.filter((n) => !!n["@id"]).find((n) => resolveAsGraphKey(n["@id"]) === key);
    },
    push(input) {
      asArray(input).forEach((node) => {
        const registeredNode = node;
        ctx.nodes.push(registeredNode);
      });
    },
    resolveGraph(meta) {
      ctx.meta = resolveMeta({ ...meta });
      ctx.nodes.forEach((node, key) => {
        const resolver2 = node._resolver;
        if (resolver2) {
          node = resolveNode(node, ctx, resolver2);
          node = resolveNodeId(node, ctx, resolver2, true);
        }
        ctx.nodes[key] = node;
      });
      ctx.nodes = dedupeNodes(ctx.nodes);
      ctx.nodes.forEach((node) => {
        var _a;
        if (node.image && typeof node.image === "string") {
          node.image = resolveRelation(node.image, ctx, imageResolver, {
            root: true
          });
        }
        if ((_a = node._resolver) == null ? void 0 : _a.resolveRootNode)
          node._resolver.resolveRootNode(node, ctx);
        delete node._resolver;
      });
      return normaliseNodes(ctx.nodes);
    },
    nodes: [],
    meta: {}
  };
  return ctx;
}
function SchemaOrgUnheadPlugin(config, meta, options2) {
  config = resolveMeta({ ...config });
  let graph;
  let resolvedMeta = {};
  return defineHeadPlugin((head) => ({
    key: "schema-org",
    hooks: {
      "entries:resolve": function() {
        graph = createSchemaOrgGraph();
      },
      "tag:normalise": async function({ tag }) {
        if (tag.key === "schema-org-graph") {
          const { loadResolver: loadResolver2 } = await Promise.resolve().then(function() {
            return resolver;
          });
          const nodes = await tag.props.nodes;
          for (const node of Array.isArray(nodes) ? nodes : [nodes]) {
            const newNode = {
              ...node,
              _resolver: loadResolver2(await node._resolver)
            };
            graph.push(newNode);
          }
          tag.tagPosition = tag.tagPosition || config.tagPosition === "head" ? "head" : "bodyClose";
        }
        if (tag.tag === "htmlAttrs" && tag.props.lang) {
          resolvedMeta.inLanguage = tag.props.lang;
        } else if (tag.tag === "title") {
          resolvedMeta.title = tag.textContent;
        } else if (tag.tag === "meta" && tag.props.name === "description") {
          resolvedMeta.description = tag.props.content;
        } else if (tag.tag === "link" && tag.props.rel === "canonical") {
          resolvedMeta.url = tag.props.href;
          if (resolvedMeta.url && !resolvedMeta.host) {
            try {
              resolvedMeta.host = new URL(resolvedMeta.url).origin;
            } catch {
            }
          }
        } else if (tag.tag === "meta" && tag.props.property === "og:image") {
          resolvedMeta.image = tag.props.content;
        } else if (tag.tag === "templateParams" && tag.props.schemaOrg) {
          resolvedMeta = {
            ...resolvedMeta,
            // @ts-expect-error untyped
            ...tag.props.schemaOrg
          };
          delete tag.props.schemaOrg;
        }
      },
      "tags:resolve": async function(ctx) {
        for (const tag of ctx.tags) {
          if (tag.tag === "script" && tag.key === "schema-org-graph") {
            const minify2 = (options2 == null ? void 0 : options2.minify) || "production" === "production";
            tag.innerHTML = JSON.stringify({
              "@context": "https://schema.org",
              "@graph": graph.resolveGraph({ ...await (meta == null ? void 0 : meta()) || {}, ...config, ...resolvedMeta })
            }, (_, value) => {
              if (typeof value !== "object")
                return processTemplateParams(value, head._templateParams, head._separator);
              return value;
            }, minify2 ? 0 : 2);
            delete tag.props.nodes;
            return;
          }
        }
      }
    }
  }));
}
function provideResolver(input, resolver2) {
  if (!input)
    input = {};
  input._resolver = resolver2;
  return input;
}
function defineOrganization(input) {
  return provideResolver(input, "organization");
}
function definePerson(input) {
  return provideResolver(input, "person");
}
function defineWebPage(input) {
  return provideResolver(input, "webPage");
}
function defineWebSite(input) {
  return provideResolver(input, "webSite");
}
function useSchemaOrg(input) {
  const config = (/* @__PURE__ */ useRuntimeConfig())["nuxt-schema-org"] || (/* @__PURE__ */ useRuntimeConfig()).public["nuxt-schema-org"];
  const script = {
    type: "application/ld+json",
    key: "schema-org-graph",
    nodes: input,
    ...(config == null ? void 0 : config.scriptAttributes) || {}
  };
  {
    return useServerHead({
      script: [script]
    });
  }
}
const defaults_dOQDx4xFky = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt-schema-org:defaults",
  setup() {
    const runtimeConfig = (/* @__PURE__ */ useRuntimeConfig())["nuxt-schema-org"] || (/* @__PURE__ */ useRuntimeConfig()).public["nuxt-schema-org"];
    const siteConfig = useSiteConfig();
    useSchemaOrg([
      defineWebSite({
        name: () => (siteConfig == null ? void 0 : siteConfig.name) || "",
        // TODO integrate with nuxt/i18n
        inLanguage: () => (siteConfig == null ? void 0 : siteConfig.currentLocale) || "",
        description: () => (siteConfig == null ? void 0 : siteConfig.description) || ""
      }),
      defineWebPage()
    ]);
    if (runtimeConfig.identity || siteConfig.identity) {
      const identity = runtimeConfig.identity || siteConfig.identity;
      let identityPayload = {
        name: siteConfig.name,
        url: siteConfig.url
      };
      let identityType = "Organization";
      if (typeof identity !== "string") {
        identityPayload = defu(identity, identityPayload);
        identityType = identity.type;
      } else {
        identityType = identity;
      }
      if (siteConfig.twitter) {
        const id = siteConfig.twitter.startsWith("@") ? siteConfig.twitter.slice(1) : siteConfig.twitter;
        identityPayload.sameAs = [
          `https://twitter.com/${id}`
        ];
      }
      useSchemaOrg([
        identityType === "Person" ? definePerson(identityPayload) : defineOrganization(identityPayload)
      ]);
    }
  }
});
function isInternalRoute(path) {
  const lastSegment = path.split("/").pop() || path;
  return lastSegment.includes(".") || path.startsWith("/__") || path.startsWith("@");
}
function filterIsOgImageOption(key) {
  const keys = [
    "url",
    "extension",
    "width",
    "height",
    "fonts",
    "alt",
    "props",
    "renderer",
    "html",
    "component",
    "renderer",
    "emojis",
    "_query",
    "satori",
    "resvg",
    "sharp",
    "screenshot",
    "cacheMaxAgeSeconds"
  ];
  return keys.includes(key);
}
function separateProps(options2, ignoreKeys = []) {
  options2 = options2 || {};
  const _props = defu(options2.props, Object.fromEntries(
    Object.entries({ ...options2 }).filter(([k2]) => !filterIsOgImageOption(k2) && !ignoreKeys.includes(k2))
  ));
  const props = {};
  Object.entries(_props).forEach(([key, val]) => {
    props[key.replace(/-([a-z])/g, (g) => g[1].toUpperCase())] = val;
  });
  return {
    ...Object.fromEntries(
      Object.entries({ ...options2 }).filter(([k2]) => filterIsOgImageOption(k2) || ignoreKeys.includes(k2))
    ),
    props
  };
}
function withoutQuery(path) {
  return path.split("?")[0];
}
function getExtension(path) {
  path = withoutQuery(path);
  const lastSegment = path.split("/").pop() || path;
  return lastSegment.split(".").pop() || lastSegment;
}
const og_image_canonical_urls_server_EgfbWs4KJr = /* @__PURE__ */ defineNuxtPlugin({
  setup(nuxtApp) {
    nuxtApp.hooks.hook("app:rendered", async (ctx) => {
      const { ssrContext } = ctx;
      const e = useRequestEvent();
      const path = parseURL(e.path).pathname;
      if (isInternalRoute(path))
        return;
      ssrContext == null ? void 0 : ssrContext.head.use({
        key: "nuxt-og-image:overrides-and-canonical-urls",
        hooks: {
          "tags:resolve": async (ctx2) => {
            const hasPrimaryPayload = ctx2.tags.some((tag) => tag.tag === "script" && tag.props.id === "nuxt-og-image-options");
            let overrides;
            for (const tag of ctx2.tags) {
              if (tag.tag === "script" && tag.props.id === "nuxt-og-image-overrides") {
                if (hasPrimaryPayload) {
                  overrides = separateProps(JSON.parse(tag.innerHTML || "{}"));
                  delete ctx2.tags[ctx2.tags.indexOf(tag)];
                } else {
                  tag.props.id = "nuxt-og-image-options";
                  tag.innerHTML = JSON.stringify(separateProps(JSON.parse(tag.innerHTML || "{}")));
                  tag._d = "script:id:nuxt-og-image-options";
                }
                break;
              }
            }
            ctx2.tags = ctx2.tags.filter(Boolean);
            for (const tag of ctx2.tags) {
              if (tag.tag === "meta" && (tag.props.property === "og:image" || tag.props.name === "twitter:image:src")) {
                if (!tag.props.content.startsWith("https")) {
                  await nuxtApp.runWithContext(() => {
                    tag.props.content = toValue(withSiteUrl(tag.props.content));
                  });
                }
              } else if (overrides && tag.tag === "script" && tag.props.id === "nuxt-og-image-options") {
                tag.innerHTML = JSON.stringify(defu(overrides, JSON.parse(tag.innerHTML)));
              }
            }
          }
        }
      });
    });
  }
});
function getOgImagePath(pagePath, _options) {
  const options2 = defu(_options, useOgImageRuntimeConfig().defaults);
  return joinURL("/__og-image__/image", pagePath, `og.${options2.extension}`);
}
function useOgImageRuntimeConfig() {
  return (/* @__PURE__ */ useRuntimeConfig())["nuxt-og-image"];
}
const componentNames = [{ "hash": "i0Vxmj8bqg", "pascalName": "BrandedLogo", "kebabName": "branded-logo", "category": "community", "credits": "Full Stack Heroes <https://fullstackheroes.com/>" }, { "hash": "EtP6PjHVxf", "pascalName": "Nuxt", "kebabName": "nuxt", "category": "community", "credits": "NuxtLabs <https://nuxtlabs.com/>" }, { "hash": "pc4vJGC02t", "pascalName": "NuxtSeo", "kebabName": "nuxt-seo", "category": "community", "credits": "Nuxt SEO <https://nuxtseo.com/>" }, { "hash": "KfQI8hATPp", "pascalName": "Pergel", "kebabName": "pergel", "category": "community", "credits": "Pergel <https://nuxtlabs.com/>" }, { "hash": "YDrRRvPRVl", "pascalName": "SimpleBlog", "kebabName": "simple-blog", "category": "community", "credits": "Full Stack Heroes <https://fullstackheroes.com/>" }, { "hash": "wt558K6QyQ", "pascalName": "UnJs", "kebabName": "un-js", "category": "community", "credits": "UnJS <https://unjs.io/>" }, { "hash": "6RdQZcuwZZ", "pascalName": "Wave", "kebabName": "wave", "category": "community", "credits": "Full Stack Heroes <https://fullstackheroes.com/>" }, { "hash": "gaB1TrbtTl", "pascalName": "WithEmoji", "kebabName": "with-emoji", "category": "community", "credits": "Full Stack Heroes <https://fullstackheroes.com/>" }];
function createOgImageMeta(src, input, resolvedOptions, ssrContext) {
  const _input = separateProps(defu(input, ssrContext._ogImagePayload));
  let url = src || input.url || resolvedOptions.url;
  if (!url)
    return;
  if (input._query && Object.keys(input._query).length && url)
    url = withQuery(url, { _query: input._query });
  let urlExtension = getExtension(url) || resolvedOptions.extension;
  if (urlExtension === "jpg")
    urlExtension = "jpeg";
  const meta = [
    { property: "og:image", content: url },
    { property: "og:image:type", content: `image/${urlExtension}` },
    { name: "twitter:card", content: "summary_large_image" },
    // we don't need this but avoids issue when using useSeoMeta({ twitterImage })
    { name: "twitter:image", content: url },
    { name: "twitter:image:src", content: url }
  ];
  if (resolvedOptions.width) {
    meta.push({ property: "og:image:width", content: resolvedOptions.width });
    meta.push({ name: "twitter:image:width", content: resolvedOptions.width });
  }
  if (resolvedOptions.height) {
    meta.push({ property: "og:image:height", content: resolvedOptions.height });
    meta.push({ name: "twitter:image:height", content: resolvedOptions.height });
  }
  if (resolvedOptions.alt) {
    meta.push({ property: "og:image:alt", content: resolvedOptions.alt });
    meta.push({ name: "twitter:image:alt", content: resolvedOptions.alt });
  }
  ssrContext._ogImageInstances = ssrContext._ogImageInstances || [];
  const script = [];
  if (src) {
    script.push({
      id: "nuxt-og-image-options",
      type: "application/json",
      processTemplateParams: true,
      innerHTML: () => {
        if (!_input.props.title)
          _input.props.title = "%s";
        delete _input.url;
        return _input;
      },
      // we want this to be last in our head
      tagPosition: "bodyClose"
    });
  }
  const instance = useServerHead({
    script,
    meta
  }, {
    tagPriority: 35
  });
  ssrContext._ogImagePayload = _input;
  ssrContext._ogImageInstances.push(instance);
}
function normaliseOptions(_options) {
  const options2 = { ...unref(_options) };
  if (!options2)
    return options2;
  if (options2.component && componentNames) {
    const originalName = options2.component;
    for (const component of componentNames) {
      if (component.pascalName.endsWith(originalName) || component.kebabName.endsWith(originalName)) {
        options2.component = component.pascalName;
        break;
      }
    }
  }
  return options2;
}
const route_rule_og_image_server_NjzMbK7oJI = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  nuxtApp.hooks.hook("app:rendered", async (ctx) => {
    var _a, _b, _c, _d, _e, _f;
    const { ssrContext } = ctx;
    const e = useRequestEvent();
    const path = parseURL(e.path).pathname;
    if (isInternalRoute(path))
      return;
    const _routeRulesMatcher = toRouteMatcher(
      createRouter$1({ routes: (_b = (_a = ssrContext == null ? void 0 : ssrContext.runtimeConfig) == null ? void 0 : _a.nitro) == null ? void 0 : _b.routeRules })
    );
    let routeRules = defu({}, ..._routeRulesMatcher.matchAll(
      withoutBase(path.split("?")[0], (_c = ssrContext == null ? void 0 : ssrContext.runtimeConfig) == null ? void 0 : _c.app.baseURL)
    ).reverse()).ogImage;
    if (typeof routeRules === "undefined")
      return;
    const ogImageInstances = nuxtApp.ssrContext._ogImageInstances || [];
    if (routeRules === false) {
      ogImageInstances == null ? void 0 : ogImageInstances.forEach((e2) => {
        e2.dispose();
      });
      nuxtApp.ssrContext._ogImagePayload = void 0;
      nuxtApp.ssrContext._ogImageInstances = void 0;
      return;
    }
    routeRules = defu((_f = (_e = (_d = nuxtApp.ssrContext) == null ? void 0 : _d.event.context._nitro) == null ? void 0 : _e.routeRules) == null ? void 0 : _f.ogImage, routeRules);
    const { defaults: defaults2 } = useOgImageRuntimeConfig();
    const resolvedOptions = normaliseOptions(defu(routeRules, defaults2));
    const src = getOgImagePath(ssrContext.url, resolvedOptions);
    createOgImageMeta(src, routeRules, resolvedOptions, nuxtApp.ssrContext);
  });
});
const robot_meta_server_5dG6q8tTdi = /* @__PURE__ */ defineNuxtPlugin({
  setup() {
    const event = useRequestEvent();
    const ctx = event.context.robots;
    if (!ctx)
      return;
    useServerHead({
      meta: [
        {
          "name": "robots",
          "content": () => ctx.rule || "",
          "data-hint": void 0
        }
      ]
    });
  }
});
function updateSiteConfig(input = {}) {
  {
    const stack = useRequestEvent().context.siteConfig;
    stack.push(input);
    return;
  }
}
const i18n_server_eydIu9K4Cx = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt-site-config:i18n",
  // @ts-expect-error untyped
  dependsOn: ["i18n:plugin"],
  setup(nuxtApp) {
    const i18n = nuxtApp.$i18n;
    if (!i18n)
      return;
    useSiteConfig().url;
    try {
      const url = parseURL(i18n.baseUrl.value);
      if (false)
        ;
    } catch {
    }
    updateSiteConfig({
      _priority: -1,
      _context: "@nuxtjs/i18n",
      url: void 0,
      // @ts-expect-error untyped
      currentLocale: i18n.locale,
      // @ts-expect-error untyped
      description: computed(() => i18n.te("nuxtSiteConfig.description") ? i18n.t("nuxtSiteConfig.description") : void 0),
      // @ts-expect-error untyped
      name: computed(() => i18n.te("nuxtSiteConfig.name") ? i18n.t("nuxtSiteConfig.name") : void 0)
    });
  }
});
const composition_nLOleWny7F = /* @__PURE__ */ defineNuxtPlugin(() => {
});
/*!
  * shared v9.8.0
  * (c) 2023 kazuya kawaguchi
  * Released under the MIT License.
  */
const inBrowser = false;
const makeSymbol$1 = (name, shareable = false) => !shareable ? Symbol(name) : Symbol.for(name);
const generateFormatCacheKey = (locale, key, source) => friendlyJSONstringify({ l: locale, k: key, s: source });
const friendlyJSONstringify = (json) => JSON.stringify(json).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029").replace(/\u0027/g, "\\u0027");
const isNumber = (val) => typeof val === "number" && isFinite(val);
const isDate = (val) => toTypeString(val) === "[object Date]";
const isRegExp = (val) => toTypeString(val) === "[object RegExp]";
const isEmptyObject = (val) => isPlainObject(val) && Object.keys(val).length === 0;
const assign$1 = Object.assign;
function escapeHtml(rawText) {
  return rawText.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
const hasOwnProperty = Object.prototype.hasOwnProperty;
function hasOwn(obj, key) {
  return hasOwnProperty.call(obj, key);
}
const isArray$1 = Array.isArray;
const isFunction$1 = (val) => typeof val === "function";
const isString$1 = (val) => typeof val === "string";
const isBoolean = (val) => typeof val === "boolean";
const isObject$1 = (val) => val !== null && typeof val === "object";
const isPromise = (val) => {
  return isObject$1(val) && isFunction$1(val.then) && isFunction$1(val.catch);
};
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);
const isPlainObject = (val) => {
  if (!isObject$1(val))
    return false;
  const proto = Object.getPrototypeOf(val);
  return proto === null || proto.constructor === Object;
};
const toDisplayString = (val) => {
  return val == null ? "" : isArray$1(val) || isPlainObject(val) && val.toString === objectToString ? JSON.stringify(val, null, 2) : String(val);
};
function join(items, separator = "") {
  return items.reduce((str, item, index) => index === 0 ? str + item : str + separator + item, "");
}
function incrementer(code2) {
  let current = code2;
  return () => ++current;
}
function warn$1(msg, err) {
  if (typeof console !== "undefined") {
    console.warn(`[intlify] ` + msg);
    if (err) {
      console.warn(err.stack);
    }
  }
}
const isNotObjectOrIsArray = (val) => !isObject$1(val) || isArray$1(val);
function deepCopy(src, des) {
  if (isNotObjectOrIsArray(src) || isNotObjectOrIsArray(des)) {
    throw new Error("Invalid value");
  }
  for (const key in src) {
    if (hasOwn(src, key)) {
      if (isNotObjectOrIsArray(src[key]) || isNotObjectOrIsArray(des[key])) {
        des[key] = src[key];
      } else {
        deepCopy(src[key], des[key]);
      }
    }
  }
}
/*!
  * message-compiler v9.8.0
  * (c) 2023 kazuya kawaguchi
  * Released under the MIT License.
  */
function createPosition(line, column, offset) {
  return { line, column, offset };
}
function createLocation(start, end, source) {
  const loc = { start, end };
  if (source != null) {
    loc.source = source;
  }
  return loc;
}
const CompileErrorCodes = {
  // tokenizer error codes
  EXPECTED_TOKEN: 1,
  INVALID_TOKEN_IN_PLACEHOLDER: 2,
  UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER: 3,
  UNKNOWN_ESCAPE_SEQUENCE: 4,
  INVALID_UNICODE_ESCAPE_SEQUENCE: 5,
  UNBALANCED_CLOSING_BRACE: 6,
  UNTERMINATED_CLOSING_BRACE: 7,
  EMPTY_PLACEHOLDER: 8,
  NOT_ALLOW_NEST_PLACEHOLDER: 9,
  INVALID_LINKED_FORMAT: 10,
  // parser error codes
  MUST_HAVE_MESSAGES_IN_PLURAL: 11,
  UNEXPECTED_EMPTY_LINKED_MODIFIER: 12,
  UNEXPECTED_EMPTY_LINKED_KEY: 13,
  UNEXPECTED_LEXICAL_ANALYSIS: 14,
  // generator error codes
  UNHANDLED_CODEGEN_NODE_TYPE: 15,
  // minifier error codes
  UNHANDLED_MINIFIER_NODE_TYPE: 16,
  // Special value for higher-order compilers to pick up the last code
  // to avoid collision of error codes. This should always be kept as the last
  // item.
  __EXTEND_POINT__: 17
};
function createCompileError(code2, loc, options2 = {}) {
  const { domain, messages, args } = options2;
  const msg = code2;
  const error = new SyntaxError(String(msg));
  error.code = code2;
  if (loc) {
    error.location = loc;
  }
  error.domain = domain;
  return error;
}
function defaultOnError(error) {
  throw error;
}
const CHAR_SP = " ";
const CHAR_CR = "\r";
const CHAR_LF = "\n";
const CHAR_LS = String.fromCharCode(8232);
const CHAR_PS = String.fromCharCode(8233);
function createScanner(str) {
  const _buf = str;
  let _index = 0;
  let _line = 1;
  let _column = 1;
  let _peekOffset = 0;
  const isCRLF = (index2) => _buf[index2] === CHAR_CR && _buf[index2 + 1] === CHAR_LF;
  const isLF = (index2) => _buf[index2] === CHAR_LF;
  const isPS = (index2) => _buf[index2] === CHAR_PS;
  const isLS = (index2) => _buf[index2] === CHAR_LS;
  const isLineEnd = (index2) => isCRLF(index2) || isLF(index2) || isPS(index2) || isLS(index2);
  const index = () => _index;
  const line = () => _line;
  const column = () => _column;
  const peekOffset = () => _peekOffset;
  const charAt = (offset) => isCRLF(offset) || isPS(offset) || isLS(offset) ? CHAR_LF : _buf[offset];
  const currentChar = () => charAt(_index);
  const currentPeek = () => charAt(_index + _peekOffset);
  function next() {
    _peekOffset = 0;
    if (isLineEnd(_index)) {
      _line++;
      _column = 0;
    }
    if (isCRLF(_index)) {
      _index++;
    }
    _index++;
    _column++;
    return _buf[_index];
  }
  function peek() {
    if (isCRLF(_index + _peekOffset)) {
      _peekOffset++;
    }
    _peekOffset++;
    return _buf[_index + _peekOffset];
  }
  function reset() {
    _index = 0;
    _line = 1;
    _column = 1;
    _peekOffset = 0;
  }
  function resetPeek(offset = 0) {
    _peekOffset = offset;
  }
  function skipToPeek() {
    const target = _index + _peekOffset;
    while (target !== _index) {
      next();
    }
    _peekOffset = 0;
  }
  return {
    index,
    line,
    column,
    peekOffset,
    charAt,
    currentChar,
    currentPeek,
    next,
    peek,
    reset,
    resetPeek,
    skipToPeek
  };
}
const EOF = void 0;
const DOT = ".";
const LITERAL_DELIMITER = "'";
const ERROR_DOMAIN$3 = "tokenizer";
function createTokenizer(source, options2 = {}) {
  const location = options2.location !== false;
  const _scnr = createScanner(source);
  const currentOffset = () => _scnr.index();
  const currentPosition = () => createPosition(_scnr.line(), _scnr.column(), _scnr.index());
  const _initLoc = currentPosition();
  const _initOffset = currentOffset();
  const _context = {
    currentType: 14,
    offset: _initOffset,
    startLoc: _initLoc,
    endLoc: _initLoc,
    lastType: 14,
    lastOffset: _initOffset,
    lastStartLoc: _initLoc,
    lastEndLoc: _initLoc,
    braceNest: 0,
    inLinked: false,
    text: ""
  };
  const context = () => _context;
  const { onError } = options2;
  function emitError(code2, pos, offset, ...args) {
    const ctx = context();
    pos.column += offset;
    pos.offset += offset;
    if (onError) {
      const loc = location ? createLocation(ctx.startLoc, pos) : null;
      const err = createCompileError(code2, loc, {
        domain: ERROR_DOMAIN$3,
        args
      });
      onError(err);
    }
  }
  function getToken(context2, type, value) {
    context2.endLoc = currentPosition();
    context2.currentType = type;
    const token = { type };
    if (location) {
      token.loc = createLocation(context2.startLoc, context2.endLoc);
    }
    if (value != null) {
      token.value = value;
    }
    return token;
  }
  const getEndToken = (context2) => getToken(
    context2,
    14
    /* TokenTypes.EOF */
  );
  function eat(scnr, ch) {
    if (scnr.currentChar() === ch) {
      scnr.next();
      return ch;
    } else {
      emitError(CompileErrorCodes.EXPECTED_TOKEN, currentPosition(), 0, ch);
      return "";
    }
  }
  function peekSpaces(scnr) {
    let buf = "";
    while (scnr.currentPeek() === CHAR_SP || scnr.currentPeek() === CHAR_LF) {
      buf += scnr.currentPeek();
      scnr.peek();
    }
    return buf;
  }
  function skipSpaces(scnr) {
    const buf = peekSpaces(scnr);
    scnr.skipToPeek();
    return buf;
  }
  function isIdentifierStart(ch) {
    if (ch === EOF) {
      return false;
    }
    const cc = ch.charCodeAt(0);
    return cc >= 97 && cc <= 122 || // a-z
    cc >= 65 && cc <= 90 || // A-Z
    cc === 95;
  }
  function isNumberStart(ch) {
    if (ch === EOF) {
      return false;
    }
    const cc = ch.charCodeAt(0);
    return cc >= 48 && cc <= 57;
  }
  function isNamedIdentifierStart(scnr, context2) {
    const { currentType } = context2;
    if (currentType !== 2) {
      return false;
    }
    peekSpaces(scnr);
    const ret = isIdentifierStart(scnr.currentPeek());
    scnr.resetPeek();
    return ret;
  }
  function isListIdentifierStart(scnr, context2) {
    const { currentType } = context2;
    if (currentType !== 2) {
      return false;
    }
    peekSpaces(scnr);
    const ch = scnr.currentPeek() === "-" ? scnr.peek() : scnr.currentPeek();
    const ret = isNumberStart(ch);
    scnr.resetPeek();
    return ret;
  }
  function isLiteralStart(scnr, context2) {
    const { currentType } = context2;
    if (currentType !== 2) {
      return false;
    }
    peekSpaces(scnr);
    const ret = scnr.currentPeek() === LITERAL_DELIMITER;
    scnr.resetPeek();
    return ret;
  }
  function isLinkedDotStart(scnr, context2) {
    const { currentType } = context2;
    if (currentType !== 8) {
      return false;
    }
    peekSpaces(scnr);
    const ret = scnr.currentPeek() === ".";
    scnr.resetPeek();
    return ret;
  }
  function isLinkedModifierStart(scnr, context2) {
    const { currentType } = context2;
    if (currentType !== 9) {
      return false;
    }
    peekSpaces(scnr);
    const ret = isIdentifierStart(scnr.currentPeek());
    scnr.resetPeek();
    return ret;
  }
  function isLinkedDelimiterStart(scnr, context2) {
    const { currentType } = context2;
    if (!(currentType === 8 || currentType === 12)) {
      return false;
    }
    peekSpaces(scnr);
    const ret = scnr.currentPeek() === ":";
    scnr.resetPeek();
    return ret;
  }
  function isLinkedReferStart(scnr, context2) {
    const { currentType } = context2;
    if (currentType !== 10) {
      return false;
    }
    const fn = () => {
      const ch = scnr.currentPeek();
      if (ch === "{") {
        return isIdentifierStart(scnr.peek());
      } else if (ch === "@" || ch === "%" || ch === "|" || ch === ":" || ch === "." || ch === CHAR_SP || !ch) {
        return false;
      } else if (ch === CHAR_LF) {
        scnr.peek();
        return fn();
      } else {
        return isIdentifierStart(ch);
      }
    };
    const ret = fn();
    scnr.resetPeek();
    return ret;
  }
  function isPluralStart(scnr) {
    peekSpaces(scnr);
    const ret = scnr.currentPeek() === "|";
    scnr.resetPeek();
    return ret;
  }
  function detectModuloStart(scnr) {
    const spaces = peekSpaces(scnr);
    const ret = scnr.currentPeek() === "%" && scnr.peek() === "{";
    scnr.resetPeek();
    return {
      isModulo: ret,
      hasSpace: spaces.length > 0
    };
  }
  function isTextStart(scnr, reset = true) {
    const fn = (hasSpace = false, prev = "", detectModulo = false) => {
      const ch = scnr.currentPeek();
      if (ch === "{") {
        return prev === "%" ? false : hasSpace;
      } else if (ch === "@" || !ch) {
        return prev === "%" ? true : hasSpace;
      } else if (ch === "%") {
        scnr.peek();
        return fn(hasSpace, "%", true);
      } else if (ch === "|") {
        return prev === "%" || detectModulo ? true : !(prev === CHAR_SP || prev === CHAR_LF);
      } else if (ch === CHAR_SP) {
        scnr.peek();
        return fn(true, CHAR_SP, detectModulo);
      } else if (ch === CHAR_LF) {
        scnr.peek();
        return fn(true, CHAR_LF, detectModulo);
      } else {
        return true;
      }
    };
    const ret = fn();
    reset && scnr.resetPeek();
    return ret;
  }
  function takeChar(scnr, fn) {
    const ch = scnr.currentChar();
    if (ch === EOF) {
      return EOF;
    }
    if (fn(ch)) {
      scnr.next();
      return ch;
    }
    return null;
  }
  function takeIdentifierChar(scnr) {
    const closure = (ch) => {
      const cc = ch.charCodeAt(0);
      return cc >= 97 && cc <= 122 || // a-z
      cc >= 65 && cc <= 90 || // A-Z
      cc >= 48 && cc <= 57 || // 0-9
      cc === 95 || // _
      cc === 36;
    };
    return takeChar(scnr, closure);
  }
  function takeDigit(scnr) {
    const closure = (ch) => {
      const cc = ch.charCodeAt(0);
      return cc >= 48 && cc <= 57;
    };
    return takeChar(scnr, closure);
  }
  function takeHexDigit(scnr) {
    const closure = (ch) => {
      const cc = ch.charCodeAt(0);
      return cc >= 48 && cc <= 57 || // 0-9
      cc >= 65 && cc <= 70 || // A-F
      cc >= 97 && cc <= 102;
    };
    return takeChar(scnr, closure);
  }
  function getDigits(scnr) {
    let ch = "";
    let num = "";
    while (ch = takeDigit(scnr)) {
      num += ch;
    }
    return num;
  }
  function readModulo(scnr) {
    skipSpaces(scnr);
    const ch = scnr.currentChar();
    if (ch !== "%") {
      emitError(CompileErrorCodes.EXPECTED_TOKEN, currentPosition(), 0, ch);
    }
    scnr.next();
    return "%";
  }
  function readText(scnr) {
    let buf = "";
    while (true) {
      const ch = scnr.currentChar();
      if (ch === "{" || ch === "}" || ch === "@" || ch === "|" || !ch) {
        break;
      } else if (ch === "%") {
        if (isTextStart(scnr)) {
          buf += ch;
          scnr.next();
        } else {
          break;
        }
      } else if (ch === CHAR_SP || ch === CHAR_LF) {
        if (isTextStart(scnr)) {
          buf += ch;
          scnr.next();
        } else if (isPluralStart(scnr)) {
          break;
        } else {
          buf += ch;
          scnr.next();
        }
      } else {
        buf += ch;
        scnr.next();
      }
    }
    return buf;
  }
  function readNamedIdentifier(scnr) {
    skipSpaces(scnr);
    let ch = "";
    let name = "";
    while (ch = takeIdentifierChar(scnr)) {
      name += ch;
    }
    if (scnr.currentChar() === EOF) {
      emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
    }
    return name;
  }
  function readListIdentifier(scnr) {
    skipSpaces(scnr);
    let value = "";
    if (scnr.currentChar() === "-") {
      scnr.next();
      value += `-${getDigits(scnr)}`;
    } else {
      value += getDigits(scnr);
    }
    if (scnr.currentChar() === EOF) {
      emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
    }
    return value;
  }
  function readLiteral(scnr) {
    skipSpaces(scnr);
    eat(scnr, `'`);
    let ch = "";
    let literal = "";
    const fn = (x) => x !== LITERAL_DELIMITER && x !== CHAR_LF;
    while (ch = takeChar(scnr, fn)) {
      if (ch === "\\") {
        literal += readEscapeSequence(scnr);
      } else {
        literal += ch;
      }
    }
    const current = scnr.currentChar();
    if (current === CHAR_LF || current === EOF) {
      emitError(CompileErrorCodes.UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER, currentPosition(), 0);
      if (current === CHAR_LF) {
        scnr.next();
        eat(scnr, `'`);
      }
      return literal;
    }
    eat(scnr, `'`);
    return literal;
  }
  function readEscapeSequence(scnr) {
    const ch = scnr.currentChar();
    switch (ch) {
      case "\\":
      case `'`:
        scnr.next();
        return `\\${ch}`;
      case "u":
        return readUnicodeEscapeSequence(scnr, ch, 4);
      case "U":
        return readUnicodeEscapeSequence(scnr, ch, 6);
      default:
        emitError(CompileErrorCodes.UNKNOWN_ESCAPE_SEQUENCE, currentPosition(), 0, ch);
        return "";
    }
  }
  function readUnicodeEscapeSequence(scnr, unicode, digits) {
    eat(scnr, unicode);
    let sequence = "";
    for (let i = 0; i < digits; i++) {
      const ch = takeHexDigit(scnr);
      if (!ch) {
        emitError(CompileErrorCodes.INVALID_UNICODE_ESCAPE_SEQUENCE, currentPosition(), 0, `\\${unicode}${sequence}${scnr.currentChar()}`);
        break;
      }
      sequence += ch;
    }
    return `\\${unicode}${sequence}`;
  }
  function readInvalidIdentifier(scnr) {
    skipSpaces(scnr);
    let ch = "";
    let identifiers = "";
    const closure = (ch2) => ch2 !== "{" && ch2 !== "}" && ch2 !== CHAR_SP && ch2 !== CHAR_LF;
    while (ch = takeChar(scnr, closure)) {
      identifiers += ch;
    }
    return identifiers;
  }
  function readLinkedModifier(scnr) {
    let ch = "";
    let name = "";
    while (ch = takeIdentifierChar(scnr)) {
      name += ch;
    }
    return name;
  }
  function readLinkedRefer(scnr) {
    const fn = (detect = false, buf) => {
      const ch = scnr.currentChar();
      if (ch === "{" || ch === "%" || ch === "@" || ch === "|" || ch === "(" || ch === ")" || !ch) {
        return buf;
      } else if (ch === CHAR_SP) {
        return buf;
      } else if (ch === CHAR_LF || ch === DOT) {
        buf += ch;
        scnr.next();
        return fn(detect, buf);
      } else {
        buf += ch;
        scnr.next();
        return fn(true, buf);
      }
    };
    return fn(false, "");
  }
  function readPlural(scnr) {
    skipSpaces(scnr);
    const plural = eat(
      scnr,
      "|"
      /* TokenChars.Pipe */
    );
    skipSpaces(scnr);
    return plural;
  }
  function readTokenInPlaceholder(scnr, context2) {
    let token = null;
    const ch = scnr.currentChar();
    switch (ch) {
      case "{":
        if (context2.braceNest >= 1) {
          emitError(CompileErrorCodes.NOT_ALLOW_NEST_PLACEHOLDER, currentPosition(), 0);
        }
        scnr.next();
        token = getToken(
          context2,
          2,
          "{"
          /* TokenChars.BraceLeft */
        );
        skipSpaces(scnr);
        context2.braceNest++;
        return token;
      case "}":
        if (context2.braceNest > 0 && context2.currentType === 2) {
          emitError(CompileErrorCodes.EMPTY_PLACEHOLDER, currentPosition(), 0);
        }
        scnr.next();
        token = getToken(
          context2,
          3,
          "}"
          /* TokenChars.BraceRight */
        );
        context2.braceNest--;
        context2.braceNest > 0 && skipSpaces(scnr);
        if (context2.inLinked && context2.braceNest === 0) {
          context2.inLinked = false;
        }
        return token;
      case "@":
        if (context2.braceNest > 0) {
          emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
        }
        token = readTokenInLinked(scnr, context2) || getEndToken(context2);
        context2.braceNest = 0;
        return token;
      default:
        let validNamedIdentifier = true;
        let validListIdentifier = true;
        let validLiteral = true;
        if (isPluralStart(scnr)) {
          if (context2.braceNest > 0) {
            emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
          }
          token = getToken(context2, 1, readPlural(scnr));
          context2.braceNest = 0;
          context2.inLinked = false;
          return token;
        }
        if (context2.braceNest > 0 && (context2.currentType === 5 || context2.currentType === 6 || context2.currentType === 7)) {
          emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
          context2.braceNest = 0;
          return readToken(scnr, context2);
        }
        if (validNamedIdentifier = isNamedIdentifierStart(scnr, context2)) {
          token = getToken(context2, 5, readNamedIdentifier(scnr));
          skipSpaces(scnr);
          return token;
        }
        if (validListIdentifier = isListIdentifierStart(scnr, context2)) {
          token = getToken(context2, 6, readListIdentifier(scnr));
          skipSpaces(scnr);
          return token;
        }
        if (validLiteral = isLiteralStart(scnr, context2)) {
          token = getToken(context2, 7, readLiteral(scnr));
          skipSpaces(scnr);
          return token;
        }
        if (!validNamedIdentifier && !validListIdentifier && !validLiteral) {
          token = getToken(context2, 13, readInvalidIdentifier(scnr));
          emitError(CompileErrorCodes.INVALID_TOKEN_IN_PLACEHOLDER, currentPosition(), 0, token.value);
          skipSpaces(scnr);
          return token;
        }
        break;
    }
    return token;
  }
  function readTokenInLinked(scnr, context2) {
    const { currentType } = context2;
    let token = null;
    const ch = scnr.currentChar();
    if ((currentType === 8 || currentType === 9 || currentType === 12 || currentType === 10) && (ch === CHAR_LF || ch === CHAR_SP)) {
      emitError(CompileErrorCodes.INVALID_LINKED_FORMAT, currentPosition(), 0);
    }
    switch (ch) {
      case "@":
        scnr.next();
        token = getToken(
          context2,
          8,
          "@"
          /* TokenChars.LinkedAlias */
        );
        context2.inLinked = true;
        return token;
      case ".":
        skipSpaces(scnr);
        scnr.next();
        return getToken(
          context2,
          9,
          "."
          /* TokenChars.LinkedDot */
        );
      case ":":
        skipSpaces(scnr);
        scnr.next();
        return getToken(
          context2,
          10,
          ":"
          /* TokenChars.LinkedDelimiter */
        );
      default:
        if (isPluralStart(scnr)) {
          token = getToken(context2, 1, readPlural(scnr));
          context2.braceNest = 0;
          context2.inLinked = false;
          return token;
        }
        if (isLinkedDotStart(scnr, context2) || isLinkedDelimiterStart(scnr, context2)) {
          skipSpaces(scnr);
          return readTokenInLinked(scnr, context2);
        }
        if (isLinkedModifierStart(scnr, context2)) {
          skipSpaces(scnr);
          return getToken(context2, 12, readLinkedModifier(scnr));
        }
        if (isLinkedReferStart(scnr, context2)) {
          skipSpaces(scnr);
          if (ch === "{") {
            return readTokenInPlaceholder(scnr, context2) || token;
          } else {
            return getToken(context2, 11, readLinkedRefer(scnr));
          }
        }
        if (currentType === 8) {
          emitError(CompileErrorCodes.INVALID_LINKED_FORMAT, currentPosition(), 0);
        }
        context2.braceNest = 0;
        context2.inLinked = false;
        return readToken(scnr, context2);
    }
  }
  function readToken(scnr, context2) {
    let token = {
      type: 14
      /* TokenTypes.EOF */
    };
    if (context2.braceNest > 0) {
      return readTokenInPlaceholder(scnr, context2) || getEndToken(context2);
    }
    if (context2.inLinked) {
      return readTokenInLinked(scnr, context2) || getEndToken(context2);
    }
    const ch = scnr.currentChar();
    switch (ch) {
      case "{":
        return readTokenInPlaceholder(scnr, context2) || getEndToken(context2);
      case "}":
        emitError(CompileErrorCodes.UNBALANCED_CLOSING_BRACE, currentPosition(), 0);
        scnr.next();
        return getToken(
          context2,
          3,
          "}"
          /* TokenChars.BraceRight */
        );
      case "@":
        return readTokenInLinked(scnr, context2) || getEndToken(context2);
      default:
        if (isPluralStart(scnr)) {
          token = getToken(context2, 1, readPlural(scnr));
          context2.braceNest = 0;
          context2.inLinked = false;
          return token;
        }
        const { isModulo, hasSpace } = detectModuloStart(scnr);
        if (isModulo) {
          return hasSpace ? getToken(context2, 0, readText(scnr)) : getToken(context2, 4, readModulo(scnr));
        }
        if (isTextStart(scnr)) {
          return getToken(context2, 0, readText(scnr));
        }
        break;
    }
    return token;
  }
  function nextToken() {
    const { currentType, offset, startLoc, endLoc } = _context;
    _context.lastType = currentType;
    _context.lastOffset = offset;
    _context.lastStartLoc = startLoc;
    _context.lastEndLoc = endLoc;
    _context.offset = currentOffset();
    _context.startLoc = currentPosition();
    if (_scnr.currentChar() === EOF) {
      return getToken(
        _context,
        14
        /* TokenTypes.EOF */
      );
    }
    return readToken(_scnr, _context);
  }
  return {
    nextToken,
    currentOffset,
    currentPosition,
    context
  };
}
const ERROR_DOMAIN$2 = "parser";
const KNOWN_ESCAPES = /(?:\\\\|\\'|\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{6}))/g;
function fromEscapeSequence(match, codePoint4, codePoint6) {
  switch (match) {
    case `\\\\`:
      return `\\`;
    case `\\'`:
      return `'`;
    default: {
      const codePoint = parseInt(codePoint4 || codePoint6, 16);
      if (codePoint <= 55295 || codePoint >= 57344) {
        return String.fromCodePoint(codePoint);
      }
      return "�";
    }
  }
}
function createParser(options2 = {}) {
  const location = options2.location !== false;
  const { onError } = options2;
  function emitError(tokenzer, code2, start, offset, ...args) {
    const end = tokenzer.currentPosition();
    end.offset += offset;
    end.column += offset;
    if (onError) {
      const loc = location ? createLocation(start, end) : null;
      const err = createCompileError(code2, loc, {
        domain: ERROR_DOMAIN$2,
        args
      });
      onError(err);
    }
  }
  function startNode(type, offset, loc) {
    const node = { type };
    if (location) {
      node.start = offset;
      node.end = offset;
      node.loc = { start: loc, end: loc };
    }
    return node;
  }
  function endNode(node, offset, pos, type) {
    if (type) {
      node.type = type;
    }
    if (location) {
      node.end = offset;
      if (node.loc) {
        node.loc.end = pos;
      }
    }
  }
  function parseText(tokenizer, value) {
    const context = tokenizer.context();
    const node = startNode(3, context.offset, context.startLoc);
    node.value = value;
    endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
    return node;
  }
  function parseList(tokenizer, index) {
    const context = tokenizer.context();
    const { lastOffset: offset, lastStartLoc: loc } = context;
    const node = startNode(5, offset, loc);
    node.index = parseInt(index, 10);
    tokenizer.nextToken();
    endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
    return node;
  }
  function parseNamed(tokenizer, key) {
    const context = tokenizer.context();
    const { lastOffset: offset, lastStartLoc: loc } = context;
    const node = startNode(4, offset, loc);
    node.key = key;
    tokenizer.nextToken();
    endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
    return node;
  }
  function parseLiteral(tokenizer, value) {
    const context = tokenizer.context();
    const { lastOffset: offset, lastStartLoc: loc } = context;
    const node = startNode(9, offset, loc);
    node.value = value.replace(KNOWN_ESCAPES, fromEscapeSequence);
    tokenizer.nextToken();
    endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
    return node;
  }
  function parseLinkedModifier(tokenizer) {
    const token = tokenizer.nextToken();
    const context = tokenizer.context();
    const { lastOffset: offset, lastStartLoc: loc } = context;
    const node = startNode(8, offset, loc);
    if (token.type !== 12) {
      emitError(tokenizer, CompileErrorCodes.UNEXPECTED_EMPTY_LINKED_MODIFIER, context.lastStartLoc, 0);
      node.value = "";
      endNode(node, offset, loc);
      return {
        nextConsumeToken: token,
        node
      };
    }
    if (token.value == null) {
      emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
    }
    node.value = token.value || "";
    endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
    return {
      node
    };
  }
  function parseLinkedKey(tokenizer, value) {
    const context = tokenizer.context();
    const node = startNode(7, context.offset, context.startLoc);
    node.value = value;
    endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
    return node;
  }
  function parseLinked(tokenizer) {
    const context = tokenizer.context();
    const linkedNode = startNode(6, context.offset, context.startLoc);
    let token = tokenizer.nextToken();
    if (token.type === 9) {
      const parsed = parseLinkedModifier(tokenizer);
      linkedNode.modifier = parsed.node;
      token = parsed.nextConsumeToken || tokenizer.nextToken();
    }
    if (token.type !== 10) {
      emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
    }
    token = tokenizer.nextToken();
    if (token.type === 2) {
      token = tokenizer.nextToken();
    }
    switch (token.type) {
      case 11:
        if (token.value == null) {
          emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
        }
        linkedNode.key = parseLinkedKey(tokenizer, token.value || "");
        break;
      case 5:
        if (token.value == null) {
          emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
        }
        linkedNode.key = parseNamed(tokenizer, token.value || "");
        break;
      case 6:
        if (token.value == null) {
          emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
        }
        linkedNode.key = parseList(tokenizer, token.value || "");
        break;
      case 7:
        if (token.value == null) {
          emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
        }
        linkedNode.key = parseLiteral(tokenizer, token.value || "");
        break;
      default:
        emitError(tokenizer, CompileErrorCodes.UNEXPECTED_EMPTY_LINKED_KEY, context.lastStartLoc, 0);
        const nextContext = tokenizer.context();
        const emptyLinkedKeyNode = startNode(7, nextContext.offset, nextContext.startLoc);
        emptyLinkedKeyNode.value = "";
        endNode(emptyLinkedKeyNode, nextContext.offset, nextContext.startLoc);
        linkedNode.key = emptyLinkedKeyNode;
        endNode(linkedNode, nextContext.offset, nextContext.startLoc);
        return {
          nextConsumeToken: token,
          node: linkedNode
        };
    }
    endNode(linkedNode, tokenizer.currentOffset(), tokenizer.currentPosition());
    return {
      node: linkedNode
    };
  }
  function parseMessage(tokenizer) {
    const context = tokenizer.context();
    const startOffset = context.currentType === 1 ? tokenizer.currentOffset() : context.offset;
    const startLoc = context.currentType === 1 ? context.endLoc : context.startLoc;
    const node = startNode(2, startOffset, startLoc);
    node.items = [];
    let nextToken = null;
    do {
      const token = nextToken || tokenizer.nextToken();
      nextToken = null;
      switch (token.type) {
        case 0:
          if (token.value == null) {
            emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
          }
          node.items.push(parseText(tokenizer, token.value || ""));
          break;
        case 6:
          if (token.value == null) {
            emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
          }
          node.items.push(parseList(tokenizer, token.value || ""));
          break;
        case 5:
          if (token.value == null) {
            emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
          }
          node.items.push(parseNamed(tokenizer, token.value || ""));
          break;
        case 7:
          if (token.value == null) {
            emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
          }
          node.items.push(parseLiteral(tokenizer, token.value || ""));
          break;
        case 8:
          const parsed = parseLinked(tokenizer);
          node.items.push(parsed.node);
          nextToken = parsed.nextConsumeToken || null;
          break;
      }
    } while (context.currentType !== 14 && context.currentType !== 1);
    const endOffset = context.currentType === 1 ? context.lastOffset : tokenizer.currentOffset();
    const endLoc = context.currentType === 1 ? context.lastEndLoc : tokenizer.currentPosition();
    endNode(node, endOffset, endLoc);
    return node;
  }
  function parsePlural(tokenizer, offset, loc, msgNode) {
    const context = tokenizer.context();
    let hasEmptyMessage = msgNode.items.length === 0;
    const node = startNode(1, offset, loc);
    node.cases = [];
    node.cases.push(msgNode);
    do {
      const msg = parseMessage(tokenizer);
      if (!hasEmptyMessage) {
        hasEmptyMessage = msg.items.length === 0;
      }
      node.cases.push(msg);
    } while (context.currentType !== 14);
    if (hasEmptyMessage) {
      emitError(tokenizer, CompileErrorCodes.MUST_HAVE_MESSAGES_IN_PLURAL, loc, 0);
    }
    endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
    return node;
  }
  function parseResource(tokenizer) {
    const context = tokenizer.context();
    const { offset, startLoc } = context;
    const msgNode = parseMessage(tokenizer);
    if (context.currentType === 14) {
      return msgNode;
    } else {
      return parsePlural(tokenizer, offset, startLoc, msgNode);
    }
  }
  function parse2(source) {
    const tokenizer = createTokenizer(source, assign$1({}, options2));
    const context = tokenizer.context();
    const node = startNode(0, context.offset, context.startLoc);
    if (location && node.loc) {
      node.loc.source = source;
    }
    node.body = parseResource(tokenizer);
    if (options2.onCacheKey) {
      node.cacheKey = options2.onCacheKey(source);
    }
    if (context.currentType !== 14) {
      emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, source[context.offset] || "");
    }
    endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
    return node;
  }
  return { parse: parse2 };
}
function getTokenCaption(token) {
  if (token.type === 14) {
    return "EOF";
  }
  const name = (token.value || "").replace(/\r?\n/gu, "\\n");
  return name.length > 10 ? name.slice(0, 9) + "…" : name;
}
function createTransformer(ast, options2 = {}) {
  const _context = {
    ast,
    helpers: /* @__PURE__ */ new Set()
  };
  const context = () => _context;
  const helper = (name) => {
    _context.helpers.add(name);
    return name;
  };
  return { context, helper };
}
function traverseNodes(nodes, transformer) {
  for (let i = 0; i < nodes.length; i++) {
    traverseNode(nodes[i], transformer);
  }
}
function traverseNode(node, transformer) {
  switch (node.type) {
    case 1:
      traverseNodes(node.cases, transformer);
      transformer.helper(
        "plural"
        /* HelperNameMap.PLURAL */
      );
      break;
    case 2:
      traverseNodes(node.items, transformer);
      break;
    case 6:
      const linked = node;
      traverseNode(linked.key, transformer);
      transformer.helper(
        "linked"
        /* HelperNameMap.LINKED */
      );
      transformer.helper(
        "type"
        /* HelperNameMap.TYPE */
      );
      break;
    case 5:
      transformer.helper(
        "interpolate"
        /* HelperNameMap.INTERPOLATE */
      );
      transformer.helper(
        "list"
        /* HelperNameMap.LIST */
      );
      break;
    case 4:
      transformer.helper(
        "interpolate"
        /* HelperNameMap.INTERPOLATE */
      );
      transformer.helper(
        "named"
        /* HelperNameMap.NAMED */
      );
      break;
  }
}
function transform(ast, options2 = {}) {
  const transformer = createTransformer(ast);
  transformer.helper(
    "normalize"
    /* HelperNameMap.NORMALIZE */
  );
  ast.body && traverseNode(ast.body, transformer);
  const context = transformer.context();
  ast.helpers = Array.from(context.helpers);
}
function optimize(ast) {
  const body = ast.body;
  if (body.type === 2) {
    optimizeMessageNode(body);
  } else {
    body.cases.forEach((c) => optimizeMessageNode(c));
  }
  return ast;
}
function optimizeMessageNode(message) {
  if (message.items.length === 1) {
    const item = message.items[0];
    if (item.type === 3 || item.type === 9) {
      message.static = item.value;
      delete item.value;
    }
  } else {
    const values = [];
    for (let i = 0; i < message.items.length; i++) {
      const item = message.items[i];
      if (!(item.type === 3 || item.type === 9)) {
        break;
      }
      if (item.value == null) {
        break;
      }
      values.push(item.value);
    }
    if (values.length === message.items.length) {
      message.static = join(values);
      for (let i = 0; i < message.items.length; i++) {
        const item = message.items[i];
        if (item.type === 3 || item.type === 9) {
          delete item.value;
        }
      }
    }
  }
}
function minify(node) {
  node.t = node.type;
  switch (node.type) {
    case 0:
      const resource2 = node;
      minify(resource2.body);
      resource2.b = resource2.body;
      delete resource2.body;
      break;
    case 1:
      const plural = node;
      const cases = plural.cases;
      for (let i = 0; i < cases.length; i++) {
        minify(cases[i]);
      }
      plural.c = cases;
      delete plural.cases;
      break;
    case 2:
      const message = node;
      const items = message.items;
      for (let i = 0; i < items.length; i++) {
        minify(items[i]);
      }
      message.i = items;
      delete message.items;
      if (message.static) {
        message.s = message.static;
        delete message.static;
      }
      break;
    case 3:
    case 9:
    case 8:
    case 7:
      const valueNode = node;
      if (valueNode.value) {
        valueNode.v = valueNode.value;
        delete valueNode.value;
      }
      break;
    case 6:
      const linked = node;
      minify(linked.key);
      linked.k = linked.key;
      delete linked.key;
      if (linked.modifier) {
        minify(linked.modifier);
        linked.m = linked.modifier;
        delete linked.modifier;
      }
      break;
    case 5:
      const list = node;
      list.i = list.index;
      delete list.index;
      break;
    case 4:
      const named = node;
      named.k = named.key;
      delete named.key;
      break;
  }
  delete node.type;
}
function createCodeGenerator(ast, options2) {
  const { sourceMap, filename, breakLineCode, needIndent: _needIndent } = options2;
  const location = options2.location !== false;
  const _context = {
    filename,
    code: "",
    column: 1,
    line: 1,
    offset: 0,
    map: void 0,
    breakLineCode,
    needIndent: _needIndent,
    indentLevel: 0
  };
  if (location && ast.loc) {
    _context.source = ast.loc.source;
  }
  const context = () => _context;
  function push(code2, node) {
    _context.code += code2;
  }
  function _newline(n, withBreakLine = true) {
    const _breakLineCode = withBreakLine ? breakLineCode : "";
    push(_needIndent ? _breakLineCode + `  `.repeat(n) : _breakLineCode);
  }
  function indent(withNewLine = true) {
    const level = ++_context.indentLevel;
    withNewLine && _newline(level);
  }
  function deindent(withNewLine = true) {
    const level = --_context.indentLevel;
    withNewLine && _newline(level);
  }
  function newline() {
    _newline(_context.indentLevel);
  }
  const helper = (key) => `_${key}`;
  const needIndent = () => _context.needIndent;
  return {
    context,
    push,
    indent,
    deindent,
    newline,
    helper,
    needIndent
  };
}
function generateLinkedNode(generator, node) {
  const { helper } = generator;
  generator.push(`${helper(
    "linked"
    /* HelperNameMap.LINKED */
  )}(`);
  generateNode(generator, node.key);
  if (node.modifier) {
    generator.push(`, `);
    generateNode(generator, node.modifier);
    generator.push(`, _type`);
  } else {
    generator.push(`, undefined, _type`);
  }
  generator.push(`)`);
}
function generateMessageNode(generator, node) {
  const { helper, needIndent } = generator;
  generator.push(`${helper(
    "normalize"
    /* HelperNameMap.NORMALIZE */
  )}([`);
  generator.indent(needIndent());
  const length = node.items.length;
  for (let i = 0; i < length; i++) {
    generateNode(generator, node.items[i]);
    if (i === length - 1) {
      break;
    }
    generator.push(", ");
  }
  generator.deindent(needIndent());
  generator.push("])");
}
function generatePluralNode(generator, node) {
  const { helper, needIndent } = generator;
  if (node.cases.length > 1) {
    generator.push(`${helper(
      "plural"
      /* HelperNameMap.PLURAL */
    )}([`);
    generator.indent(needIndent());
    const length = node.cases.length;
    for (let i = 0; i < length; i++) {
      generateNode(generator, node.cases[i]);
      if (i === length - 1) {
        break;
      }
      generator.push(", ");
    }
    generator.deindent(needIndent());
    generator.push(`])`);
  }
}
function generateResource(generator, node) {
  if (node.body) {
    generateNode(generator, node.body);
  } else {
    generator.push("null");
  }
}
function generateNode(generator, node) {
  const { helper } = generator;
  switch (node.type) {
    case 0:
      generateResource(generator, node);
      break;
    case 1:
      generatePluralNode(generator, node);
      break;
    case 2:
      generateMessageNode(generator, node);
      break;
    case 6:
      generateLinkedNode(generator, node);
      break;
    case 8:
      generator.push(JSON.stringify(node.value), node);
      break;
    case 7:
      generator.push(JSON.stringify(node.value), node);
      break;
    case 5:
      generator.push(`${helper(
        "interpolate"
        /* HelperNameMap.INTERPOLATE */
      )}(${helper(
        "list"
        /* HelperNameMap.LIST */
      )}(${node.index}))`, node);
      break;
    case 4:
      generator.push(`${helper(
        "interpolate"
        /* HelperNameMap.INTERPOLATE */
      )}(${helper(
        "named"
        /* HelperNameMap.NAMED */
      )}(${JSON.stringify(node.key)}))`, node);
      break;
    case 9:
      generator.push(JSON.stringify(node.value), node);
      break;
    case 3:
      generator.push(JSON.stringify(node.value), node);
      break;
  }
}
const generate = (ast, options2 = {}) => {
  const mode = isString$1(options2.mode) ? options2.mode : "normal";
  const filename = isString$1(options2.filename) ? options2.filename : "message.intl";
  const sourceMap = !!options2.sourceMap;
  const breakLineCode = options2.breakLineCode != null ? options2.breakLineCode : mode === "arrow" ? ";" : "\n";
  const needIndent = options2.needIndent ? options2.needIndent : mode !== "arrow";
  const helpers = ast.helpers || [];
  const generator = createCodeGenerator(ast, {
    mode,
    filename,
    sourceMap,
    breakLineCode,
    needIndent
  });
  generator.push(mode === "normal" ? `function __msg__ (ctx) {` : `(ctx) => {`);
  generator.indent(needIndent);
  if (helpers.length > 0) {
    generator.push(`const { ${join(helpers.map((s) => `${s}: _${s}`), ", ")} } = ctx`);
    generator.newline();
  }
  generator.push(`return `);
  generateNode(generator, ast);
  generator.deindent(needIndent);
  generator.push(`}`);
  delete ast.helpers;
  const { code: code2, map } = generator.context();
  return {
    ast,
    code: code2,
    map: map ? map.toJSON() : void 0
    // eslint-disable-line @typescript-eslint/no-explicit-any
  };
};
function baseCompile$1(source, options2 = {}) {
  const assignedOptions = assign$1({}, options2);
  const jit = !!assignedOptions.jit;
  const enalbeMinify = !!assignedOptions.minify;
  const enambeOptimize = assignedOptions.optimize == null ? true : assignedOptions.optimize;
  const parser = createParser(assignedOptions);
  const ast = parser.parse(source);
  if (!jit) {
    transform(ast, assignedOptions);
    return generate(ast, assignedOptions);
  } else {
    enambeOptimize && optimize(ast);
    enalbeMinify && minify(ast);
    return { ast, code: "" };
  }
}
const pathStateMachine = [];
pathStateMachine[
  0
  /* States.BEFORE_PATH */
] = {
  [
    "w"
    /* PathCharTypes.WORKSPACE */
  ]: [
    0
    /* States.BEFORE_PATH */
  ],
  [
    "i"
    /* PathCharTypes.IDENT */
  ]: [
    3,
    0
    /* Actions.APPEND */
  ],
  [
    "["
    /* PathCharTypes.LEFT_BRACKET */
  ]: [
    4
    /* States.IN_SUB_PATH */
  ],
  [
    "o"
    /* PathCharTypes.END_OF_FAIL */
  ]: [
    7
    /* States.AFTER_PATH */
  ]
};
pathStateMachine[
  1
  /* States.IN_PATH */
] = {
  [
    "w"
    /* PathCharTypes.WORKSPACE */
  ]: [
    1
    /* States.IN_PATH */
  ],
  [
    "."
    /* PathCharTypes.DOT */
  ]: [
    2
    /* States.BEFORE_IDENT */
  ],
  [
    "["
    /* PathCharTypes.LEFT_BRACKET */
  ]: [
    4
    /* States.IN_SUB_PATH */
  ],
  [
    "o"
    /* PathCharTypes.END_OF_FAIL */
  ]: [
    7
    /* States.AFTER_PATH */
  ]
};
pathStateMachine[
  2
  /* States.BEFORE_IDENT */
] = {
  [
    "w"
    /* PathCharTypes.WORKSPACE */
  ]: [
    2
    /* States.BEFORE_IDENT */
  ],
  [
    "i"
    /* PathCharTypes.IDENT */
  ]: [
    3,
    0
    /* Actions.APPEND */
  ],
  [
    "0"
    /* PathCharTypes.ZERO */
  ]: [
    3,
    0
    /* Actions.APPEND */
  ]
};
pathStateMachine[
  3
  /* States.IN_IDENT */
] = {
  [
    "i"
    /* PathCharTypes.IDENT */
  ]: [
    3,
    0
    /* Actions.APPEND */
  ],
  [
    "0"
    /* PathCharTypes.ZERO */
  ]: [
    3,
    0
    /* Actions.APPEND */
  ],
  [
    "w"
    /* PathCharTypes.WORKSPACE */
  ]: [
    1,
    1
    /* Actions.PUSH */
  ],
  [
    "."
    /* PathCharTypes.DOT */
  ]: [
    2,
    1
    /* Actions.PUSH */
  ],
  [
    "["
    /* PathCharTypes.LEFT_BRACKET */
  ]: [
    4,
    1
    /* Actions.PUSH */
  ],
  [
    "o"
    /* PathCharTypes.END_OF_FAIL */
  ]: [
    7,
    1
    /* Actions.PUSH */
  ]
};
pathStateMachine[
  4
  /* States.IN_SUB_PATH */
] = {
  [
    "'"
    /* PathCharTypes.SINGLE_QUOTE */
  ]: [
    5,
    0
    /* Actions.APPEND */
  ],
  [
    '"'
    /* PathCharTypes.DOUBLE_QUOTE */
  ]: [
    6,
    0
    /* Actions.APPEND */
  ],
  [
    "["
    /* PathCharTypes.LEFT_BRACKET */
  ]: [
    4,
    2
    /* Actions.INC_SUB_PATH_DEPTH */
  ],
  [
    "]"
    /* PathCharTypes.RIGHT_BRACKET */
  ]: [
    1,
    3
    /* Actions.PUSH_SUB_PATH */
  ],
  [
    "o"
    /* PathCharTypes.END_OF_FAIL */
  ]: 8,
  [
    "l"
    /* PathCharTypes.ELSE */
  ]: [
    4,
    0
    /* Actions.APPEND */
  ]
};
pathStateMachine[
  5
  /* States.IN_SINGLE_QUOTE */
] = {
  [
    "'"
    /* PathCharTypes.SINGLE_QUOTE */
  ]: [
    4,
    0
    /* Actions.APPEND */
  ],
  [
    "o"
    /* PathCharTypes.END_OF_FAIL */
  ]: 8,
  [
    "l"
    /* PathCharTypes.ELSE */
  ]: [
    5,
    0
    /* Actions.APPEND */
  ]
};
pathStateMachine[
  6
  /* States.IN_DOUBLE_QUOTE */
] = {
  [
    '"'
    /* PathCharTypes.DOUBLE_QUOTE */
  ]: [
    4,
    0
    /* Actions.APPEND */
  ],
  [
    "o"
    /* PathCharTypes.END_OF_FAIL */
  ]: 8,
  [
    "l"
    /* PathCharTypes.ELSE */
  ]: [
    6,
    0
    /* Actions.APPEND */
  ]
};
const literalValueRE = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;
function isLiteral(exp) {
  return literalValueRE.test(exp);
}
function stripQuotes(str) {
  const a = str.charCodeAt(0);
  const b = str.charCodeAt(str.length - 1);
  return a === b && (a === 34 || a === 39) ? str.slice(1, -1) : str;
}
function getPathCharType(ch) {
  if (ch === void 0 || ch === null) {
    return "o";
  }
  const code2 = ch.charCodeAt(0);
  switch (code2) {
    case 91:
    case 93:
    case 46:
    case 34:
    case 39:
      return ch;
    case 95:
    case 36:
    case 45:
      return "i";
    case 9:
    case 10:
    case 13:
    case 160:
    case 65279:
    case 8232:
    case 8233:
      return "w";
  }
  return "i";
}
function formatSubPath(path) {
  const trimmed = path.trim();
  if (path.charAt(0) === "0" && isNaN(parseInt(path))) {
    return false;
  }
  return isLiteral(trimmed) ? stripQuotes(trimmed) : "*" + trimmed;
}
function parse(path) {
  const keys = [];
  let index = -1;
  let mode = 0;
  let subPathDepth = 0;
  let c;
  let key;
  let newChar;
  let type;
  let transition;
  let action;
  let typeMap;
  const actions = [];
  actions[
    0
    /* Actions.APPEND */
  ] = () => {
    if (key === void 0) {
      key = newChar;
    } else {
      key += newChar;
    }
  };
  actions[
    1
    /* Actions.PUSH */
  ] = () => {
    if (key !== void 0) {
      keys.push(key);
      key = void 0;
    }
  };
  actions[
    2
    /* Actions.INC_SUB_PATH_DEPTH */
  ] = () => {
    actions[
      0
      /* Actions.APPEND */
    ]();
    subPathDepth++;
  };
  actions[
    3
    /* Actions.PUSH_SUB_PATH */
  ] = () => {
    if (subPathDepth > 0) {
      subPathDepth--;
      mode = 4;
      actions[
        0
        /* Actions.APPEND */
      ]();
    } else {
      subPathDepth = 0;
      if (key === void 0) {
        return false;
      }
      key = formatSubPath(key);
      if (key === false) {
        return false;
      } else {
        actions[
          1
          /* Actions.PUSH */
        ]();
      }
    }
  };
  function maybeUnescapeQuote() {
    const nextChar = path[index + 1];
    if (mode === 5 && nextChar === "'" || mode === 6 && nextChar === '"') {
      index++;
      newChar = "\\" + nextChar;
      actions[
        0
        /* Actions.APPEND */
      ]();
      return true;
    }
  }
  while (mode !== null) {
    index++;
    c = path[index];
    if (c === "\\" && maybeUnescapeQuote()) {
      continue;
    }
    type = getPathCharType(c);
    typeMap = pathStateMachine[mode];
    transition = typeMap[type] || typeMap[
      "l"
      /* PathCharTypes.ELSE */
    ] || 8;
    if (transition === 8) {
      return;
    }
    mode = transition[0];
    if (transition[1] !== void 0) {
      action = actions[transition[1]];
      if (action) {
        newChar = c;
        if (action() === false) {
          return;
        }
      }
    }
    if (mode === 7) {
      return keys;
    }
  }
}
const cache = /* @__PURE__ */ new Map();
function resolveWithKeyValue(obj, path) {
  return isObject$1(obj) ? obj[path] : null;
}
function resolveValue(obj, path) {
  if (!isObject$1(obj)) {
    return null;
  }
  let hit = cache.get(path);
  if (!hit) {
    hit = parse(path);
    if (hit) {
      cache.set(path, hit);
    }
  }
  if (!hit) {
    return null;
  }
  const len = hit.length;
  let last = obj;
  let i = 0;
  while (i < len) {
    const val = last[hit[i]];
    if (val === void 0) {
      return null;
    }
    if (isFunction$1(last)) {
      return null;
    }
    last = val;
    i++;
  }
  return last;
}
const DEFAULT_MODIFIER = (str) => str;
const DEFAULT_MESSAGE = (ctx) => "";
const DEFAULT_MESSAGE_DATA_TYPE = "text";
const DEFAULT_NORMALIZE = (values) => values.length === 0 ? "" : join(values);
const DEFAULT_INTERPOLATE = toDisplayString;
function pluralDefault(choice, choicesLength) {
  choice = Math.abs(choice);
  if (choicesLength === 2) {
    return choice ? choice > 1 ? 1 : 0 : 1;
  }
  return choice ? Math.min(choice, 2) : 0;
}
function getPluralIndex(options2) {
  const index = isNumber(options2.pluralIndex) ? options2.pluralIndex : -1;
  return options2.named && (isNumber(options2.named.count) || isNumber(options2.named.n)) ? isNumber(options2.named.count) ? options2.named.count : isNumber(options2.named.n) ? options2.named.n : index : index;
}
function normalizeNamed(pluralIndex, props) {
  if (!props.count) {
    props.count = pluralIndex;
  }
  if (!props.n) {
    props.n = pluralIndex;
  }
}
function createMessageContext(options2 = {}) {
  const locale = options2.locale;
  const pluralIndex = getPluralIndex(options2);
  const pluralRule = isObject$1(options2.pluralRules) && isString$1(locale) && isFunction$1(options2.pluralRules[locale]) ? options2.pluralRules[locale] : pluralDefault;
  const orgPluralRule = isObject$1(options2.pluralRules) && isString$1(locale) && isFunction$1(options2.pluralRules[locale]) ? pluralDefault : void 0;
  const plural = (messages) => {
    return messages[pluralRule(pluralIndex, messages.length, orgPluralRule)];
  };
  const _list = options2.list || [];
  const list = (index) => _list[index];
  const _named = options2.named || {};
  isNumber(options2.pluralIndex) && normalizeNamed(pluralIndex, _named);
  const named = (key) => _named[key];
  function message(key) {
    const msg = isFunction$1(options2.messages) ? options2.messages(key) : isObject$1(options2.messages) ? options2.messages[key] : false;
    return !msg ? options2.parent ? options2.parent.message(key) : DEFAULT_MESSAGE : msg;
  }
  const _modifier = (name) => options2.modifiers ? options2.modifiers[name] : DEFAULT_MODIFIER;
  const normalize = isPlainObject(options2.processor) && isFunction$1(options2.processor.normalize) ? options2.processor.normalize : DEFAULT_NORMALIZE;
  const interpolate = isPlainObject(options2.processor) && isFunction$1(options2.processor.interpolate) ? options2.processor.interpolate : DEFAULT_INTERPOLATE;
  const type = isPlainObject(options2.processor) && isString$1(options2.processor.type) ? options2.processor.type : DEFAULT_MESSAGE_DATA_TYPE;
  const linked = (key, ...args) => {
    const [arg1, arg2] = args;
    let type2 = "text";
    let modifier = "";
    if (args.length === 1) {
      if (isObject$1(arg1)) {
        modifier = arg1.modifier || modifier;
        type2 = arg1.type || type2;
      } else if (isString$1(arg1)) {
        modifier = arg1 || modifier;
      }
    } else if (args.length === 2) {
      if (isString$1(arg1)) {
        modifier = arg1 || modifier;
      }
      if (isString$1(arg2)) {
        type2 = arg2 || type2;
      }
    }
    const ret = message(key)(ctx);
    const msg = (
      // The message in vnode resolved with linked are returned as an array by processor.nomalize
      type2 === "vnode" && isArray$1(ret) && modifier ? ret[0] : ret
    );
    return modifier ? _modifier(modifier)(msg, type2) : msg;
  };
  const ctx = {
    [
      "list"
      /* HelperNameMap.LIST */
    ]: list,
    [
      "named"
      /* HelperNameMap.NAMED */
    ]: named,
    [
      "plural"
      /* HelperNameMap.PLURAL */
    ]: plural,
    [
      "linked"
      /* HelperNameMap.LINKED */
    ]: linked,
    [
      "message"
      /* HelperNameMap.MESSAGE */
    ]: message,
    [
      "type"
      /* HelperNameMap.TYPE */
    ]: type,
    [
      "interpolate"
      /* HelperNameMap.INTERPOLATE */
    ]: interpolate,
    [
      "normalize"
      /* HelperNameMap.NORMALIZE */
    ]: normalize,
    [
      "values"
      /* HelperNameMap.VALUES */
    ]: assign$1({}, _list, _named)
  };
  return ctx;
}
const CoreWarnCodes = {
  NOT_FOUND_KEY: 1,
  FALLBACK_TO_TRANSLATE: 2,
  CANNOT_FORMAT_NUMBER: 3,
  FALLBACK_TO_NUMBER_FORMAT: 4,
  CANNOT_FORMAT_DATE: 5,
  FALLBACK_TO_DATE_FORMAT: 6,
  EXPERIMENTAL_CUSTOM_MESSAGE_COMPILER: 7,
  __EXTEND_POINT__: 8
};
const code$2 = CompileErrorCodes.__EXTEND_POINT__;
const inc$2 = incrementer(code$2);
const CoreErrorCodes = {
  INVALID_ARGUMENT: code$2,
  INVALID_DATE_ARGUMENT: inc$2(),
  INVALID_ISO_DATE_ARGUMENT: inc$2(),
  NOT_SUPPORT_NON_STRING_MESSAGE: inc$2(),
  NOT_SUPPORT_LOCALE_PROMISE_VALUE: inc$2(),
  NOT_SUPPORT_LOCALE_ASYNC_FUNCTION: inc$2(),
  NOT_SUPPORT_LOCALE_TYPE: inc$2(),
  __EXTEND_POINT__: inc$2()
  // 25
};
function createCoreError(code2) {
  return createCompileError(code2, null, void 0);
}
function getLocale$1(context, options2) {
  return options2.locale != null ? resolveLocale(options2.locale) : resolveLocale(context.locale);
}
let _resolveLocale;
function resolveLocale(locale) {
  if (isString$1(locale)) {
    return locale;
  } else {
    if (isFunction$1(locale)) {
      if (locale.resolvedOnce && _resolveLocale != null) {
        return _resolveLocale;
      } else if (locale.constructor.name === "Function") {
        const resolve2 = locale();
        if (isPromise(resolve2)) {
          throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_PROMISE_VALUE);
        }
        return _resolveLocale = resolve2;
      } else {
        throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_ASYNC_FUNCTION);
      }
    } else {
      throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_TYPE);
    }
  }
}
function fallbackWithSimple(ctx, fallback, start) {
  return [.../* @__PURE__ */ new Set([
    start,
    ...isArray$1(fallback) ? fallback : isObject$1(fallback) ? Object.keys(fallback) : isString$1(fallback) ? [fallback] : [start]
  ])];
}
function fallbackWithLocaleChain(ctx, fallback, start) {
  const startLocale = isString$1(start) ? start : DEFAULT_LOCALE$1;
  const context = ctx;
  if (!context.__localeChainCache) {
    context.__localeChainCache = /* @__PURE__ */ new Map();
  }
  let chain = context.__localeChainCache.get(startLocale);
  if (!chain) {
    chain = [];
    let block = [start];
    while (isArray$1(block)) {
      block = appendBlockToChain(chain, block, fallback);
    }
    const defaults2 = isArray$1(fallback) || !isPlainObject(fallback) ? fallback : fallback["default"] ? fallback["default"] : null;
    block = isString$1(defaults2) ? [defaults2] : defaults2;
    if (isArray$1(block)) {
      appendBlockToChain(chain, block, false);
    }
    context.__localeChainCache.set(startLocale, chain);
  }
  return chain;
}
function appendBlockToChain(chain, block, blocks) {
  let follow = true;
  for (let i = 0; i < block.length && isBoolean(follow); i++) {
    const locale = block[i];
    if (isString$1(locale)) {
      follow = appendLocaleToChain(chain, block[i], blocks);
    }
  }
  return follow;
}
function appendLocaleToChain(chain, locale, blocks) {
  let follow;
  const tokens = locale.split("-");
  do {
    const target = tokens.join("-");
    follow = appendItemToChain(chain, target, blocks);
    tokens.splice(-1, 1);
  } while (tokens.length && follow === true);
  return follow;
}
function appendItemToChain(chain, target, blocks) {
  let follow = false;
  if (!chain.includes(target)) {
    follow = true;
    if (target) {
      follow = target[target.length - 1] !== "!";
      const locale = target.replace(/!/g, "");
      chain.push(locale);
      if ((isArray$1(blocks) || isPlainObject(blocks)) && blocks[locale]) {
        follow = blocks[locale];
      }
    }
  }
  return follow;
}
const VERSION$1 = "9.8.0";
const NOT_REOSLVED = -1;
const DEFAULT_LOCALE$1 = "en-US";
const MISSING_RESOLVE_VALUE = "";
const capitalize = (str) => `${str.charAt(0).toLocaleUpperCase()}${str.substr(1)}`;
function getDefaultLinkedModifiers() {
  return {
    upper: (val, type) => {
      return type === "text" && isString$1(val) ? val.toUpperCase() : type === "vnode" && isObject$1(val) && "__v_isVNode" in val ? val.children.toUpperCase() : val;
    },
    lower: (val, type) => {
      return type === "text" && isString$1(val) ? val.toLowerCase() : type === "vnode" && isObject$1(val) && "__v_isVNode" in val ? val.children.toLowerCase() : val;
    },
    capitalize: (val, type) => {
      return type === "text" && isString$1(val) ? capitalize(val) : type === "vnode" && isObject$1(val) && "__v_isVNode" in val ? capitalize(val.children) : val;
    }
  };
}
let _compiler;
function registerMessageCompiler(compiler) {
  _compiler = compiler;
}
let _resolver;
function registerMessageResolver(resolver2) {
  _resolver = resolver2;
}
let _fallbacker;
function registerLocaleFallbacker(fallbacker) {
  _fallbacker = fallbacker;
}
const setAdditionalMeta = /* @__NO_SIDE_EFFECTS__ */ (meta) => {
};
let _fallbackContext = null;
const setFallbackContext = (context) => {
  _fallbackContext = context;
};
const getFallbackContext = () => _fallbackContext;
let _cid = 0;
function createCoreContext(options2 = {}) {
  const onWarn = isFunction$1(options2.onWarn) ? options2.onWarn : warn$1;
  const version2 = isString$1(options2.version) ? options2.version : VERSION$1;
  const locale = isString$1(options2.locale) || isFunction$1(options2.locale) ? options2.locale : DEFAULT_LOCALE$1;
  const _locale = isFunction$1(locale) ? DEFAULT_LOCALE$1 : locale;
  const fallbackLocale = isArray$1(options2.fallbackLocale) || isPlainObject(options2.fallbackLocale) || isString$1(options2.fallbackLocale) || options2.fallbackLocale === false ? options2.fallbackLocale : _locale;
  const messages = isPlainObject(options2.messages) ? options2.messages : { [_locale]: {} };
  const datetimeFormats = isPlainObject(options2.datetimeFormats) ? options2.datetimeFormats : { [_locale]: {} };
  const numberFormats = isPlainObject(options2.numberFormats) ? options2.numberFormats : { [_locale]: {} };
  const modifiers = assign$1({}, options2.modifiers || {}, getDefaultLinkedModifiers());
  const pluralRules = options2.pluralRules || {};
  const missing = isFunction$1(options2.missing) ? options2.missing : null;
  const missingWarn = isBoolean(options2.missingWarn) || isRegExp(options2.missingWarn) ? options2.missingWarn : true;
  const fallbackWarn = isBoolean(options2.fallbackWarn) || isRegExp(options2.fallbackWarn) ? options2.fallbackWarn : true;
  const fallbackFormat = !!options2.fallbackFormat;
  const unresolving = !!options2.unresolving;
  const postTranslation = isFunction$1(options2.postTranslation) ? options2.postTranslation : null;
  const processor = isPlainObject(options2.processor) ? options2.processor : null;
  const warnHtmlMessage = isBoolean(options2.warnHtmlMessage) ? options2.warnHtmlMessage : true;
  const escapeParameter = !!options2.escapeParameter;
  const messageCompiler = isFunction$1(options2.messageCompiler) ? options2.messageCompiler : _compiler;
  const messageResolver = isFunction$1(options2.messageResolver) ? options2.messageResolver : _resolver || resolveWithKeyValue;
  const localeFallbacker = isFunction$1(options2.localeFallbacker) ? options2.localeFallbacker : _fallbacker || fallbackWithSimple;
  const fallbackContext = isObject$1(options2.fallbackContext) ? options2.fallbackContext : void 0;
  const internalOptions = options2;
  const __datetimeFormatters = isObject$1(internalOptions.__datetimeFormatters) ? internalOptions.__datetimeFormatters : /* @__PURE__ */ new Map();
  const __numberFormatters = isObject$1(internalOptions.__numberFormatters) ? internalOptions.__numberFormatters : /* @__PURE__ */ new Map();
  const __meta = isObject$1(internalOptions.__meta) ? internalOptions.__meta : {};
  _cid++;
  const context = {
    version: version2,
    cid: _cid,
    locale,
    fallbackLocale,
    messages,
    modifiers,
    pluralRules,
    missing,
    missingWarn,
    fallbackWarn,
    fallbackFormat,
    unresolving,
    postTranslation,
    processor,
    warnHtmlMessage,
    escapeParameter,
    messageCompiler,
    messageResolver,
    localeFallbacker,
    fallbackContext,
    onWarn,
    __meta
  };
  {
    context.datetimeFormats = datetimeFormats;
    context.numberFormats = numberFormats;
    context.__datetimeFormatters = __datetimeFormatters;
    context.__numberFormatters = __numberFormatters;
  }
  return context;
}
function handleMissing(context, key, locale, missingWarn, type) {
  const { missing, onWarn } = context;
  if (missing !== null) {
    const ret = missing(context, locale, key, type);
    return isString$1(ret) ? ret : key;
  } else {
    return key;
  }
}
function updateFallbackLocale(ctx, locale, fallback) {
  const context = ctx;
  context.__localeChainCache = /* @__PURE__ */ new Map();
  ctx.localeFallbacker(ctx, fallback, locale);
}
function format(ast) {
  const msg = (ctx) => formatParts(ctx, ast);
  return msg;
}
function formatParts(ctx, ast) {
  const body = ast.b || ast.body;
  if ((body.t || body.type) === 1) {
    const plural = body;
    const cases = plural.c || plural.cases;
    return ctx.plural(cases.reduce((messages, c) => [
      ...messages,
      formatMessageParts(ctx, c)
    ], []));
  } else {
    return formatMessageParts(ctx, body);
  }
}
function formatMessageParts(ctx, node) {
  const _static = node.s || node.static;
  if (_static) {
    return ctx.type === "text" ? _static : ctx.normalize([_static]);
  } else {
    const messages = (node.i || node.items).reduce((acm, c) => [...acm, formatMessagePart(ctx, c)], []);
    return ctx.normalize(messages);
  }
}
function formatMessagePart(ctx, node) {
  const type = node.t || node.type;
  switch (type) {
    case 3:
      const text = node;
      return text.v || text.value;
    case 9:
      const literal = node;
      return literal.v || literal.value;
    case 4:
      const named = node;
      return ctx.interpolate(ctx.named(named.k || named.key));
    case 5:
      const list = node;
      return ctx.interpolate(ctx.list(list.i != null ? list.i : list.index));
    case 6:
      const linked = node;
      const modifier = linked.m || linked.modifier;
      return ctx.linked(formatMessagePart(ctx, linked.k || linked.key), modifier ? formatMessagePart(ctx, modifier) : void 0, ctx.type);
    case 7:
      const linkedKey = node;
      return linkedKey.v || linkedKey.value;
    case 8:
      const linkedModifier = node;
      return linkedModifier.v || linkedModifier.value;
    default:
      throw new Error(`unhandled node type on format message part: ${type}`);
  }
}
const defaultOnCacheKey = (message) => message;
let compileCache = /* @__PURE__ */ Object.create(null);
const isMessageAST = (val) => isObject$1(val) && (val.t === 0 || val.type === 0) && ("b" in val || "body" in val);
function baseCompile(message, options2 = {}) {
  let detectError = false;
  const onError = options2.onError || defaultOnError;
  options2.onError = (err) => {
    detectError = true;
    onError(err);
  };
  return { ...baseCompile$1(message, options2), detectError };
}
function compile(message, context) {
  if (isString$1(message)) {
    isBoolean(context.warnHtmlMessage) ? context.warnHtmlMessage : true;
    const onCacheKey = context.onCacheKey || defaultOnCacheKey;
    const cacheKey = onCacheKey(message);
    const cached = compileCache[cacheKey];
    if (cached) {
      return cached;
    }
    const { ast, detectError } = baseCompile(message, {
      ...context,
      location: "production" !== "production",
      jit: true
    });
    const msg = format(ast);
    return !detectError ? compileCache[cacheKey] = msg : msg;
  } else {
    const cacheKey = message.cacheKey;
    if (cacheKey) {
      const cached = compileCache[cacheKey];
      if (cached) {
        return cached;
      }
      return compileCache[cacheKey] = format(message);
    } else {
      return format(message);
    }
  }
}
const NOOP_MESSAGE_FUNCTION = () => "";
const isMessageFunction = (val) => isFunction$1(val);
function translate(context, ...args) {
  const { fallbackFormat, postTranslation, unresolving, messageCompiler, fallbackLocale, messages } = context;
  const [key, options2] = parseTranslateArgs(...args);
  const missingWarn = isBoolean(options2.missingWarn) ? options2.missingWarn : context.missingWarn;
  const fallbackWarn = isBoolean(options2.fallbackWarn) ? options2.fallbackWarn : context.fallbackWarn;
  const escapeParameter = isBoolean(options2.escapeParameter) ? options2.escapeParameter : context.escapeParameter;
  const resolvedMessage = !!options2.resolvedMessage;
  const defaultMsgOrKey = isString$1(options2.default) || isBoolean(options2.default) ? !isBoolean(options2.default) ? options2.default : !messageCompiler ? () => key : key : fallbackFormat ? !messageCompiler ? () => key : key : "";
  const enableDefaultMsg = fallbackFormat || defaultMsgOrKey !== "";
  const locale = getLocale$1(context, options2);
  escapeParameter && escapeParams(options2);
  let [formatScope, targetLocale, message] = !resolvedMessage ? resolveMessageFormat(context, key, locale, fallbackLocale, fallbackWarn, missingWarn) : [
    key,
    locale,
    messages[locale] || {}
  ];
  let format2 = formatScope;
  let cacheBaseKey = key;
  if (!resolvedMessage && !(isString$1(format2) || isMessageAST(format2) || isMessageFunction(format2))) {
    if (enableDefaultMsg) {
      format2 = defaultMsgOrKey;
      cacheBaseKey = format2;
    }
  }
  if (!resolvedMessage && (!(isString$1(format2) || isMessageAST(format2) || isMessageFunction(format2)) || !isString$1(targetLocale))) {
    return unresolving ? NOT_REOSLVED : key;
  }
  let occurred = false;
  const onError = () => {
    occurred = true;
  };
  const msg = !isMessageFunction(format2) ? compileMessageFormat(context, key, targetLocale, format2, cacheBaseKey, onError) : format2;
  if (occurred) {
    return format2;
  }
  const ctxOptions = getMessageContextOptions(context, targetLocale, message, options2);
  const msgContext = createMessageContext(ctxOptions);
  const messaged = evaluateMessage(context, msg, msgContext);
  const ret = postTranslation ? postTranslation(messaged, key) : messaged;
  return ret;
}
function escapeParams(options2) {
  if (isArray$1(options2.list)) {
    options2.list = options2.list.map((item) => isString$1(item) ? escapeHtml(item) : item);
  } else if (isObject$1(options2.named)) {
    Object.keys(options2.named).forEach((key) => {
      if (isString$1(options2.named[key])) {
        options2.named[key] = escapeHtml(options2.named[key]);
      }
    });
  }
}
function resolveMessageFormat(context, key, locale, fallbackLocale, fallbackWarn, missingWarn) {
  const { messages, onWarn, messageResolver: resolveValue2, localeFallbacker } = context;
  const locales = localeFallbacker(context, fallbackLocale, locale);
  let message = {};
  let targetLocale;
  let format2 = null;
  const type = "translate";
  for (let i = 0; i < locales.length; i++) {
    targetLocale = locales[i];
    message = messages[targetLocale] || {};
    if ((format2 = resolveValue2(message, key)) === null) {
      format2 = message[key];
    }
    if (isString$1(format2) || isMessageAST(format2) || isMessageFunction(format2)) {
      break;
    }
    const missingRet = handleMissing(
      context,
      // eslint-disable-line @typescript-eslint/no-explicit-any
      key,
      targetLocale,
      missingWarn,
      type
    );
    if (missingRet !== key) {
      format2 = missingRet;
    }
  }
  return [format2, targetLocale, message];
}
function compileMessageFormat(context, key, targetLocale, format2, cacheBaseKey, onError) {
  const { messageCompiler, warnHtmlMessage } = context;
  if (isMessageFunction(format2)) {
    const msg2 = format2;
    msg2.locale = msg2.locale || targetLocale;
    msg2.key = msg2.key || key;
    return msg2;
  }
  if (messageCompiler == null) {
    const msg2 = () => format2;
    msg2.locale = targetLocale;
    msg2.key = key;
    return msg2;
  }
  const msg = messageCompiler(format2, getCompileContext(context, targetLocale, cacheBaseKey, format2, warnHtmlMessage, onError));
  msg.locale = targetLocale;
  msg.key = key;
  msg.source = format2;
  return msg;
}
function evaluateMessage(context, msg, msgCtx) {
  const messaged = msg(msgCtx);
  return messaged;
}
function parseTranslateArgs(...args) {
  const [arg1, arg2, arg3] = args;
  const options2 = {};
  if (!isString$1(arg1) && !isNumber(arg1) && !isMessageFunction(arg1) && !isMessageAST(arg1)) {
    throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
  }
  const key = isNumber(arg1) ? String(arg1) : isMessageFunction(arg1) ? arg1 : arg1;
  if (isNumber(arg2)) {
    options2.plural = arg2;
  } else if (isString$1(arg2)) {
    options2.default = arg2;
  } else if (isPlainObject(arg2) && !isEmptyObject(arg2)) {
    options2.named = arg2;
  } else if (isArray$1(arg2)) {
    options2.list = arg2;
  }
  if (isNumber(arg3)) {
    options2.plural = arg3;
  } else if (isString$1(arg3)) {
    options2.default = arg3;
  } else if (isPlainObject(arg3)) {
    assign$1(options2, arg3);
  }
  return [key, options2];
}
function getCompileContext(context, locale, key, source, warnHtmlMessage, onError) {
  return {
    locale,
    key,
    warnHtmlMessage,
    onError: (err) => {
      onError && onError(err);
      {
        throw err;
      }
    },
    onCacheKey: (source2) => generateFormatCacheKey(locale, key, source2)
  };
}
function getMessageContextOptions(context, locale, message, options2) {
  const { modifiers, pluralRules, messageResolver: resolveValue2, fallbackLocale, fallbackWarn, missingWarn, fallbackContext } = context;
  const resolveMessage = (key) => {
    let val = resolveValue2(message, key);
    if (val == null && fallbackContext) {
      const [, , message2] = resolveMessageFormat(fallbackContext, key, locale, fallbackLocale, fallbackWarn, missingWarn);
      val = resolveValue2(message2, key);
    }
    if (isString$1(val) || isMessageAST(val)) {
      let occurred = false;
      const onError = () => {
        occurred = true;
      };
      const msg = compileMessageFormat(context, key, locale, val, key, onError);
      return !occurred ? msg : NOOP_MESSAGE_FUNCTION;
    } else if (isMessageFunction(val)) {
      return val;
    } else {
      return NOOP_MESSAGE_FUNCTION;
    }
  };
  const ctxOptions = {
    locale,
    modifiers,
    pluralRules,
    messages: resolveMessage
  };
  if (context.processor) {
    ctxOptions.processor = context.processor;
  }
  if (options2.list) {
    ctxOptions.list = options2.list;
  }
  if (options2.named) {
    ctxOptions.named = options2.named;
  }
  if (isNumber(options2.plural)) {
    ctxOptions.pluralIndex = options2.plural;
  }
  return ctxOptions;
}
function datetime(context, ...args) {
  const { datetimeFormats, unresolving, fallbackLocale, onWarn, localeFallbacker } = context;
  const { __datetimeFormatters } = context;
  const [key, value, options2, overrides] = parseDateTimeArgs(...args);
  const missingWarn = isBoolean(options2.missingWarn) ? options2.missingWarn : context.missingWarn;
  isBoolean(options2.fallbackWarn) ? options2.fallbackWarn : context.fallbackWarn;
  const part = !!options2.part;
  const locale = getLocale$1(context, options2);
  const locales = localeFallbacker(
    context,
    // eslint-disable-line @typescript-eslint/no-explicit-any
    fallbackLocale,
    locale
  );
  if (!isString$1(key) || key === "") {
    return new Intl.DateTimeFormat(locale, overrides).format(value);
  }
  let datetimeFormat = {};
  let targetLocale;
  let format2 = null;
  const type = "datetime format";
  for (let i = 0; i < locales.length; i++) {
    targetLocale = locales[i];
    datetimeFormat = datetimeFormats[targetLocale] || {};
    format2 = datetimeFormat[key];
    if (isPlainObject(format2))
      break;
    handleMissing(context, key, targetLocale, missingWarn, type);
  }
  if (!isPlainObject(format2) || !isString$1(targetLocale)) {
    return unresolving ? NOT_REOSLVED : key;
  }
  let id = `${targetLocale}__${key}`;
  if (!isEmptyObject(overrides)) {
    id = `${id}__${JSON.stringify(overrides)}`;
  }
  let formatter = __datetimeFormatters.get(id);
  if (!formatter) {
    formatter = new Intl.DateTimeFormat(targetLocale, assign$1({}, format2, overrides));
    __datetimeFormatters.set(id, formatter);
  }
  return !part ? formatter.format(value) : formatter.formatToParts(value);
}
const DATETIME_FORMAT_OPTIONS_KEYS = [
  "localeMatcher",
  "weekday",
  "era",
  "year",
  "month",
  "day",
  "hour",
  "minute",
  "second",
  "timeZoneName",
  "formatMatcher",
  "hour12",
  "timeZone",
  "dateStyle",
  "timeStyle",
  "calendar",
  "dayPeriod",
  "numberingSystem",
  "hourCycle",
  "fractionalSecondDigits"
];
function parseDateTimeArgs(...args) {
  const [arg1, arg2, arg3, arg4] = args;
  const options2 = {};
  let overrides = {};
  let value;
  if (isString$1(arg1)) {
    const matches = arg1.match(/(\d{4}-\d{2}-\d{2})(T|\s)?(.*)/);
    if (!matches) {
      throw createCoreError(CoreErrorCodes.INVALID_ISO_DATE_ARGUMENT);
    }
    const dateTime = matches[3] ? matches[3].trim().startsWith("T") ? `${matches[1].trim()}${matches[3].trim()}` : `${matches[1].trim()}T${matches[3].trim()}` : matches[1].trim();
    value = new Date(dateTime);
    try {
      value.toISOString();
    } catch (e) {
      throw createCoreError(CoreErrorCodes.INVALID_ISO_DATE_ARGUMENT);
    }
  } else if (isDate(arg1)) {
    if (isNaN(arg1.getTime())) {
      throw createCoreError(CoreErrorCodes.INVALID_DATE_ARGUMENT);
    }
    value = arg1;
  } else if (isNumber(arg1)) {
    value = arg1;
  } else {
    throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
  }
  if (isString$1(arg2)) {
    options2.key = arg2;
  } else if (isPlainObject(arg2)) {
    Object.keys(arg2).forEach((key) => {
      if (DATETIME_FORMAT_OPTIONS_KEYS.includes(key)) {
        overrides[key] = arg2[key];
      } else {
        options2[key] = arg2[key];
      }
    });
  }
  if (isString$1(arg3)) {
    options2.locale = arg3;
  } else if (isPlainObject(arg3)) {
    overrides = arg3;
  }
  if (isPlainObject(arg4)) {
    overrides = arg4;
  }
  return [options2.key || "", value, options2, overrides];
}
function clearDateTimeFormat(ctx, locale, format2) {
  const context = ctx;
  for (const key in format2) {
    const id = `${locale}__${key}`;
    if (!context.__datetimeFormatters.has(id)) {
      continue;
    }
    context.__datetimeFormatters.delete(id);
  }
}
function number(context, ...args) {
  const { numberFormats, unresolving, fallbackLocale, onWarn, localeFallbacker } = context;
  const { __numberFormatters } = context;
  const [key, value, options2, overrides] = parseNumberArgs(...args);
  const missingWarn = isBoolean(options2.missingWarn) ? options2.missingWarn : context.missingWarn;
  isBoolean(options2.fallbackWarn) ? options2.fallbackWarn : context.fallbackWarn;
  const part = !!options2.part;
  const locale = getLocale$1(context, options2);
  const locales = localeFallbacker(
    context,
    // eslint-disable-line @typescript-eslint/no-explicit-any
    fallbackLocale,
    locale
  );
  if (!isString$1(key) || key === "") {
    return new Intl.NumberFormat(locale, overrides).format(value);
  }
  let numberFormat = {};
  let targetLocale;
  let format2 = null;
  const type = "number format";
  for (let i = 0; i < locales.length; i++) {
    targetLocale = locales[i];
    numberFormat = numberFormats[targetLocale] || {};
    format2 = numberFormat[key];
    if (isPlainObject(format2))
      break;
    handleMissing(context, key, targetLocale, missingWarn, type);
  }
  if (!isPlainObject(format2) || !isString$1(targetLocale)) {
    return unresolving ? NOT_REOSLVED : key;
  }
  let id = `${targetLocale}__${key}`;
  if (!isEmptyObject(overrides)) {
    id = `${id}__${JSON.stringify(overrides)}`;
  }
  let formatter = __numberFormatters.get(id);
  if (!formatter) {
    formatter = new Intl.NumberFormat(targetLocale, assign$1({}, format2, overrides));
    __numberFormatters.set(id, formatter);
  }
  return !part ? formatter.format(value) : formatter.formatToParts(value);
}
const NUMBER_FORMAT_OPTIONS_KEYS = [
  "localeMatcher",
  "style",
  "currency",
  "currencyDisplay",
  "currencySign",
  "useGrouping",
  "minimumIntegerDigits",
  "minimumFractionDigits",
  "maximumFractionDigits",
  "minimumSignificantDigits",
  "maximumSignificantDigits",
  "compactDisplay",
  "notation",
  "signDisplay",
  "unit",
  "unitDisplay",
  "roundingMode",
  "roundingPriority",
  "roundingIncrement",
  "trailingZeroDisplay"
];
function parseNumberArgs(...args) {
  const [arg1, arg2, arg3, arg4] = args;
  const options2 = {};
  let overrides = {};
  if (!isNumber(arg1)) {
    throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
  }
  const value = arg1;
  if (isString$1(arg2)) {
    options2.key = arg2;
  } else if (isPlainObject(arg2)) {
    Object.keys(arg2).forEach((key) => {
      if (NUMBER_FORMAT_OPTIONS_KEYS.includes(key)) {
        overrides[key] = arg2[key];
      } else {
        options2[key] = arg2[key];
      }
    });
  }
  if (isString$1(arg3)) {
    options2.locale = arg3;
  } else if (isPlainObject(arg3)) {
    overrides = arg3;
  }
  if (isPlainObject(arg4)) {
    overrides = arg4;
  }
  return [options2.key || "", value, options2, overrides];
}
function clearNumberFormat(ctx, locale, format2) {
  const context = ctx;
  for (const key in format2) {
    const id = `${locale}__${key}`;
    if (!context.__numberFormatters.has(id)) {
      continue;
    }
    context.__numberFormatters.delete(id);
  }
}
/*!
  * vue-i18n v9.8.0
  * (c) 2023 kazuya kawaguchi
  * Released under the MIT License.
  */
const VERSION = "9.8.0";
const code$1 = CoreWarnCodes.__EXTEND_POINT__;
const inc$1 = incrementer(code$1);
({
  FALLBACK_TO_ROOT: code$1,
  NOT_SUPPORTED_PRESERVE: inc$1(),
  NOT_SUPPORTED_FORMATTER: inc$1(),
  NOT_SUPPORTED_PRESERVE_DIRECTIVE: inc$1(),
  NOT_SUPPORTED_GET_CHOICE_INDEX: inc$1(),
  COMPONENT_NAME_LEGACY_COMPATIBLE: inc$1(),
  NOT_FOUND_PARENT_SCOPE: inc$1(),
  IGNORE_OBJ_FLATTEN: inc$1(),
  NOTICE_DROP_ALLOW_COMPOSITION: inc$1()
  // 17
});
const code = CoreErrorCodes.__EXTEND_POINT__;
const inc = incrementer(code);
const I18nErrorCodes = {
  // composer module errors
  UNEXPECTED_RETURN_TYPE: code,
  // legacy module errors
  INVALID_ARGUMENT: inc(),
  // i18n module errors
  MUST_BE_CALL_SETUP_TOP: inc(),
  NOT_INSTALLED: inc(),
  NOT_AVAILABLE_IN_LEGACY_MODE: inc(),
  // directive module errors
  REQUIRED_VALUE: inc(),
  INVALID_VALUE: inc(),
  // vue-devtools errors
  CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN: inc(),
  NOT_INSTALLED_WITH_PROVIDE: inc(),
  // unexpected error
  UNEXPECTED_ERROR: inc(),
  // not compatible legacy vue-i18n constructor
  NOT_COMPATIBLE_LEGACY_VUE_I18N: inc(),
  // bridge support vue 2.x only
  BRIDGE_SUPPORT_VUE_2_ONLY: inc(),
  // need to define `i18n` option in `allowComposition: true` and `useScope: 'local' at `useI18n``
  MUST_DEFINE_I18N_OPTION_IN_ALLOW_COMPOSITION: inc(),
  // Not available Compostion API in Legacy API mode. Please make sure that the legacy API mode is working properly
  NOT_AVAILABLE_COMPOSITION_IN_LEGACY: inc(),
  // for enhancement
  __EXTEND_POINT__: inc()
  // 40
};
function createI18nError(code2, ...args) {
  return createCompileError(code2, null, void 0);
}
const TranslateVNodeSymbol = /* @__PURE__ */ makeSymbol$1("__translateVNode");
const DatetimePartsSymbol = /* @__PURE__ */ makeSymbol$1("__datetimeParts");
const NumberPartsSymbol = /* @__PURE__ */ makeSymbol$1("__numberParts");
const SetPluralRulesSymbol = makeSymbol$1("__setPluralRules");
const InejctWithOptionSymbol = /* @__PURE__ */ makeSymbol$1("__injectWithOption");
const DisposeSymbol = /* @__PURE__ */ makeSymbol$1("__dispose");
function handleFlatJson(obj) {
  if (!isObject$1(obj)) {
    return obj;
  }
  for (const key in obj) {
    if (!hasOwn(obj, key)) {
      continue;
    }
    if (!key.includes(".")) {
      if (isObject$1(obj[key])) {
        handleFlatJson(obj[key]);
      }
    } else {
      const subKeys = key.split(".");
      const lastIndex = subKeys.length - 1;
      let currentObj = obj;
      let hasStringValue = false;
      for (let i = 0; i < lastIndex; i++) {
        if (!(subKeys[i] in currentObj)) {
          currentObj[subKeys[i]] = {};
        }
        if (!isObject$1(currentObj[subKeys[i]])) {
          hasStringValue = true;
          break;
        }
        currentObj = currentObj[subKeys[i]];
      }
      if (!hasStringValue) {
        currentObj[subKeys[lastIndex]] = obj[key];
        delete obj[key];
      }
      if (isObject$1(currentObj[subKeys[lastIndex]])) {
        handleFlatJson(currentObj[subKeys[lastIndex]]);
      }
    }
  }
  return obj;
}
function getLocaleMessages(locale, options2) {
  const { messages, __i18n, messageResolver, flatJson } = options2;
  const ret = isPlainObject(messages) ? messages : isArray$1(__i18n) ? {} : { [locale]: {} };
  if (isArray$1(__i18n)) {
    __i18n.forEach((custom) => {
      if ("locale" in custom && "resource" in custom) {
        const { locale: locale2, resource: resource2 } = custom;
        if (locale2) {
          ret[locale2] = ret[locale2] || {};
          deepCopy(resource2, ret[locale2]);
        } else {
          deepCopy(resource2, ret);
        }
      } else {
        isString$1(custom) && deepCopy(JSON.parse(custom), ret);
      }
    });
  }
  if (messageResolver == null && flatJson) {
    for (const key in ret) {
      if (hasOwn(ret, key)) {
        handleFlatJson(ret[key]);
      }
    }
  }
  return ret;
}
function getComponentOptions(instance) {
  return instance.type;
}
function adjustI18nResources(gl, options2, componentOptions) {
  let messages = isObject$1(options2.messages) ? options2.messages : {};
  if ("__i18nGlobal" in componentOptions) {
    messages = getLocaleMessages(gl.locale.value, {
      messages,
      __i18n: componentOptions.__i18nGlobal
    });
  }
  const locales = Object.keys(messages);
  if (locales.length) {
    locales.forEach((locale) => {
      gl.mergeLocaleMessage(locale, messages[locale]);
    });
  }
  {
    if (isObject$1(options2.datetimeFormats)) {
      const locales2 = Object.keys(options2.datetimeFormats);
      if (locales2.length) {
        locales2.forEach((locale) => {
          gl.mergeDateTimeFormat(locale, options2.datetimeFormats[locale]);
        });
      }
    }
    if (isObject$1(options2.numberFormats)) {
      const locales2 = Object.keys(options2.numberFormats);
      if (locales2.length) {
        locales2.forEach((locale) => {
          gl.mergeNumberFormat(locale, options2.numberFormats[locale]);
        });
      }
    }
  }
}
function createTextNode(key) {
  return createVNode(Text, null, key, 0);
}
const DEVTOOLS_META = "__INTLIFY_META__";
const NOOP_RETURN_ARRAY = () => [];
const NOOP_RETURN_FALSE = () => false;
let composerID = 0;
function defineCoreMissingHandler(missing) {
  return (ctx, locale, key, type) => {
    return missing(locale, key, getCurrentInstance() || void 0, type);
  };
}
const getMetaInfo = /* @__NO_SIDE_EFFECTS__ */ () => {
  const instance = getCurrentInstance();
  let meta = null;
  return instance && (meta = getComponentOptions(instance)[DEVTOOLS_META]) ? { [DEVTOOLS_META]: meta } : null;
};
function createComposer(options2 = {}, VueI18nLegacy) {
  const { __root, __injectWithOption } = options2;
  const _isGlobal = __root === void 0;
  const flatJson = options2.flatJson;
  let _inheritLocale = isBoolean(options2.inheritLocale) ? options2.inheritLocale : true;
  const _locale = ref(
    // prettier-ignore
    __root && _inheritLocale ? __root.locale.value : isString$1(options2.locale) ? options2.locale : DEFAULT_LOCALE$1
  );
  const _fallbackLocale = ref(
    // prettier-ignore
    __root && _inheritLocale ? __root.fallbackLocale.value : isString$1(options2.fallbackLocale) || isArray$1(options2.fallbackLocale) || isPlainObject(options2.fallbackLocale) || options2.fallbackLocale === false ? options2.fallbackLocale : _locale.value
  );
  const _messages = ref(getLocaleMessages(_locale.value, options2));
  const _datetimeFormats = ref(isPlainObject(options2.datetimeFormats) ? options2.datetimeFormats : { [_locale.value]: {} });
  const _numberFormats = ref(isPlainObject(options2.numberFormats) ? options2.numberFormats : { [_locale.value]: {} });
  let _missingWarn = __root ? __root.missingWarn : isBoolean(options2.missingWarn) || isRegExp(options2.missingWarn) ? options2.missingWarn : true;
  let _fallbackWarn = __root ? __root.fallbackWarn : isBoolean(options2.fallbackWarn) || isRegExp(options2.fallbackWarn) ? options2.fallbackWarn : true;
  let _fallbackRoot = __root ? __root.fallbackRoot : isBoolean(options2.fallbackRoot) ? options2.fallbackRoot : true;
  let _fallbackFormat = !!options2.fallbackFormat;
  let _missing = isFunction$1(options2.missing) ? options2.missing : null;
  let _runtimeMissing = isFunction$1(options2.missing) ? defineCoreMissingHandler(options2.missing) : null;
  let _postTranslation = isFunction$1(options2.postTranslation) ? options2.postTranslation : null;
  let _warnHtmlMessage = __root ? __root.warnHtmlMessage : isBoolean(options2.warnHtmlMessage) ? options2.warnHtmlMessage : true;
  let _escapeParameter = !!options2.escapeParameter;
  const _modifiers = __root ? __root.modifiers : isPlainObject(options2.modifiers) ? options2.modifiers : {};
  let _pluralRules = options2.pluralRules || __root && __root.pluralRules;
  let _context;
  const getCoreContext = () => {
    _isGlobal && setFallbackContext(null);
    const ctxOptions = {
      version: VERSION,
      locale: _locale.value,
      fallbackLocale: _fallbackLocale.value,
      messages: _messages.value,
      modifiers: _modifiers,
      pluralRules: _pluralRules,
      missing: _runtimeMissing === null ? void 0 : _runtimeMissing,
      missingWarn: _missingWarn,
      fallbackWarn: _fallbackWarn,
      fallbackFormat: _fallbackFormat,
      unresolving: true,
      postTranslation: _postTranslation === null ? void 0 : _postTranslation,
      warnHtmlMessage: _warnHtmlMessage,
      escapeParameter: _escapeParameter,
      messageResolver: options2.messageResolver,
      messageCompiler: options2.messageCompiler,
      __meta: { framework: "vue" }
    };
    {
      ctxOptions.datetimeFormats = _datetimeFormats.value;
      ctxOptions.numberFormats = _numberFormats.value;
      ctxOptions.__datetimeFormatters = isPlainObject(_context) ? _context.__datetimeFormatters : void 0;
      ctxOptions.__numberFormatters = isPlainObject(_context) ? _context.__numberFormatters : void 0;
    }
    const ctx = createCoreContext(ctxOptions);
    _isGlobal && setFallbackContext(ctx);
    return ctx;
  };
  _context = getCoreContext();
  updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
  function trackReactivityValues() {
    return [
      _locale.value,
      _fallbackLocale.value,
      _messages.value,
      _datetimeFormats.value,
      _numberFormats.value
    ];
  }
  const locale = computed({
    get: () => _locale.value,
    set: (val) => {
      _locale.value = val;
      _context.locale = _locale.value;
    }
  });
  const fallbackLocale = computed({
    get: () => _fallbackLocale.value,
    set: (val) => {
      _fallbackLocale.value = val;
      _context.fallbackLocale = _fallbackLocale.value;
      updateFallbackLocale(_context, _locale.value, val);
    }
  });
  const messages = computed(() => _messages.value);
  const datetimeFormats = /* @__PURE__ */ computed(() => _datetimeFormats.value);
  const numberFormats = /* @__PURE__ */ computed(() => _numberFormats.value);
  function getPostTranslationHandler() {
    return isFunction$1(_postTranslation) ? _postTranslation : null;
  }
  function setPostTranslationHandler(handler) {
    _postTranslation = handler;
    _context.postTranslation = handler;
  }
  function getMissingHandler() {
    return _missing;
  }
  function setMissingHandler(handler) {
    if (handler !== null) {
      _runtimeMissing = defineCoreMissingHandler(handler);
    }
    _missing = handler;
    _context.missing = _runtimeMissing;
  }
  const wrapWithDeps = (fn, argumentParser, warnType, fallbackSuccess, fallbackFail, successCondition) => {
    trackReactivityValues();
    let ret;
    try {
      if ("production" !== "production" || false) ;
      if (!_isGlobal) {
        _context.fallbackContext = __root ? getFallbackContext() : void 0;
      }
      ret = fn(_context);
    } finally {
      if (!_isGlobal) {
        _context.fallbackContext = void 0;
      }
    }
    if (warnType !== "translate exists" && // for not `te` (e.g `t`)
    isNumber(ret) && ret === NOT_REOSLVED || warnType === "translate exists" && !ret) {
      const [key, arg2] = argumentParser();
      return __root && _fallbackRoot ? fallbackSuccess(__root) : fallbackFail(key);
    } else if (successCondition(ret)) {
      return ret;
    } else {
      throw createI18nError(I18nErrorCodes.UNEXPECTED_RETURN_TYPE);
    }
  };
  function t(...args) {
    return wrapWithDeps((context) => Reflect.apply(translate, null, [context, ...args]), () => parseTranslateArgs(...args), "translate", (root) => Reflect.apply(root.t, root, [...args]), (key) => key, (val) => isString$1(val));
  }
  function rt(...args) {
    const [arg1, arg2, arg3] = args;
    if (arg3 && !isObject$1(arg3)) {
      throw createI18nError(I18nErrorCodes.INVALID_ARGUMENT);
    }
    return t(...[arg1, arg2, assign$1({ resolvedMessage: true }, arg3 || {})]);
  }
  function d(...args) {
    return wrapWithDeps((context) => Reflect.apply(datetime, null, [context, ...args]), () => parseDateTimeArgs(...args), "datetime format", (root) => Reflect.apply(root.d, root, [...args]), () => MISSING_RESOLVE_VALUE, (val) => isString$1(val));
  }
  function n(...args) {
    return wrapWithDeps((context) => Reflect.apply(number, null, [context, ...args]), () => parseNumberArgs(...args), "number format", (root) => Reflect.apply(root.n, root, [...args]), () => MISSING_RESOLVE_VALUE, (val) => isString$1(val));
  }
  function normalize(values) {
    return values.map((val) => isString$1(val) || isNumber(val) || isBoolean(val) ? createTextNode(String(val)) : val);
  }
  const interpolate = (val) => val;
  const processor = {
    normalize,
    interpolate,
    type: "vnode"
  };
  function translateVNode(...args) {
    return wrapWithDeps(
      (context) => {
        let ret;
        const _context2 = context;
        try {
          _context2.processor = processor;
          ret = Reflect.apply(translate, null, [_context2, ...args]);
        } finally {
          _context2.processor = null;
        }
        return ret;
      },
      () => parseTranslateArgs(...args),
      "translate",
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (root) => root[TranslateVNodeSymbol](...args),
      (key) => [createTextNode(key)],
      (val) => isArray$1(val)
    );
  }
  function numberParts(...args) {
    return wrapWithDeps(
      (context) => Reflect.apply(number, null, [context, ...args]),
      () => parseNumberArgs(...args),
      "number format",
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (root) => root[NumberPartsSymbol](...args),
      NOOP_RETURN_ARRAY,
      (val) => isString$1(val) || isArray$1(val)
    );
  }
  function datetimeParts(...args) {
    return wrapWithDeps(
      (context) => Reflect.apply(datetime, null, [context, ...args]),
      () => parseDateTimeArgs(...args),
      "datetime format",
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (root) => root[DatetimePartsSymbol](...args),
      NOOP_RETURN_ARRAY,
      (val) => isString$1(val) || isArray$1(val)
    );
  }
  function setPluralRules(rules) {
    _pluralRules = rules;
    _context.pluralRules = _pluralRules;
  }
  function te(key, locale2) {
    return wrapWithDeps(() => {
      if (!key) {
        return false;
      }
      const targetLocale = isString$1(locale2) ? locale2 : _locale.value;
      const message = getLocaleMessage(targetLocale);
      const resolved = _context.messageResolver(message, key);
      return isMessageAST(resolved) || isMessageFunction(resolved) || isString$1(resolved);
    }, () => [key], "translate exists", (root) => {
      return Reflect.apply(root.te, root, [key, locale2]);
    }, NOOP_RETURN_FALSE, (val) => isBoolean(val));
  }
  function resolveMessages(key) {
    let messages2 = null;
    const locales = fallbackWithLocaleChain(_context, _fallbackLocale.value, _locale.value);
    for (let i = 0; i < locales.length; i++) {
      const targetLocaleMessages = _messages.value[locales[i]] || {};
      const messageValue = _context.messageResolver(targetLocaleMessages, key);
      if (messageValue != null) {
        messages2 = messageValue;
        break;
      }
    }
    return messages2;
  }
  function tm(key) {
    const messages2 = resolveMessages(key);
    return messages2 != null ? messages2 : __root ? __root.tm(key) || {} : {};
  }
  function getLocaleMessage(locale2) {
    return _messages.value[locale2] || {};
  }
  function setLocaleMessage(locale2, message) {
    if (flatJson) {
      const _message = { [locale2]: message };
      for (const key in _message) {
        if (hasOwn(_message, key)) {
          handleFlatJson(_message[key]);
        }
      }
      message = _message[locale2];
    }
    _messages.value[locale2] = message;
    _context.messages = _messages.value;
  }
  function mergeLocaleMessage2(locale2, message) {
    _messages.value[locale2] = _messages.value[locale2] || {};
    const _message = { [locale2]: message };
    for (const key in _message) {
      if (hasOwn(_message, key)) {
        handleFlatJson(_message[key]);
      }
    }
    message = _message[locale2];
    deepCopy(message, _messages.value[locale2]);
    _context.messages = _messages.value;
  }
  function getDateTimeFormat(locale2) {
    return _datetimeFormats.value[locale2] || {};
  }
  function setDateTimeFormat(locale2, format2) {
    _datetimeFormats.value[locale2] = format2;
    _context.datetimeFormats = _datetimeFormats.value;
    clearDateTimeFormat(_context, locale2, format2);
  }
  function mergeDateTimeFormat(locale2, format2) {
    _datetimeFormats.value[locale2] = assign$1(_datetimeFormats.value[locale2] || {}, format2);
    _context.datetimeFormats = _datetimeFormats.value;
    clearDateTimeFormat(_context, locale2, format2);
  }
  function getNumberFormat(locale2) {
    return _numberFormats.value[locale2] || {};
  }
  function setNumberFormat(locale2, format2) {
    _numberFormats.value[locale2] = format2;
    _context.numberFormats = _numberFormats.value;
    clearNumberFormat(_context, locale2, format2);
  }
  function mergeNumberFormat(locale2, format2) {
    _numberFormats.value[locale2] = assign$1(_numberFormats.value[locale2] || {}, format2);
    _context.numberFormats = _numberFormats.value;
    clearNumberFormat(_context, locale2, format2);
  }
  composerID++;
  if (__root && inBrowser) {
    watch(__root.locale, (val) => {
      if (_inheritLocale) {
        _locale.value = val;
        _context.locale = val;
        updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
      }
    });
    watch(__root.fallbackLocale, (val) => {
      if (_inheritLocale) {
        _fallbackLocale.value = val;
        _context.fallbackLocale = val;
        updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
      }
    });
  }
  const composer = {
    id: composerID,
    locale,
    fallbackLocale,
    get inheritLocale() {
      return _inheritLocale;
    },
    set inheritLocale(val) {
      _inheritLocale = val;
      if (val && __root) {
        _locale.value = __root.locale.value;
        _fallbackLocale.value = __root.fallbackLocale.value;
        updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
      }
    },
    get availableLocales() {
      return Object.keys(_messages.value).sort();
    },
    messages,
    get modifiers() {
      return _modifiers;
    },
    get pluralRules() {
      return _pluralRules || {};
    },
    get isGlobal() {
      return _isGlobal;
    },
    get missingWarn() {
      return _missingWarn;
    },
    set missingWarn(val) {
      _missingWarn = val;
      _context.missingWarn = _missingWarn;
    },
    get fallbackWarn() {
      return _fallbackWarn;
    },
    set fallbackWarn(val) {
      _fallbackWarn = val;
      _context.fallbackWarn = _fallbackWarn;
    },
    get fallbackRoot() {
      return _fallbackRoot;
    },
    set fallbackRoot(val) {
      _fallbackRoot = val;
    },
    get fallbackFormat() {
      return _fallbackFormat;
    },
    set fallbackFormat(val) {
      _fallbackFormat = val;
      _context.fallbackFormat = _fallbackFormat;
    },
    get warnHtmlMessage() {
      return _warnHtmlMessage;
    },
    set warnHtmlMessage(val) {
      _warnHtmlMessage = val;
      _context.warnHtmlMessage = val;
    },
    get escapeParameter() {
      return _escapeParameter;
    },
    set escapeParameter(val) {
      _escapeParameter = val;
      _context.escapeParameter = val;
    },
    t,
    getLocaleMessage,
    setLocaleMessage,
    mergeLocaleMessage: mergeLocaleMessage2,
    getPostTranslationHandler,
    setPostTranslationHandler,
    getMissingHandler,
    setMissingHandler,
    [SetPluralRulesSymbol]: setPluralRules
  };
  {
    composer.datetimeFormats = datetimeFormats;
    composer.numberFormats = numberFormats;
    composer.rt = rt;
    composer.te = te;
    composer.tm = tm;
    composer.d = d;
    composer.n = n;
    composer.getDateTimeFormat = getDateTimeFormat;
    composer.setDateTimeFormat = setDateTimeFormat;
    composer.mergeDateTimeFormat = mergeDateTimeFormat;
    composer.getNumberFormat = getNumberFormat;
    composer.setNumberFormat = setNumberFormat;
    composer.mergeNumberFormat = mergeNumberFormat;
    composer[InejctWithOptionSymbol] = __injectWithOption;
    composer[TranslateVNodeSymbol] = translateVNode;
    composer[DatetimePartsSymbol] = datetimeParts;
    composer[NumberPartsSymbol] = numberParts;
  }
  return composer;
}
const baseFormatProps = {
  tag: {
    type: [String, Object]
  },
  locale: {
    type: String
  },
  scope: {
    type: String,
    // NOTE: avoid https://github.com/microsoft/rushstack/issues/1050
    validator: (val) => val === "parent" || val === "global",
    default: "parent"
    /* ComponentI18nScope */
  },
  i18n: {
    type: Object
  }
};
function getInterpolateArg({ slots }, keys) {
  if (keys.length === 1 && keys[0] === "default") {
    const ret = slots.default ? slots.default() : [];
    return ret.reduce((slot, current) => {
      return [
        ...slot,
        // prettier-ignore
        ...current.type === Fragment ? current.children : [current]
      ];
    }, []);
  } else {
    return keys.reduce((arg, key) => {
      const slot = slots[key];
      if (slot) {
        arg[key] = slot();
      }
      return arg;
    }, {});
  }
}
function getFragmentableTag(tag) {
  return Fragment;
}
const TranslationImpl = /* @__PURE__ */ defineComponent({
  /* eslint-disable */
  name: "i18n-t",
  props: assign$1({
    keypath: {
      type: String,
      required: true
    },
    plural: {
      type: [Number, String],
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      validator: (val) => isNumber(val) || !isNaN(val)
    }
  }, baseFormatProps),
  /* eslint-enable */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  setup(props, context) {
    const { slots, attrs } = context;
    const i18n = props.i18n || useI18n({
      useScope: props.scope,
      __useComponent: true
    });
    return () => {
      const keys = Object.keys(slots).filter((key) => key !== "_");
      const options2 = {};
      if (props.locale) {
        options2.locale = props.locale;
      }
      if (props.plural !== void 0) {
        options2.plural = isString$1(props.plural) ? +props.plural : props.plural;
      }
      const arg = getInterpolateArg(context, keys);
      const children = i18n[TranslateVNodeSymbol](props.keypath, arg, options2);
      const assignedAttrs = assign$1({}, attrs);
      const tag = isString$1(props.tag) || isObject$1(props.tag) ? props.tag : getFragmentableTag();
      return h(tag, assignedAttrs, children);
    };
  }
});
const Translation = TranslationImpl;
function isVNode(target) {
  return isArray$1(target) && !isString$1(target[0]);
}
function renderFormatter(props, context, slotKeys, partFormatter) {
  const { slots, attrs } = context;
  return () => {
    const options2 = { part: true };
    let overrides = {};
    if (props.locale) {
      options2.locale = props.locale;
    }
    if (isString$1(props.format)) {
      options2.key = props.format;
    } else if (isObject$1(props.format)) {
      if (isString$1(props.format.key)) {
        options2.key = props.format.key;
      }
      overrides = Object.keys(props.format).reduce((options22, prop) => {
        return slotKeys.includes(prop) ? assign$1({}, options22, { [prop]: props.format[prop] }) : options22;
      }, {});
    }
    const parts = partFormatter(...[props.value, options2, overrides]);
    let children = [options2.key];
    if (isArray$1(parts)) {
      children = parts.map((part, index) => {
        const slot = slots[part.type];
        const node = slot ? slot({ [part.type]: part.value, index, parts }) : [part.value];
        if (isVNode(node)) {
          node[0].key = `${part.type}-${index}`;
        }
        return node;
      });
    } else if (isString$1(parts)) {
      children = [parts];
    }
    const assignedAttrs = assign$1({}, attrs);
    const tag = isString$1(props.tag) || isObject$1(props.tag) ? props.tag : getFragmentableTag();
    return h(tag, assignedAttrs, children);
  };
}
const NumberFormatImpl = /* @__PURE__ */ defineComponent({
  /* eslint-disable */
  name: "i18n-n",
  props: assign$1({
    value: {
      type: Number,
      required: true
    },
    format: {
      type: [String, Object]
    }
  }, baseFormatProps),
  /* eslint-enable */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  setup(props, context) {
    const i18n = props.i18n || useI18n({
      useScope: "parent",
      __useComponent: true
    });
    return renderFormatter(props, context, NUMBER_FORMAT_OPTIONS_KEYS, (...args) => (
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      i18n[NumberPartsSymbol](...args)
    ));
  }
});
const NumberFormat = NumberFormatImpl;
const DatetimeFormatImpl = /* @__PURE__ */ defineComponent({
  /* eslint-disable */
  name: "i18n-d",
  props: assign$1({
    value: {
      type: [Number, Date],
      required: true
    },
    format: {
      type: [String, Object]
    }
  }, baseFormatProps),
  /* eslint-enable */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  setup(props, context) {
    const i18n = props.i18n || useI18n({
      useScope: "parent",
      __useComponent: true
    });
    return renderFormatter(props, context, DATETIME_FORMAT_OPTIONS_KEYS, (...args) => (
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      i18n[DatetimePartsSymbol](...args)
    ));
  }
});
const DatetimeFormat = DatetimeFormatImpl;
function getComposer$2(i18n, instance) {
  const i18nInternal = i18n;
  if (i18n.mode === "composition") {
    return i18nInternal.__getInstance(instance) || i18n.global;
  } else {
    const vueI18n = i18nInternal.__getInstance(instance);
    return vueI18n != null ? vueI18n.__composer : i18n.global.__composer;
  }
}
function vTDirective(i18n) {
  const _process = (binding) => {
    const { instance, modifiers, value } = binding;
    if (!instance || !instance.$) {
      throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
    }
    const composer = getComposer$2(i18n, instance.$);
    const parsedValue = parseValue(value);
    return [
      Reflect.apply(composer.t, composer, [...makeParams(parsedValue)]),
      composer
    ];
  };
  const register = (el, binding) => {
    const [textContent, composer] = _process(binding);
    el.__composer = composer;
    el.textContent = textContent;
  };
  const unregister = (el) => {
    if (el.__composer) {
      el.__composer = void 0;
      delete el.__composer;
    }
  };
  const update = (el, { value }) => {
    if (el.__composer) {
      const composer = el.__composer;
      const parsedValue = parseValue(value);
      el.textContent = Reflect.apply(composer.t, composer, [
        ...makeParams(parsedValue)
      ]);
    }
  };
  const getSSRProps = (binding) => {
    const [textContent] = _process(binding);
    return { textContent };
  };
  return {
    created: register,
    unmounted: unregister,
    beforeUpdate: update,
    getSSRProps
  };
}
function parseValue(value) {
  if (isString$1(value)) {
    return { path: value };
  } else if (isPlainObject(value)) {
    if (!("path" in value)) {
      throw createI18nError(I18nErrorCodes.REQUIRED_VALUE, "path");
    }
    return value;
  } else {
    throw createI18nError(I18nErrorCodes.INVALID_VALUE);
  }
}
function makeParams(value) {
  const { path, locale, args, choice, plural } = value;
  const options2 = {};
  const named = args || {};
  if (isString$1(locale)) {
    options2.locale = locale;
  }
  if (isNumber(choice)) {
    options2.plural = choice;
  }
  if (isNumber(plural)) {
    options2.plural = plural;
  }
  return [path, named, options2];
}
function apply(app, i18n, ...options2) {
  const pluginOptions = isPlainObject(options2[0]) ? options2[0] : {};
  const useI18nComponentName = !!pluginOptions.useI18nComponentName;
  const globalInstall = isBoolean(pluginOptions.globalInstall) ? pluginOptions.globalInstall : true;
  if (globalInstall) {
    [!useI18nComponentName ? Translation.name : "i18n", "I18nT"].forEach((name) => app.component(name, Translation));
    [NumberFormat.name, "I18nN"].forEach((name) => app.component(name, NumberFormat));
    [DatetimeFormat.name, "I18nD"].forEach((name) => app.component(name, DatetimeFormat));
  }
  {
    app.directive("t", vTDirective(i18n));
  }
}
const I18nInjectionKey = /* @__PURE__ */ makeSymbol$1("global-vue-i18n");
function createI18n(options2 = {}, VueI18nLegacy) {
  const __globalInjection = isBoolean(options2.globalInjection) ? options2.globalInjection : true;
  const __allowComposition = true;
  const __instances = /* @__PURE__ */ new Map();
  const [globalScope, __global] = createGlobal(options2);
  const symbol = /* @__PURE__ */ makeSymbol$1("");
  function __getInstance(component) {
    return __instances.get(component) || null;
  }
  function __setInstance(component, instance) {
    __instances.set(component, instance);
  }
  function __deleteInstance(component) {
    __instances.delete(component);
  }
  {
    const i18n = {
      // mode
      get mode() {
        return "composition";
      },
      // allowComposition
      get allowComposition() {
        return __allowComposition;
      },
      // install plugin
      async install(app, ...options22) {
        app.__VUE_I18N_SYMBOL__ = symbol;
        app.provide(app.__VUE_I18N_SYMBOL__, i18n);
        if (isPlainObject(options22[0])) {
          const opts = options22[0];
          i18n.__composerExtend = opts.__composerExtend;
          i18n.__vueI18nExtend = opts.__vueI18nExtend;
        }
        let globalReleaseHandler = null;
        if (__globalInjection) {
          globalReleaseHandler = injectGlobalFields(app, i18n.global);
        }
        {
          apply(app, i18n, ...options22);
        }
        const unmountApp = app.unmount;
        app.unmount = () => {
          globalReleaseHandler && globalReleaseHandler();
          i18n.dispose();
          unmountApp();
        };
      },
      // global accessor
      get global() {
        return __global;
      },
      dispose() {
        globalScope.stop();
      },
      // @internal
      __instances,
      // @internal
      __getInstance,
      // @internal
      __setInstance,
      // @internal
      __deleteInstance
    };
    return i18n;
  }
}
function useI18n(options2 = {}) {
  const instance = getCurrentInstance();
  if (instance == null) {
    throw createI18nError(I18nErrorCodes.MUST_BE_CALL_SETUP_TOP);
  }
  if (!instance.isCE && instance.appContext.app != null && !instance.appContext.app.__VUE_I18N_SYMBOL__) {
    throw createI18nError(I18nErrorCodes.NOT_INSTALLED);
  }
  const i18n = getI18nInstance(instance);
  const gl = getGlobalComposer(i18n);
  const componentOptions = getComponentOptions(instance);
  const scope = getScope(options2, componentOptions);
  if (scope === "global") {
    adjustI18nResources(gl, options2, componentOptions);
    return gl;
  }
  if (scope === "parent") {
    let composer2 = getComposer$3(i18n, instance, options2.__useComponent);
    if (composer2 == null) {
      composer2 = gl;
    }
    return composer2;
  }
  const i18nInternal = i18n;
  let composer = i18nInternal.__getInstance(instance);
  if (composer == null) {
    const composerOptions = assign$1({}, options2);
    if ("__i18n" in componentOptions) {
      composerOptions.__i18n = componentOptions.__i18n;
    }
    if (gl) {
      composerOptions.__root = gl;
    }
    composer = createComposer(composerOptions);
    if (i18nInternal.__composerExtend) {
      composer[DisposeSymbol] = i18nInternal.__composerExtend(composer);
    }
    setupLifeCycle(i18nInternal, instance, composer);
    i18nInternal.__setInstance(instance, composer);
  }
  return composer;
}
function createGlobal(options2, legacyMode, VueI18nLegacy) {
  const scope = effectScope();
  {
    const obj = scope.run(() => createComposer(options2));
    if (obj == null) {
      throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
    }
    return [scope, obj];
  }
}
function getI18nInstance(instance) {
  {
    const i18n = inject(!instance.isCE ? instance.appContext.app.__VUE_I18N_SYMBOL__ : I18nInjectionKey);
    if (!i18n) {
      throw createI18nError(!instance.isCE ? I18nErrorCodes.UNEXPECTED_ERROR : I18nErrorCodes.NOT_INSTALLED_WITH_PROVIDE);
    }
    return i18n;
  }
}
function getScope(options2, componentOptions) {
  return isEmptyObject(options2) ? "__i18n" in componentOptions ? "local" : "global" : !options2.useScope ? "local" : options2.useScope;
}
function getGlobalComposer(i18n) {
  return i18n.mode === "composition" ? i18n.global : i18n.global.__composer;
}
function getComposer$3(i18n, target, useComponent = false) {
  let composer = null;
  const root = target.root;
  let current = getParentComponentInstance(target, useComponent);
  while (current != null) {
    const i18nInternal = i18n;
    if (i18n.mode === "composition") {
      composer = i18nInternal.__getInstance(current);
    }
    if (composer != null) {
      break;
    }
    if (root === current) {
      break;
    }
    current = current.parent;
  }
  return composer;
}
function getParentComponentInstance(target, useComponent = false) {
  if (target == null) {
    return null;
  }
  {
    return !useComponent ? target.parent : target.vnode.ctx || target.parent;
  }
}
function setupLifeCycle(i18n, target, composer) {
  {
    onUnmounted(() => {
      const _composer = composer;
      i18n.__deleteInstance(target);
      const dispose = _composer[DisposeSymbol];
      if (dispose) {
        dispose();
        delete _composer[DisposeSymbol];
      }
    }, target);
  }
}
const globalExportProps = [
  "locale",
  "fallbackLocale",
  "availableLocales"
];
const globalExportMethods = ["t", "rt", "d", "n", "tm", "te"];
function injectGlobalFields(app, composer) {
  const i18n = /* @__PURE__ */ Object.create(null);
  globalExportProps.forEach((prop) => {
    const desc = Object.getOwnPropertyDescriptor(composer, prop);
    if (!desc) {
      throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
    }
    const wrap = isRef(desc.value) ? {
      get() {
        return desc.value.value;
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      set(val) {
        desc.value.value = val;
      }
    } : {
      get() {
        return desc.get && desc.get();
      }
    };
    Object.defineProperty(i18n, prop, wrap);
  });
  app.config.globalProperties.$i18n = i18n;
  globalExportMethods.forEach((method) => {
    const desc = Object.getOwnPropertyDescriptor(composer, method);
    if (!desc || !desc.value) {
      throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
    }
    Object.defineProperty(app.config.globalProperties, `$${method}`, desc);
  });
  const dispose = () => {
    delete app.config.globalProperties.$i18n;
    globalExportMethods.forEach((method) => {
      delete app.config.globalProperties[`$${method}`];
    });
  };
  return dispose;
}
{
  registerMessageCompiler(compile);
}
registerMessageResolver(resolveValue);
registerLocaleFallbacker(fallbackWithLocaleChain);
const isVue3 = true;
const STRATEGIES = {
  PREFIX: "prefix",
  PREFIX_EXCEPT_DEFAULT: "prefix_except_default",
  PREFIX_AND_DEFAULT: "prefix_and_default",
  NO_PREFIX: "no_prefix"
};
const DEFAULT_LOCALE = "";
const DEFAULT_STRATEGY = STRATEGIES.PREFIX_EXCEPT_DEFAULT;
const DEFAULT_TRAILING_SLASH = false;
const DEFAULT_ROUTES_NAME_SEPARATOR = "___";
const DEFAULT_LOCALE_ROUTE_NAME_SUFFIX = "default";
const DEFAULT_DETECTION_DIRECTION = "ltr";
const DEFAULT_BASE_URL = "";
const DEFAULT_DYNAMIC_PARAMS_KEY = "";
/*!
  * shared v9.4.1
  * (c) 2023 kazuya kawaguchi
  * Released under the MIT License.
  */
const makeSymbol = (name, shareable = false) => !shareable ? Symbol(name) : Symbol.for(name);
const assign = Object.assign;
const isArray = Array.isArray;
const isFunction = (val) => typeof val === "function";
const isString = (val) => typeof val === "string";
const isSymbol = (val) => typeof val === "symbol";
const isObject = (val) => val !== null && typeof val === "object";
const PLUS_RE = /\+/g;
function decode(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodeQueryKey(text) {
  return decode(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode(text.replace(PLUS_RE, " "));
}
function parseQuery(parametersString = "") {
  const object = {};
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
const TRAILING_SLASH_RE = /\/$|\/\?/;
function hasTrailingSlash(input = "", queryParameters = false) {
  if (!queryParameters) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", queryParameters = false) {
  if (!queryParameters) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  const [s0, ...s] = input.split("?");
  return (s0.slice(0, -1) || "/") + (s.length > 0 ? `?${s.join("?")}` : "");
}
function withTrailingSlash(input = "", queryParameters = false) {
  if (!queryParameters) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  const [s0, ...s] = input.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "");
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash2 = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash: hash2
  };
}
function warn(msg, err) {
  if (typeof console !== "undefined") {
    console.warn(`[vue-i18n-routing] ` + msg);
    if (err) {
      console.warn(err.stack);
    }
  }
}
function getNormalizedLocales(locales) {
  locales = locales || [];
  const normalized = [];
  for (const locale of locales) {
    if (isString(locale)) {
      normalized.push({ code: locale });
    } else {
      normalized.push(locale);
    }
  }
  return normalized;
}
function isI18nInstance(i18n) {
  return i18n != null && "global" in i18n && "mode" in i18n;
}
function isComposer(target) {
  return target != null && !("__composer" in target) && isRef(target.locale);
}
function isVueI18n(target) {
  return target != null && "__composer" in target;
}
function isExportedGlobalComposer(target) {
  return target != null && !("__composer" in target) && !isRef(target.locale);
}
function isLegacyVueI18n$1(target) {
  return target != null && ("__VUE_I18N_BRIDGE__" in target || "_sync" in target);
}
function getComposer(i18n) {
  return isI18nInstance(i18n) ? isComposer(i18n.global) ? i18n.global : i18n.global.__composer : isVueI18n(i18n) ? i18n.__composer : i18n;
}
function getLocale(i18n) {
  const target = isI18nInstance(i18n) ? i18n.global : i18n;
  return isComposer(target) ? target.locale.value : isExportedGlobalComposer(target) || isVueI18n(target) || isLegacyVueI18n$1(target) ? target.locale : target.locale;
}
function getLocales(i18n) {
  const target = isI18nInstance(i18n) ? i18n.global : i18n;
  return isComposer(target) ? target.locales.value : isExportedGlobalComposer(target) || isVueI18n(target) || isLegacyVueI18n$1(target) ? target.locales : target.locales;
}
function getLocaleCodes(i18n) {
  const target = isI18nInstance(i18n) ? i18n.global : i18n;
  return isComposer(target) ? target.localeCodes.value : isExportedGlobalComposer(target) || isVueI18n(target) || isLegacyVueI18n$1(target) ? target.localeCodes : target.localeCodes;
}
function setLocale(i18n, locale) {
  const target = isI18nInstance(i18n) ? i18n.global : i18n;
  if (isComposer(target)) {
    {
      target.locale.value = locale;
    }
  } else if (isExportedGlobalComposer(target) || isVueI18n(target) || isLegacyVueI18n$1(target)) {
    target.locale = locale;
  } else {
    throw new Error("TODO:");
  }
}
function toRawRoute(maybeRoute) {
  return isRef(maybeRoute) ? maybeRoute.value : maybeRoute;
}
function getRouteName(routeName) {
  return isString(routeName) ? routeName : isSymbol(routeName) ? routeName.toString() : "(null)";
}
function getLocaleRouteName(routeName, locale, {
  defaultLocale,
  strategy,
  routesNameSeparator,
  defaultLocaleRouteNameSuffix
}) {
  let name = getRouteName(routeName) + (strategy === "no_prefix" ? "" : routesNameSeparator + locale);
  if (locale === defaultLocale && strategy === "prefix_and_default") {
    name += routesNameSeparator + defaultLocaleRouteNameSuffix;
  }
  return name;
}
function resolveBaseUrl(baseUrl, context) {
  if (isFunction(baseUrl)) {
    return baseUrl(context);
  }
  return baseUrl;
}
function matchBrowserLocale(locales, browserLocales) {
  const matchedLocales = [];
  for (const [index, browserCode] of browserLocales.entries()) {
    const matchedLocale = locales.find((l) => l.iso.toLowerCase() === browserCode.toLowerCase());
    if (matchedLocale) {
      matchedLocales.push({ code: matchedLocale.code, score: 1 - index / browserLocales.length });
      break;
    }
  }
  for (const [index, browserCode] of browserLocales.entries()) {
    const languageCode = browserCode.split("-")[0].toLowerCase();
    const matchedLocale = locales.find((l) => l.iso.split("-")[0].toLowerCase() === languageCode);
    if (matchedLocale) {
      matchedLocales.push({ code: matchedLocale.code, score: 0.999 - index / browserLocales.length });
      break;
    }
  }
  return matchedLocales;
}
const DefaultBrowserLocaleMatcher = matchBrowserLocale;
function compareBrowserLocale(a, b) {
  if (a.score === b.score) {
    return b.code.length - a.code.length;
  }
  return b.score - a.score;
}
const DefaultBrowerLocaleComparer = compareBrowserLocale;
function findBrowserLocale(locales, browserLocales, { matcher = DefaultBrowserLocaleMatcher, comparer = DefaultBrowerLocaleComparer } = {}) {
  const normalizedLocales = [];
  for (const l of locales) {
    const { code: code2 } = l;
    const iso = l.iso || code2;
    normalizedLocales.push({ code: code2, iso });
  }
  const matchedLocales = matcher(normalizedLocales, browserLocales);
  if (matchedLocales.length > 1) {
    matchedLocales.sort(comparer);
  }
  return matchedLocales.length ? matchedLocales[0].code : "";
}
function proxyVueInstance(target) {
  return function() {
    return Reflect.apply(
      target,
      {
        getRouteBaseName: this.getRouteBaseName,
        localePath: this.localePath,
        localeRoute: this.localeRoute,
        localeLocation: this.localeLocation,
        resolveRoute: this.resolveRoute,
        switchLocalePath: this.switchLocalePath,
        localeHead: this.localeHead,
        i18n: this.$i18n,
        route: this.$route,
        router: this.$router
      },
      // eslint-disable-next-line prefer-rest-params
      arguments
    );
  };
}
function extendI18n(i18n, {
  locales = [],
  localeCodes: localeCodes2 = [],
  baseUrl = DEFAULT_BASE_URL,
  hooks = {},
  context = {}
} = {}) {
  const scope = effectScope();
  const orgInstall = i18n.install;
  i18n.install = (vue, ...options2) => {
    const pluginOptions = isPluginOptions(options2[0]) ? assign({}, options2[0]) : { inject: true };
    if (pluginOptions.inject == null) {
      pluginOptions.inject = true;
    }
    const orgComposerExtend = pluginOptions.__composerExtend;
    pluginOptions.__composerExtend = (localComposer) => {
      const globalComposer2 = getComposer(i18n);
      localComposer.locales = computed(() => globalComposer2.locales.value);
      localComposer.localeCodes = computed(() => globalComposer2.localeCodes.value);
      localComposer.baseUrl = computed(() => globalComposer2.baseUrl.value);
      let orgComposerDispose;
      if (isFunction(orgComposerExtend)) {
        orgComposerDispose = Reflect.apply(orgComposerExtend, pluginOptions, [localComposer]);
      }
      return () => {
        orgComposerDispose && orgComposerDispose();
      };
    };
    if (i18n.mode === "legacy") {
      const orgVueI18nExtend = pluginOptions.__vueI18nExtend;
      pluginOptions.__vueI18nExtend = (vueI18n) => {
        extendVueI18n(vueI18n, hooks.onExtendVueI18n);
        let orgVueI18nDispose;
        if (isFunction(orgVueI18nExtend)) {
          orgVueI18nDispose = Reflect.apply(orgVueI18nExtend, pluginOptions, [vueI18n]);
        }
        return () => {
          orgVueI18nDispose && orgVueI18nDispose();
        };
      };
    }
    options2[0] = pluginOptions;
    Reflect.apply(orgInstall, i18n, [vue, ...options2]);
    const globalComposer = getComposer(i18n);
    scope.run(() => {
      extendComposer(globalComposer, { locales, localeCodes: localeCodes2, baseUrl, hooks, context });
      if (i18n.mode === "legacy" && isVueI18n(i18n.global)) {
        extendVueI18n(i18n.global, hooks.onExtendVueI18n);
      }
    });
    const app = vue;
    const exported = i18n.mode === "composition" ? app.config.globalProperties.$i18n : null;
    if (exported) {
      extendExportedGlobal(exported, globalComposer, hooks.onExtendExportedGlobal);
    }
    if (pluginOptions.inject) {
      vue.mixin({
        methods: {
          resolveRoute: proxyVueInstance(resolveRoute),
          localePath: proxyVueInstance(localePath),
          localeRoute: proxyVueInstance(localeRoute),
          localeLocation: proxyVueInstance(localeLocation),
          switchLocalePath: proxyVueInstance(switchLocalePath),
          getRouteBaseName: proxyVueInstance(getRouteBaseName),
          localeHead: proxyVueInstance(localeHead)
        }
      });
    }
    if (app.unmount) {
      const unmountApp = app.unmount;
      app.unmount = () => {
        scope.stop();
        unmountApp();
      };
    }
  };
  return scope;
}
function extendComposer(composer, options2) {
  const { locales, localeCodes: localeCodes2, baseUrl, context } = options2;
  const _locales = ref(locales);
  const _localeCodes = ref(localeCodes2);
  const _baseUrl = ref("");
  composer.locales = computed(() => _locales.value);
  composer.localeCodes = computed(() => _localeCodes.value);
  composer.baseUrl = computed(() => _baseUrl.value);
  {
    _baseUrl.value = resolveBaseUrl(baseUrl, context);
  }
  if (options2.hooks && options2.hooks.onExtendComposer) {
    options2.hooks.onExtendComposer(composer);
  }
}
function extendProperyDescripters(composer, exported, hook) {
  const properties = [
    {
      locales: {
        get() {
          return composer.locales.value;
        }
      },
      localeCodes: {
        get() {
          return composer.localeCodes.value;
        }
      },
      baseUrl: {
        get() {
          return composer.baseUrl.value;
        }
      }
    }
  ];
  hook && properties.push(hook(composer));
  for (const property of properties) {
    for (const [key, descriptor] of Object.entries(property)) {
      Object.defineProperty(exported, key, descriptor);
    }
  }
}
function extendExportedGlobal(exported, g, hook) {
  extendProperyDescripters(g, exported, hook);
}
function extendVueI18n(vueI18n, hook) {
  const c = getComposer(vueI18n);
  extendProperyDescripters(c, vueI18n, hook);
}
function isPluginOptions(options2) {
  return isObject(options2) && ("inject" in options2 || "__composerExtend" in options2 || "__vueI18nExtend" in options2);
}
const GlobalOptionsRegistory = makeSymbol("vue-i18n-routing-gor");
function registerGlobalOptions(router, options2) {
  const _options = router[GlobalOptionsRegistory];
  if (_options) {
    warn("already registered global options");
  } else {
    router[GlobalOptionsRegistory] = options2;
  }
}
function getGlobalOptions(router) {
  return router[GlobalOptionsRegistory] ?? {};
}
function getLocalesRegex(localeCodes2) {
  return new RegExp(`^/(${localeCodes2.join("|")})(?:/|$)`, "i");
}
function createLocaleFromRouteGetter(localeCodes2, routesNameSeparator, defaultLocaleRouteNameSuffix) {
  const localesPattern = `(${localeCodes2.join("|")})`;
  const defaultSuffixPattern = `(?:${routesNameSeparator}${defaultLocaleRouteNameSuffix})?`;
  const regexpName = new RegExp(`${routesNameSeparator}${localesPattern}${defaultSuffixPattern}$`, "i");
  const regexpPath = getLocalesRegex(localeCodes2);
  const getLocaleFromRoute = (route) => {
    if (isObject(route)) {
      if (route.name) {
        const name = isString(route.name) ? route.name : route.name.toString();
        const matches = name.match(regexpName);
        if (matches && matches.length > 1) {
          return matches[1];
        }
      } else if (route.path) {
        const matches = route.path.match(regexpPath);
        if (matches && matches.length > 1) {
          return matches[1];
        }
      }
    } else if (isString(route)) {
      const matches = route.match(regexpPath);
      if (matches && matches.length > 1) {
        return matches[1];
      }
    }
    return "";
  };
  return getLocaleFromRoute;
}
function getI18nRoutingOptions(router, proxy, {
  defaultLocale = DEFAULT_LOCALE,
  defaultDirection = DEFAULT_DETECTION_DIRECTION,
  defaultLocaleRouteNameSuffix = DEFAULT_LOCALE_ROUTE_NAME_SUFFIX,
  routesNameSeparator = DEFAULT_ROUTES_NAME_SEPARATOR,
  strategy = DEFAULT_STRATEGY,
  trailingSlash = DEFAULT_TRAILING_SLASH,
  localeCodes: localeCodes2 = [],
  prefixable: prefixable2 = DefaultPrefixable,
  switchLocalePathIntercepter = DefaultSwitchLocalePathIntercepter,
  dynamicRouteParamsKey = DEFAULT_DYNAMIC_PARAMS_KEY
} = {}) {
  const options2 = getGlobalOptions(router);
  return {
    defaultLocale: proxy.defaultLocale || options2.defaultLocale || defaultLocale,
    defaultDirection: proxy.defaultDirection || options2.defaultDirection || defaultDirection,
    defaultLocaleRouteNameSuffix: proxy.defaultLocaleRouteNameSuffix || options2.defaultLocaleRouteNameSuffix || defaultLocaleRouteNameSuffix,
    routesNameSeparator: proxy.routesNameSeparator || options2.routesNameSeparator || routesNameSeparator,
    strategy: proxy.strategy || options2.strategy || strategy,
    trailingSlash: proxy.trailingSlash || options2.trailingSlash || trailingSlash,
    localeCodes: proxy.localeCodes || options2.localeCodes || localeCodes2,
    prefixable: proxy.prefixable || options2.prefixable || prefixable2,
    switchLocalePathIntercepter: proxy.switchLocalePathIntercepter || options2.switchLocalePathIntercepter || switchLocalePathIntercepter,
    dynamicRouteParamsKey: proxy.dynamicRouteParamsKey || options2.dynamicRouteParamsKey || dynamicRouteParamsKey,
    dynamicParamsInterceptor: options2.dynamicParamsInterceptor || void 0
  };
}
function split(str, index) {
  const result = [str.slice(0, index), str.slice(index)];
  return result;
}
function routeToObject(route) {
  const { fullPath, query, hash: hash2, name, path, params, meta, redirectedFrom, matched } = route;
  return {
    fullPath,
    params,
    query,
    hash: hash2,
    name,
    path,
    meta,
    matched,
    redirectedFrom
  };
}
function isV4Route(val) {
  return isVue3;
}
function resolve(router, route, strategy, locale) {
  var _a, _b;
  if (strategy !== "prefix") {
    return router.resolve(route);
  }
  const [rootSlash, restPath] = split(route.path, 1);
  const targetPath = `${rootSlash}${locale}${restPath === "" ? restPath : `/${restPath}`}`;
  const _route = (_b = (_a = router.options) == null ? void 0 : _a.routes) == null ? void 0 : _b.find((r) => r.path === targetPath);
  if (_route == null) {
    return route;
  }
  const _resolvableRoute = assign({}, route, _route);
  _resolvableRoute.path = targetPath;
  return router.resolve(_resolvableRoute);
}
const RESOLVED_PREFIXED = /* @__PURE__ */ new Set(["prefix_and_default", "prefix_except_default"]);
function prefixable(optons) {
  const { currentLocale, defaultLocale, strategy } = optons;
  const isDefaultLocale = currentLocale === defaultLocale;
  return !(isDefaultLocale && RESOLVED_PREFIXED.has(strategy)) && // no prefix for any language
  !(strategy === "no_prefix");
}
const DefaultPrefixable = prefixable;
function getRouteBaseName(givenRoute) {
  const router = this.router;
  const { routesNameSeparator } = getI18nRoutingOptions(router, this);
  const route = givenRoute != null ? isRef(givenRoute) ? unref(givenRoute) : givenRoute : this.route;
  if (route == null || !route.name) {
    return;
  }
  const name = getRouteName(route.name);
  return name.split(routesNameSeparator)[0];
}
function localePath(route, locale) {
  var _a;
  const localizedRoute = resolveRoute.call(this, route, locale);
  return localizedRoute == null ? "" : ((_a = localizedRoute.redirectedFrom) == null ? void 0 : _a.fullPath) || localizedRoute.fullPath;
}
function localeRoute(route, locale) {
  const resolved = resolveRoute.call(this, route, locale);
  return resolved == null ? void 0 : resolved;
}
function localeLocation(route, locale) {
  const resolved = resolveRoute.call(this, route, locale);
  return resolved == null ? void 0 : resolved;
}
function resolveRoute(route, locale) {
  const router = this.router;
  const i18n = this.i18n;
  const _locale = locale || getLocale(i18n);
  const { routesNameSeparator, defaultLocale, defaultLocaleRouteNameSuffix, strategy, trailingSlash, prefixable: prefixable2 } = getI18nRoutingOptions(router, this);
  let _route;
  if (isString(route)) {
    if (route[0] === "/") {
      const { pathname: path, search, hash: hash2 } = parsePath(route);
      const query = parseQuery(search);
      _route = { path, query, hash: hash2 };
    } else {
      _route = { name: route };
    }
  } else {
    _route = route;
  }
  let localizedRoute = assign({}, _route);
  const isRouteLocationPathRaw = (val) => "path" in val && !!val.path && !("name" in val);
  if (isRouteLocationPathRaw(localizedRoute)) {
    let _resolvedRoute = null;
    try {
      _resolvedRoute = resolve(router, localizedRoute, strategy, _locale);
    } catch {
    }
    const resolvedRoute = _resolvedRoute;
    const resolvedRouteName = getRouteBaseName.call(this, resolvedRoute);
    if (isString(resolvedRouteName)) {
      localizedRoute = {
        name: getLocaleRouteName(resolvedRouteName, _locale, {
          defaultLocale,
          strategy,
          routesNameSeparator,
          defaultLocaleRouteNameSuffix
        }),
        params: resolvedRoute.params,
        query: resolvedRoute.query,
        hash: resolvedRoute.hash
      };
      {
        localizedRoute.state = resolvedRoute.state;
      }
    } else {
      if (prefixable2({ currentLocale: _locale, defaultLocale, strategy })) {
        localizedRoute.path = `/${_locale}${localizedRoute.path}`;
      }
      localizedRoute.path = trailingSlash ? withTrailingSlash(localizedRoute.path, true) : withoutTrailingSlash(localizedRoute.path, true);
    }
  } else {
    if (!localizedRoute.name && !("path" in localizedRoute)) {
      localizedRoute.name = getRouteBaseName.call(this, this.route);
    }
    localizedRoute.name = getLocaleRouteName(localizedRoute.name, _locale, {
      defaultLocale,
      strategy,
      routesNameSeparator,
      defaultLocaleRouteNameSuffix
    });
  }
  try {
    const resolvedRoute = router.resolve(localizedRoute);
    if (isV4Route(resolvedRoute) ? resolvedRoute.name : resolvedRoute.route.name) {
      return resolvedRoute;
    }
    return router.resolve(route);
  } catch (e) {
    if (typeof e === "object" && "type" in e && e.type === 1) {
      return null;
    }
  }
}
const DefaultSwitchLocalePathIntercepter = (path) => path;
function getLocalizableMetaFromDynamicParams(route, key) {
  const metaDefault = {};
  if (key === DEFAULT_DYNAMIC_PARAMS_KEY) {
    return metaDefault;
  }
  const meta = route.meta;
  if (isRef(meta)) {
    return meta.value[key] || metaDefault;
  } else {
    return meta[key] || metaDefault;
  }
}
function switchLocalePath(locale) {
  var _a, _b;
  const route = this.route;
  const name = getRouteBaseName.call(this, route);
  if (!name) {
    return "";
  }
  const { switchLocalePathIntercepter, dynamicRouteParamsKey, dynamicParamsInterceptor } = getI18nRoutingOptions(
    this.router,
    this
  );
  const routeValue = route;
  const routeCopy = routeToObject(routeValue);
  const langSwitchParamsIntercepted = (_b = (_a = dynamicParamsInterceptor == null ? void 0 : dynamicParamsInterceptor()) == null ? void 0 : _a.value) == null ? void 0 : _b[locale];
  const langSwitchParams = getLocalizableMetaFromDynamicParams(route, dynamicRouteParamsKey)[locale] || {};
  const resolvedParams = langSwitchParamsIntercepted ?? langSwitchParams ?? {};
  const _baseRoute = {
    name,
    params: {
      ...routeCopy.params,
      ...resolvedParams
    }
  };
  const baseRoute = assign({}, routeCopy, _baseRoute);
  let path = localePath.call(this, baseRoute, locale);
  path = switchLocalePathIntercepter(path, locale);
  return path;
}
function localeHead({ addDirAttribute = false, addSeoAttributes = false, identifierAttribute = "hid" } = {}) {
  const router = this.router;
  const i18n = this.i18n;
  const { defaultDirection } = getI18nRoutingOptions(router, this);
  const metaObject = {
    htmlAttrs: {},
    link: [],
    meta: []
  };
  if (i18n.locales == null || i18n.baseUrl == null) {
    return metaObject;
  }
  const locale = getLocale(i18n);
  const locales = getLocales(i18n);
  const currentLocale = getNormalizedLocales(locales).find((l) => l.code === locale) || {
    code: locale
  };
  const currentLocaleIso = currentLocale.iso;
  const currentLocaleDir = currentLocale.dir || defaultDirection;
  if (addDirAttribute) {
    metaObject.htmlAttrs.dir = currentLocaleDir;
  }
  if (addSeoAttributes && locale && i18n.locales) {
    if (currentLocaleIso) {
      metaObject.htmlAttrs.lang = currentLocaleIso;
    }
    addHreflangLinks.call(this, locales, unref(i18n.baseUrl), metaObject.link, identifierAttribute);
    addCanonicalLinksAndOgUrl.call(
      this,
      unref(i18n.baseUrl),
      metaObject.link,
      metaObject.meta,
      identifierAttribute,
      addSeoAttributes
    );
    addCurrentOgLocale(currentLocale, currentLocaleIso, metaObject.meta, identifierAttribute);
    addAlternateOgLocales(locales, currentLocaleIso, metaObject.meta, identifierAttribute);
  }
  return metaObject;
}
function addHreflangLinks(locales, baseUrl, link, identifierAttribute) {
  const router = this.router;
  const { defaultLocale, strategy } = getI18nRoutingOptions(router, this);
  if (strategy === STRATEGIES.NO_PREFIX) {
    return;
  }
  const localeMap = /* @__PURE__ */ new Map();
  for (const locale of locales) {
    const localeIso = locale.iso;
    if (!localeIso) {
      warn("Locale ISO code is required to generate alternate link");
      continue;
    }
    const [language, region] = localeIso.split("-");
    if (language && region && (locale.isCatchallLocale || !localeMap.has(language))) {
      localeMap.set(language, locale);
    }
    localeMap.set(localeIso, locale);
  }
  for (const [iso, mapLocale] of localeMap.entries()) {
    const localePath2 = switchLocalePath.call(this, mapLocale.code);
    if (localePath2) {
      link.push({
        [identifierAttribute]: `i18n-alt-${iso}`,
        rel: "alternate",
        href: toAbsoluteUrl(localePath2, baseUrl),
        hreflang: iso
      });
    }
  }
  if (defaultLocale) {
    const localePath2 = switchLocalePath.call(this, defaultLocale);
    if (localePath2) {
      link.push({
        [identifierAttribute]: "i18n-xd",
        rel: "alternate",
        href: toAbsoluteUrl(localePath2, baseUrl),
        hreflang: "x-default"
      });
    }
  }
}
function addCanonicalLinksAndOgUrl(baseUrl, link, meta, identifierAttribute, seoAttributesOptions) {
  const route = this.route;
  const currentRoute = localeRoute.call(this, {
    ...route,
    // eslint-disable-line @typescript-eslint/no-explicit-any
    name: getRouteBaseName.call(this, route)
  });
  if (currentRoute) {
    let href = toAbsoluteUrl(currentRoute.path, baseUrl);
    const canonicalQueries = isObject(seoAttributesOptions) && seoAttributesOptions.canonicalQueries || [];
    if (canonicalQueries.length) {
      const currentRouteQueryParams = currentRoute.query;
      const params = new URLSearchParams();
      for (const queryParamName of canonicalQueries) {
        if (queryParamName in currentRouteQueryParams) {
          const queryParamValue = currentRouteQueryParams[queryParamName];
          if (isArray(queryParamValue)) {
            queryParamValue.forEach((v) => params.append(queryParamName, v || ""));
          } else {
            params.append(queryParamName, queryParamValue || "");
          }
        }
      }
      const queryString = params.toString();
      if (queryString) {
        href = `${href}?${queryString}`;
      }
    }
    link.push({
      [identifierAttribute]: "i18n-can",
      rel: "canonical",
      href
    });
    meta.push({
      [identifierAttribute]: "i18n-og-url",
      property: "og:url",
      content: href
    });
  }
}
function addCurrentOgLocale(currentLocale, currentLocaleIso, meta, identifierAttribute) {
  const hasCurrentLocaleAndIso = currentLocale && currentLocaleIso;
  if (!hasCurrentLocaleAndIso) {
    return;
  }
  meta.push({
    [identifierAttribute]: "i18n-og",
    property: "og:locale",
    // Replace dash with underscore as defined in spec: language_TERRITORY
    content: hypenToUnderscore(currentLocaleIso)
  });
}
function addAlternateOgLocales(locales, currentLocaleIso, meta, identifierAttribute) {
  const localesWithoutCurrent = locales.filter((locale) => {
    const localeIso = locale.iso;
    return localeIso && localeIso !== currentLocaleIso;
  });
  if (localesWithoutCurrent.length) {
    const alternateLocales = localesWithoutCurrent.map((locale) => ({
      [identifierAttribute]: `i18n-og-alt-${locale.iso}`,
      property: "og:locale:alternate",
      content: hypenToUnderscore(locale.iso)
    }));
    meta.push(...alternateLocales);
  }
}
function hypenToUnderscore(str) {
  return (str || "").replace(/-/g, "_");
}
function toAbsoluteUrl(urlOrPath, baseUrl) {
  if (urlOrPath.match(/^https?:\/\//)) {
    return urlOrPath;
  }
  return baseUrl + urlOrPath;
}
function proxyForComposable(options2, target) {
  const {
    router,
    route,
    i18n,
    defaultLocale,
    strategy,
    defaultLocaleRouteNameSuffix,
    trailingSlash,
    routesNameSeparator
  } = options2;
  return function(...args) {
    return Reflect.apply(
      target,
      {
        router,
        route,
        i18n,
        defaultLocale,
        strategy,
        defaultLocaleRouteNameSuffix,
        trailingSlash,
        routesNameSeparator
      },
      args
    );
  };
}
function useLocalePath$1({
  router = useRouter$1(),
  route = useRoute$1(),
  i18n = useI18n(),
  defaultLocale = void 0,
  defaultLocaleRouteNameSuffix = void 0,
  routesNameSeparator = void 0,
  strategy = void 0,
  trailingSlash = void 0
} = {}) {
  return proxyForComposable(
    { router, route, i18n, defaultLocale, defaultLocaleRouteNameSuffix, routesNameSeparator, strategy, trailingSlash },
    localePath
  );
}
function useSwitchLocalePath$1({
  router = useRouter$1(),
  route = useRoute$1(),
  i18n = useI18n(),
  defaultLocale = void 0,
  defaultLocaleRouteNameSuffix = void 0,
  routesNameSeparator = void 0,
  strategy = void 0,
  trailingSlash = void 0
} = {}) {
  return proxyForComposable(
    {
      router,
      route,
      i18n,
      defaultLocale,
      defaultLocaleRouteNameSuffix,
      routesNameSeparator,
      strategy,
      trailingSlash
    },
    switchLocalePath
  );
}
function useLocaleHead$1({
  addDirAttribute = false,
  addSeoAttributes = false,
  identifierAttribute = "hid",
  strategy = void 0,
  defaultLocale = void 0,
  route = useRoute$1(),
  router = useRouter$1(),
  i18n = useI18n()
} = {}) {
  const _router = router;
  const metaObject = ref({
    htmlAttrs: {},
    link: [],
    meta: []
  });
  function updateMeta(_route) {
    metaObject.value = Reflect.apply(
      localeHead,
      {
        router,
        route: _route,
        i18n,
        defaultLocale,
        strategy
      },
      [{ addDirAttribute, addSeoAttributes, identifierAttribute }]
    );
  }
  {
    updateMeta(toRawRoute(_router.currentRoute));
  }
  return metaObject;
}
const resource$t = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Search for Emoji, 🖱️Click to Copy - Emoji Search Engine Supporting 30 Languages" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Let Emojis bring your content to life. SearchEmoji houses the largest collection of emojis from around the world. Find exactly the emoji you need through powerful search functions—either search by keyword or browse through categories. Preview any emoji and copy it with one click into your documents, messages, and social posts." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji detail" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") was added to the Emoji family in version " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", included in the [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] category, with a Unicode encoding of " }, { "t": 4, "k": "code" }, { "t": 3, "v": " and officially named as " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Search for Emoji, Click to Copy" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Enter a keyword" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Switch to dark mode" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Switch to light mode" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Back to top" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Click to" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Click to copy: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Go to detail" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copy Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Qualified" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "fully-qualified" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimally-qualified" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "unqualified" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "component" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Skin tone:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "light" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medium-light" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medium" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medium-dark" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "dark" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojis" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Group:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Size:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Refresh" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Keyword: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" returns no results' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copy Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode name" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Search keyword" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Version" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Code" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Group" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Display on other platform" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " for " }, { "t": 4, "k": "platform" }, { "t": 3, "v": " platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Right click to copy or download" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copied" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "For professional: Multilingual Vector Icon Search Engine, includes more than 200k icons." } }
};
const resource$s = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji - 支持 30 个语言的 Emoji 搜索引擎。🔍一词搜索，🖱️一键复制！" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "丰富多彩的 Emoji 助你内容更生动。SearchEmoji 收录最全的 Emoji 表情库，并提供强大的搜索功能，你可以通过关键词精确查找，或者通过分类筛选、预览，并一键复制到你的文章、聊天及社交媒体中。" } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji 详情" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") 于 v" }, { "t": 4, "k": "version" }, { "t": 3, "v": " 版本加入到 Emoji 家族，收录在[" }, { "t": 4, "k": "group" }, { "t": 3, "v": "]分类中，Unicode 的编码为 " }, { "t": 4, "k": "code" }, { "t": 3, "v": "，官方命名为： " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "一词搜索，一键复制！" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "输入关键词搜索" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "切换到暗黑模式" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "切换到日间模式" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "回顶部" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "点击时" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "点击复制：" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "打开详情" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "复制 Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "是否合格" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "完全合格" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "基本合格" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "不合格" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "组件" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "肤色：" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "浅色" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "中浅色" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "中性色" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "中深色" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "深色" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "个 Emoji" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "分组：" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "尺寸：" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "刷新" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": "关键词：“" }, { "t": 4, "k": "keyword" }, { "t": 3, "v": "” 搜索不到任何结果" }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "复制 Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode 名称" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "搜索关键词" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "版本" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "编码" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "分组" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "其他平台上的展现" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " 平台中的 " }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "点击右键可复制或下载图片" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "已复制" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "给专业人士：多语言矢量图标搜索引擎，收录超过 20 万图标！" } }
};
const resource$r = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Busque Emojis, 🖱️Haga clic para Copiar - Motor de búsqueda de emojis compatible con 30 idiomas" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Deje que los emojis den vida a su contenido. SearchEmoji alberga la colección más grande de emojis de todo el mundo. Encuentre exactamente el emoji que necesita a través de potentes funciones de búsqueda, ya sea buscando por palabra clave o navegando por categorías. Previsualice cualquier emoji y cópielo con un clic en sus documentos, mensajes y publicaciones en redes sociales." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Detalle de Emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") fue agregado a la familia Emoji en la versión " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", incluido en la categoría [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], con una codificación Unicode de " }, { "t": 4, "k": "code" }, { "t": 3, "v": " y oficialmente nombrado como " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Busque Emojis, Haga clic para Copiar" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ingrese una palabra clave" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cambiar al modo oscuro" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cambiar al modo claro" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Volver arriba" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Haga clic para" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Haga clic para copiar: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ir al detalle" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiar Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Calificado" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "totalmente calificado" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mínimamente calificado" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "no calificado" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "componente" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tono de piel:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "pálido" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medio claro" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medio" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medio oscuro" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "oscuro" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojis" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grupo:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tamaño:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Actualizar" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Palabra clave: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" no devuelve resultados' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiar Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nombre Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Buscar palabra clave" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versión" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Código" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grupo" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Mostrar en otra plataforma" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " para la plataforma " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Haga clic derecho para copiar o descargar la imagen" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiado" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Para profesionales: Motor de búsqueda de iconos vectoriales multilingüe, que incluye más de 200k iconos." } }
};
const resource$q = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "支援 30 種語言的 Emoji 搜尋引擎。🔍一詞搜尋，🖱️一鍵複製！" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "豐富多彩的 Emoji 助你內容更生動。SearchEmoji 收錄最全的 Emoji 表情庫，並提供強大的搜尋功能，你可以透過關鍵詞精確查找，或者透過分類篩選、預覽，並一鍵複製到你的文章、聊天及社交媒體中。" } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji 詳情" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") 於 v " }, { "t": 4, "k": "version" }, { "t": 3, "v": " 版本加入到 Emoji 家族，收錄在 [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] 分類中，Unicode 的編碼為 " }, { "t": 4, "k": "code" }, { "t": 3, "v": "，官方命名為： " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "一詞搜尋，一鍵複製！" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "輸入關鍵詞搜尋" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "切換到暗黑模式" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "切換到日間模式" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "返回頂部" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "點擊時" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "點擊複製：" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "打開詳情" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "複製 Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "是否合格" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "完全合格" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "基本合格" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "不合格" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "組件" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "膚色：" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "淺色" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "中淺色" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "中性色" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "中深色" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "深色" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "個 Emoji" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "分組：" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "尺寸：" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "刷新" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": "關鍵詞：“" }, { "t": 4, "k": "keyword" }, { "t": 3, "v": "” 搜尋不到任何結果" }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "複製 Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode 名稱" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "搜索關鍵詞" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "版本" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "編碼" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "分組" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "其他平台上的展現" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " 平台中的 " }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "點選右鍵可複製或下載圖片" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "已複製" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "適用於專業人士：多語言向量圖標搜索引擎，含有超過 20 萬個圖標。" } }
};
const resource$p = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Suche nach Emoji, 🖱️Klicken zum Kopieren - Emoji-Suchmaschine mit Unterstützung von 30 Sprachen" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Lassen Sie Emojis Ihre Inhalte lebendig werden. SearchEmoji beherbergt die größte Sammlung von Emojis aus der ganzen Welt. Finden Sie genau das Emoji, das Sie benötigen, mithilfe leistungsstarker Suchfunktionen – entweder suchen Sie nach Schlüsselworten oder durchsuchen Kategorien. Vorschau jedes Emojis und kopieren Sie es mit einem Klick in Ihre Dokumente, Nachrichten und Social-Media-Posts." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji-Detail" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") wurde in Version " }, { "t": 4, "k": "version" }, { "t": 3, "v": " der Emoji-Familie hinzugefügt und in der [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] Kategorie eingeschlossen, mit einer Unicode-Kodierung von " }, { "t": 4, "k": "code" }, { "t": 3, "v": " und offiziell benannt als " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Suche nach Emoji, Klicken zum Kopieren" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Geben Sie ein Schlüsselwort ein" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Wechseln zum Dunkelmodus" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Wechseln zum Hellmodus" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Zurück nach oben" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klicken zum" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klicken zum Kopieren: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Zur Detailansicht" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji kopieren" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Qualifiziert" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "vollständig qualifiziert" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimal qualifiziert" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "nicht qualifiziert" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Komponente" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Hautfarbe:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "hell" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mittel-hell" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mittel" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mittel-dunkel" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "dunkel" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojis" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gruppe:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Größe:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Aktualisieren" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Schlüsselwort: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" ergibt keine Ergebnisse' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji kopieren" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode-Name" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Suchschlüsselwort" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Version" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Code" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gruppe" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Auf anderen Plattformen anzeigen" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " für " }, { "t": 4, "k": "platform" }, { "t": 3, "v": " Plattform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klicken Sie mit der rechten Maustaste, um das Bild zu kopieren oder herunterzuladen" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopiert" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Für Fachleute: Mehrsprachige Vektor-Symbol-Suchmaschine, enthält mehr als 200.000 Symbole." } }
};
const resource$o = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Emojiを検索、🖱️クリックしてコピー - 30か国語をサポートする絵文字検索エンジン" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "絵文字でコンテンツをより活気づけましょう。SearchEmojiは世界中からの絵文字コレクションを収集しています。キーワードで検索したり、カテゴリを閲覧したりと、必要な絵文字を強力な検索機能で見つけましょう。プレビューして一クリックでドキュメントやメッセージ、ソーシャル投稿にコピーできます。" } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - 絵文字詳細" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") はバージョン" }, { "t": 4, "k": "version" }, { "t": 3, "v": "で絵文字ファミリーに追加され、[" }, { "t": 4, "k": "group" }, { "t": 3, "v": "]カテゴリに含まれており、Unicodeエンコーディングは" }, { "t": 4, "k": "code" }, { "t": 3, "v": "、正式な名前は" }, { "t": 4, "k": "oName" }, { "t": 3, "v": "です" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "絵文字を検索、クリックしてコピー" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "キーワードを入力" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ダークモードに切り替え" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ライトモードに切り替え" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "トップに戻る" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "クリックして" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "クリックしてコピー：" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "詳細へ" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "絵文字をコピー" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "合格" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "完全合格" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "基本合格" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "不合格" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "部品" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "肌の色：" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ライト" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ミディアムライト" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ミディアム" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ミディアムダーク" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ダーク" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "個の絵文字" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "グループ：" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "サイズ：" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "更新" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": "キーワード「" }, { "t": 4, "k": "keyword" }, { "t": 3, "v": "」に一致する結果がありません" }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "絵文字をコピー" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode名" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "キーワードを検索" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "バージョン" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "コード" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "グループ内" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "他のプラットフォームで表示" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": "プラットフォームの" }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "右クリックして画像をコピーまたはダウンロード" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "コピー済み" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "専門家向け：マルチリンガルベクターアイコン検索エンジン、20 万以上のアイコンを収録。" } }
};
const resource$n = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Recherche d'emoji, 🖱️Cliquez pour copier - Moteur de recherche d'emoji prenant en charge 30 langues" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Laissez les emojis donner vie à votre contenu. SearchEmoji abrite la plus grande collection d'emojis du monde entier. Trouvez exactement l'emoji dont vous avez besoin grâce à de puissantes fonctions de recherche - recherchez par mot-clé ou parcourez les catégories. Prévisualisez n'importe quel emoji et copiez-le en un clic dans vos documents, messages et publications sociales." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Détail de l'emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " (" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") a été ajouté à la famille Emoji dans la version " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", inclus dans la catégorie [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], avec un codage Unicode de " }, { "t": 4, "k": "code" }, { "t": 3, "v": " et officiellement nommé " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Recherche d'emoji, Cliquez pour copier" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Entrez un mot-clé" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Passer en mode sombre" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Passer en mode clair" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Retour en haut" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cliquez pour" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cliquez pour copier :" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Aller à la détail" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copier l'emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Qualifié" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "entièrement qualifié" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimale-qualifié" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "non qualifié" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "composant" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tonalité de la peau :" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "clair" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "moyennement claire" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "moyenne" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "moyennement foncée" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "foncée" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojis" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Groupe :" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Taille :" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Actualiser" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Le mot-clé "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" ne retourne aucun résultat' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copier l'emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nom Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Mot-clé de recherche" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Version" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Code" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Groupe" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Affichage sur une autre plateforme" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " pour la plateforme " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cliquez avec le bouton droit pour copier ou télécharger l'image" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copié" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Pour les professionnels : Moteur de recherche d'icônes vectorielles multilingue, comprenant plus de 200 000 icônes." } }
};
const resource$m = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍이모지 검색, 🖱️클릭하여 복사 - 30개 언어를 지원하는 이모지 검색 엔진" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "이모지를 통해 콘텐츠를 다채롭게 표현해보세요. SearchEmoji는 전 세계에서 오는 이모지 컬렉션을 보유하고 있습니다. 강력한 검색 기능을 통해 원하는 이모지를 찾아보세요. 키워드로 검색하거나 카테고리를 통해 미리 보기를 하고 클릭 한 번으로 문서, 메시지 및 소셜 미디어에 복사합니다." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - 이모지 상세" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ")은 Emoji 패밀리의 " }, { "t": 4, "k": "version" }, { "t": 3, "v": " 버전에 포함되었으며 [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] 범주에 포함되어 있습니다. 유니코드 인코딩은 " }, { "t": 4, "k": "code" }, { "t": 3, "v": "이고 공식 이름은 " }, { "t": 4, "k": "oName" }, { "t": 3, "v": "으로 지정되었습니다." }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "이모지 검색, 클릭하여 복사" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "키워드를 입력하세요" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "다크 모드로 전환" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "라이트 모드로 전환" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "맨 위로" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "클릭하여" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "클릭하여 복사: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "상세 정보" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "이모지 복사" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "자격 있음" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "완전 자격 있음" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "최소 자격 있음" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "부적격" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "구성 요소" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "피부톤:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "라이트" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "미디엄 라이트" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "미디엄" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "미디엄 다크" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "다크" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "이모지" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "그룹:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "크기:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "새로고침" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": '키워드: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '"에 대한 결과가 없습니다' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "이모지 복사" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "유니코드 이름" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "키워드 검색" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "버전" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "코드" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "그룹내" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "다른 플랫폼에 표시" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " 플랫폼을 위한 " }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "이미지 복사 또는 다운로드를 하려면 마우스 오른쪽 버튼을 클릭하세요" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "복사됨" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "전문가를 위한: 다국어 벡터 아이콘 검색 엔진, 20만개 이상의 아이콘을 포함하고 있습니다." } }
};
const resource$l = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Pesquisar Emoji, 🖱️Clique para Copiar - Motor de Busca de Emoji Suportando 30 Idiomas" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Deixe os Emojis dar vida ao seu conteúdo. O SearchEmoji possui a maior coleção de emojis do mundo. Encontre exatamente o emoji de que precisa através de poderosas funções de pesquisa - pesquise por palavra-chave ou navegue pelas categorias. Visualize qualquer emoji e copie-o com um clique para seus documentos, mensagens e publicações nas redes sociais." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Detalhe do Emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") foi adicionado à família de Emojis na versão " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", incluído na categoria [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], com uma codificação Unicode de " }, { "t": 4, "k": "code" }, { "t": 3, "v": " e oficialmente nomeado como " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Pesquisar Emoji, Clique para Copiar" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Digite uma palavra-chave" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Mudar para modo escuro" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Mudar para modo claro" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Voltar ao topo" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Clique para" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Clique para copiar: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ir para detalhes" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiar Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Qualificado" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "totalmente qualificado" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimamente qualificado" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "não qualificado" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "componente" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tom de pele:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "claro" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "médio-claro" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "médio" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "médio-escuro" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "escuro" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojis" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grupo:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tamanho:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Atualizar" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Palavra-chave: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" não retorna resultados' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiar Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nome Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Pesquisar palavra-chave" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versão" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Código" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grupo" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Exibir em outra plataforma" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " para a plataforma " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Clique com o botão direito para copiar ou baixar a imagem" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiado" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Para profissionais: Motor de busca de ícones vetoriais multilíngue, inclui mais de 200 mil ícones." } }
};
const resource$k = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍 Поиск по эмодзи, 🖱️ Щелкните, чтобы скопировать - Поисковый двигатель эмодзи, поддерживающий 30 языков" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Позвольте эмодзи оживить ваш контент. SearchEmoji содержит крупнейшую коллекцию эмодзи со всего мира. Найдите именно тот эмодзи, который вам нужен, с помощью мощных функций поиска - можно искать по ключевому слову или просматривать по категориям. Предварительный просмотр любого эмодзи и его копирование одним щелчком в ваши документы, сообщения и социальные публикации." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Эмодзи детализация" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") был добавлен в семейство эмодзи в версии " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", включенной в категорию [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], с Юникод-кодировкой " }, { "t": 4, "k": "code" }, { "t": 3, "v": " и официально названный как " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Поиск по эмодзи, Щелкните, чтобы скопировать" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Введите ключевое слово" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Переключиться в темный режим" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Переключиться в светлый режим" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Наверх" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Нажмите, чтобы" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Кликните, чтобы скопировать: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Перейти к деталям" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Скопировать эмодзи" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Квалифицированный" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "полностью квалифицированный" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "минимально квалифицированный" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "неквалифицированный" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "компонент" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Цвет кожи:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "светлый" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "средне-светлый" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "средний" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "средне-темный" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "темный" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "эмодзи" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Группа:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Размер:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Обновить" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Ключевое слово: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" не дает результатов' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Скопировать эмодзи" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Имя Юникод" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Поиск по ключевому слову" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Версия" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Код" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "В группе" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Отображение на другой платформе" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " для платформы " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Щелкните правой кнопкой мыши, чтобы скопировать или загрузить изображение" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Скопировано" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Для профессионалов: мультиязычный поисковик векторных иконок, включает более 200 тыс. иконок." } }
};
const resource$j = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Emoji Arama, 🖱️Kopyalamak için Tıklayın - 30 Dil Desteği Sunan Emoji Arama Motoru" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojilerle İçeriğinizi Canlandırın. SearchEmoji, dünyanın dört bir yanından emojilerin en büyük koleksiyonunu barındırıyor. Güçlü arama işlevleri sayesinde ihtiyacınız olan emojiyi tam olarak bulun—ister anahtar kelime ile arayın ister kategorilere göz atın. Herhangi bir emojiyi önizleyin ve bir tıklama ile belgelerinize, mesajlarınıza ve sosyal gönderilerinize kopyalayın." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji detayı" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") Emoji ailesine " }, { "t": 4, "k": "version" }, { "t": 3, "v": " sürümünde eklenmiş olup [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] kategorisine dahil edilmiş, " }, { "t": 4, "k": "code" }, { "t": 3, "v": " Unicode kodlamasına ve resmi olarak " }, { "t": 4, "k": "oName" }, { "t": 3, "v": " olarak adlandırılmıştır" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji Arama, Kopyalamak için Tıklayın" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Bir anahtar kelime girin" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Koyu moda geç" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Açık moda geç" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Başa dön" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tıklayarak" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopyalamak için tıklayın:" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Detaya git" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji Kopyala" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Uyumlu" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "tam uyumlu" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimum uyumlu" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "uyumsuz" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "bileşen" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ten rengi:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "açık" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "orta açık" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "orta" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "orta koyu" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "koyu" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojiler" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grup:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Boyut:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Yenile" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Anahtar kelime: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" hiçbir sonuç döndürmedi' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji Kopyala" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode adı" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Anahtar kelime ara" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Sürüm" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kod" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grup" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Diğer platformda göster" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " platformu için " }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Resmi kopyalamak veya indirmek için sağ tıklayın" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiado" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Para profesionales: Motor de búsqueda multilingüe de iconos vectoriales, que incluye más de 200k iconos." } }
};
const resource$i = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍البحث عن الرموز التعبيرية، 🖱️انقر للنسخ - محرك بحث الرموز التعبيرية يدعم 30 لغة" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "دع الرموز التعبيرية تعيش محتواك. يحتوي محرك بحث الرموز التعبيرية على أكبر مجموعة من الرموز التعبيرية من جميع أنحاء العالم. ابحث عن الرمز التعبيري الذي تحتاجه بدقة من خلال وظائف البحث القوية - ابحث إما بكلمة رئيسية أو تصفح الفئات. اعرض أي رمز تعبيري وانسخه بنقرة واحدة إلى وثائقك، رسائلك ومنشوراتك الاجتماعية." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - تفاصيل الرمز التعبيري" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") تمت إضافته إلى عائلة الرموز التعبيرية في الإصدار " }, { "t": 4, "k": "version" }, { "t": 3, "v": " ، مضمنًا في تصنيف [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] ، بترميز يونيكود " }, { "t": 4, "k": "code" }, { "t": 3, "v": " واسمه الرسمي " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "محرك بحث الرموز التعبيرية" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ابحث عن رمز تعبيري، انقر للنسخ" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "أدخل كلمة رئيسية" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "التبديل إلى الوضع الداكن" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "التبديل إلى الوضع النهاري" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "العودة إلى الأعلى" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "انقر للـ" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "انقر للنسخ: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "الانتقال إلى التفاصيل" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "نسخ الرمز التعبيري" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "مؤهل" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "مؤهل بشكل كامل" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "مؤهل بشكل أساسي" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "غير مؤهل" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "مكون" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": ":درجة البشرة" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "فاتح" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "فاتح متوسط" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "متوسط" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "متوسط داكن" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "داكن" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "رموز تعبيرية" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": ":المجموعة" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "الحجم:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "تحديث" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'الكلمة الرئيسية: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" لا ترجع نتائج' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "نسخ الرمز التعبيري" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "اسم اليونيكود" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "البحث بكلمة رئيسية" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "الإصدار" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "الترميز" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "في التصنيف" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "عرض في منصة أخرى" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " لمنصة " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "انقر بزر الماوس الأيمن للنسخ أو تحميل الصورة" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "تم النسخ" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "بالنسبة للمحترفين: محرك بحث الرموز التعبيرية متعدد اللغات، يشمل أكثر من 200 ألف رمز." } }
};
const resource$h = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Cerca Emoji, 🖱️Clicca per Copiare - Motore di Ricerca Emoji che Supporta 30 Lingue" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Lascia che gli emoji diano vita al tuo contenuto. SearchEmoji ospita la più grande raccolta di emoji provenienti da tutto il mondo. Trova esattamente l'emoji di cui hai bisogno attraverso potenti funzioni di ricerca, sia cercando per parole chiave che navigando tra le categorie. Anteprima di qualsiasi emoji e copialo con un clic nei tuoi documenti, messaggi e post sui social." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Dettaglio emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") è stato aggiunto alla famiglia Emoji nella versione " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", incluso nella categoria [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], con una codifica Unicode di " }, { "t": 4, "k": "code" }, { "t": 3, "v": " e ufficialmente chiamato " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cerca Emoji, Clicca per Copiare" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Inserisci una parola chiave" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Passa alla modalità scura" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Passa alla modalità luminosa" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Torna in alto" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Clicca per" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Clicca per copiare: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Vai al dettaglio" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copia Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Qualificato" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "totalmente qualificato" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimamente qualificato" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "non qualificato" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "componente" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tonalità della pelle:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "chiaro" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mediamente chiaro" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medio" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mediamente scuro" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "scuro" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gruppo:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Dimensioni:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Aggiorna" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'La parola chiave "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" non restituisce risultati' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copia Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nome Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cerca parola chiave" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versione" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Codice" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gruppo" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Mostra su altre piattaforme" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " per la piattaforma " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Fai clic con il pulsante destro per copiare o scaricare l'immagine" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiato" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Per professionisti: motore di ricerca di icone vettoriali multilingue, include più di 200.000 icone." } }
};
const resource$g = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍इमोजी खोजें, 🖱️क्लिक करें - 30 भाषाओं का समर्थन करने वाला इमोजी खोज इंजन" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "इमोजिज से अपनी सामग्री को जीवंत करें। SearchEmoji में दुनिया भर से इमोजी का बड़ा संग्रह है। शक्तिशाली खोज कार्यों के माध्यम से उन्हें खोजें—संकेतशब्द से खोजें या श्रेणियों के माध्यम से ब्राउज करें। हर इमोजी का पूर्वावलोकन करें और उसे एक क्लिक में अपने दस्तावेज़ों, संदेशों और सामाजिक पोस्ट में कॉपी करें।" } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - इमोजी विवरण" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") को संस्करण " }, { "t": 4, "k": "version" }, { "t": 3, "v": " में इमोजी परिवार में जोड़ा गया था, [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] श्रेणी में शामिल है, " }, { "t": 4, "k": "code" }, { "t": 3, "v": " का यूनिकोड कोड है और आधिकारिक रूप से " }, { "t": 4, "k": "oName" }, { "t": 3, "v": " नामकरण किया गया है" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "इमोजी खोजें, क्लिक करें" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "एक संकेतशब्द दर्ज करें" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "डार्क मोड पर स्विच करें" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "लाइट मोड पर स्विच करें" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "शीर्ष पर वापस जाएं" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "क्लिक करें" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "क्लिक करके कॉपी करें: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "विवरण पर जाएं" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "इमोजी की कॉपी करें" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "योग्य" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "पूरी तरह से योग्य" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "न्यूनतम रूप से योग्य" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "अयोग्य" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "घटक" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "चमड़ी रंग:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "हल्का" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "मध्यम-हल्का" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "मध्यम" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "मध्यम-गहरा" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "गहरा" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "इमोजिज" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "समूह:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "आकार:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ताज़ा करें" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'संकेतशब्द: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" कोई परिणाम नहीं देता' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "इमोजी कॉपी करें" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "यूनिकोड नाम" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "संकेतशब्द खोजें" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "संस्करण" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "कोड" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "समूह में" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "अन्य प्लेटफ़ॉर्म पर प्रदर्शित करें" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " प्लेटफ़ॉर्म के लिए " }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "छवि की कॉपी या डाउनलोड करने के लिए दाएँ क्लिक करें" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "कॉपी की गई" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "पेशेवरों के लिए: बहुभाषी वेक्टर आइकन खोज इंजन, 20 लाख से अधिक आइकन शामिल है।" } }
};
const resource$f = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Wyszukaj emoji, 🖱️Kliknij, aby skopiować - Wyszukiwarka emoji obsługująca 30 języków" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Pozwól, że emotikony ożywią twój kontent. SearchEmoji zawiera największą kolekcję emoji z całego świata. Znajdź dokładnie to emoji, którego potrzebujesz dzięki potężnym funkcjom wyszukiwania – wyszukaj według słowa kluczowego lub przeglądaj według kategorii. Podglądaj dowolne emoji i skopiuj je jednym kliknięciem do swoich dokumentów, wiadomości oraz postów na portalach społecznościowych." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Szczegóły emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") został dodany do rodziny emoji w wersji " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", umieszczony w kategorii [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], z kodowaniem Unicode " }, { "t": 4, "k": "code" }, { "t": 3, "v": " i oficjalnie nazwany jako " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Wyszukaj emoji, Kliknij, aby skopiować" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Wpisz słowo kluczowe" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Przełącz się w tryb ciemny" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Przełącz się w tryb jasny" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Wróć do góry" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kliknij, aby" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kliknij, aby skopiować: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Idź do szczegółów" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Skopiuj emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kwalifikowany" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "w pełni kwalifikowany" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimalnie kwalifikowany" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "niekwalifikowany" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "składnik" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Odcień skóry:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "jasny" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "średnio jasny" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "średni" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "średnio ciemny" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ciemny" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emotikony" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grupa:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Rozmiar:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Odśwież" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": "Słowo kluczowe: „" }, { "t": 4, "k": "keyword" }, { "t": 3, "v": "” nie zwraca żadnych wyników" }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopiuj emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nazwa Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Szukaj słowa kluczowego" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Wersja" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kod" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "W grupie" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Wyświetl na innej platformie" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " dla platformy " }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kliknij prawym przyciskiem myszy, aby skopiować lub pobrać obraz" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Skopiowano" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Dla profesjonalistów: Wielojęzyczny silnik wyszukiwania ikon wektorowych, zawiera ponad 200 000 ikon." } }
};
const resource$e = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ইমোজি অনুসন্ধানে, ইমোজি কপি করতে ব্যবহার করুন - ৩০ ভাষা সমর্থিত ইমোজি অনুসন্ধান ইঞ্জিন" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "এমোজিগুলি আপনার সামগ্রীকে জীবন আনুন। SearchEmoji পৃথিবীর বিভিন্ন অঞ্চল থেকে এমোজি সংগ্রহের সর্ববৃহৎ সংগ্রহ তালিকাগুলি ঘর করে। কীভাবেই অনুরোধ করুন শক্তিশালী অনুসন্ধান ফাংশনের মাধ্যমে আপনি প্রয়োজনের যে ইমোজি খুঁজে পেতে পারেন- বিভাগের মধ্যে বা বিভাগ দুটি মোটর់স, একাধিক ইমোজি আপাত দেখুন এবং এক ক্লিকে তা এসে এ নাম দলের সাথে অনুমোদিত করুন।" } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - ইমোজি বিবরণ" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") ভার্সন " }, { "t": 4, "k": "version" }, { "t": 3, "v": " এ ইমোজি পরিবারে যোগ দেওয়া হয়েছে, [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] বিভাগে অন্তর্ভুক্ত, একটি ইউনিকোড এনকোডিং এর সাথে " }, { "t": 4, "k": "code" }, { "t": 3, "v": " এবং সরকারীভাবে " }, { "t": 4, "k": "oName" }, { "t": 3, "v": " হিসাবে নামকরণ করা হয়েছে" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ইমোজি অনুসন্ধানে, কপি করুন" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "একটি শব্দ লিখুন" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ডার্ক মোডে সুইচ করুন" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "লাইট মোডে লেজ সুইচ করুন" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "শীর্ষে ফেরে যান" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ক্লিক করুন" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ক্লিক করুন এ যে:" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "বিবরণ দেখুন" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ইমোজি কপি করুন" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "যোগ্য" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "সম্পূর্ণভাবে যোগ্য" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "সর্বনির্বাচিতভাবে যোগ্য" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "অযোগ্য" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "কম্পোনেন্ট" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ত্বকটি:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "হালকা" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "মাঝের প্রকাশ" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "মাঝে" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "মাঝের অন্ধকার" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "অন্ধকার" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ইমোজিস" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "গ্রুপ:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "আয়তন:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ফিরে আসুন" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'শব্দ: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" কোনও ফলাফল প্রদান করে না' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ইমোজি কপি করুন" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ইউনিকোড নাম" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "অনুসন্ধান শব্দ" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "সংস্করণ" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "কোড" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "উপ-বিভাগ" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "অন্যান্য প্ল্যাটফর্মে প্রদর্শন" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " প্ল্যাটফর্মে জন্য " }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ডান ক্লিক করে চিত্র কপি করুন অথবা ডাউনলোড করুন" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "কপি করা হয়েছে" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "পেশাদারদের জন্য: বহুভাষিক ভেক্টর আইকন অনুসন্ধান ইঞ্জিন, ২০০ হাজারেরও অধিক আইকন রয়েছে।" } }
};
const resource$d = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Zoek naar Emoji, 🖱️Klik om te kopiëren - Emoji-zoekmachine met ondersteuning voor 30 talen" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Laat emoji's leven inblazen in je content. SearchEmoji herbergt de grootste verzameling emoji's van over de hele wereld. Vind precies de emoji die je nodig hebt via krachtige zoekfuncties - door te zoeken op trefwoord of door te bladeren door categorieën. Voorbeeld van een emoji en kopieer deze met één klik naar je documenten, berichten en sociale posts." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji detail" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") werd toegevoegd aan de Emoji-familie in versie " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", opgenomen in de [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] categorie, met een Unicode-encoding van " }, { "t": 4, "k": "code" }, { "t": 3, "v": " en officieel benoemd als " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Zoek naar Emoji, Klik om te kopiëren" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Voer een trefwoord in" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Overschakelen naar donkere modus" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Overschakelen naar lichte modus" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Terug naar boven" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik op" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik om te kopiëren: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ga naar detail" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopieer Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gekwalificeerd" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "volledig gekwalificeerd" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimaal gekwalificeerd" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "niet gekwalificeerd" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "component" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Huidskleur:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "licht" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "licht-midden" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "gemiddeld" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "midden-donker" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "donker" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji's" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Groep:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grootte:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Vernieuwen" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Trefwoord: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" levert geen resultaten op' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopieer Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode-naam" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Zoekwoord zoeken" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versie" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Code" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Groep" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Weergave op ander platform" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " voor " }, { "t": 4, "k": "platform" }, { "t": 3, "v": " platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik met rechts om de afbeelding te kopiëren of te downloaden" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gekopieerd" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Voor professionals: Meertalige Vector Pictogrammen Zoekmachine, bevat meer dan 200k pictogrammen." } }
};
const resource$c = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Пошук Emoji, 🖱️натисніть, щоб скопіювати - Пошуковий двигун Emoji з підтримкою 30 мов" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Нехай емодзі оживлять ваш вміст. SearchEmoji містить найбільшу колекцію емодзі з усього світу. Знайдіть саме той емодзі, який вам потрібен завдяки потужним функціям пошуку - шукайте за ключовим словом або переглядайте за категоріями. Попередній перегляд будь-якого емодзі та його копіювання одним натисканням у ваши документи, повідомлення та соціальні пости." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Деталі емодзі" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " (" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") був доданий до родини Emoji у версії " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", включений в категорію [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], з Юнікод-кодуванням " }, { "t": 4, "k": "code" }, { "t": 3, "v": " та офіційно названий як " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Пошук Emoji, Натисніть, щоб скопіювати" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Введіть ключове слово" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Перейти до темного режиму" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Перейти до світлого режиму" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Назад до верху" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Натисніть, щоб" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Натисніть, щоб скопіювати: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Перейти до деталей" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Скопіювати Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Кваліфікований" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "повністю кваліфікований" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "мінімально кваліфікований" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "не кваліфікований" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "компонент" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Відтінок шкіри:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "світлий" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "середньо-світлий" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "середній" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "середньо-темний" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "темний" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Емодзі" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Група:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Розмір:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Оновити" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Ключове слово: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" не повернуло результатів' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Скопіювати Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Юнікод-назва" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Пошук за ключовим словом" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Версія" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Код" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "У групі" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Показ на інших платформах" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " для платформи " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Клацніть правою кнопкою миші, щоб скопіювати або завантажити зображення" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Скопійовано" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Для професіоналів: багатомовний пошук векторних піктограм, включає понад 200 тис. піктограм." } }
};
const resource$b = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Cari Emoji, 🖱️Klik untuk Menyalin - Mesin Pencari Emoji Mendukung 30 Bahasa" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Biarkan Emoji Memeriahkan Konten Anda. SearchEmoji memiliki koleksi emoji terbesar dari seluruh dunia. Temukan emoji yang Anda butuhkan melalui fungsi pencarian yang kuat—baik dengan kata kunci atau jelajahi melalui kategori. Pratinjau emoji apa pun dan salinnya dengan satu klik ke dokumen, pesan, dan pos sosial Anda." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Detail Emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") ditambahkan ke keluarga Emoji dalam versi " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", disertakan dalam kategori [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], dengan pengkodean Unicode " }, { "t": 4, "k": "code" }, { "t": 3, "v": " dan resmi dinamai sebagai " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cari Emoji, Klik untuk Menyalin" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Masukkan kata kunci" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Beralih ke mode gelap" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Beralih ke mode terang" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kembali ke atas" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik untuk" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik untuk menyalin: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Buka detail" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Salin Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Berkualifikasi" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sepenuhnya berkualifikasi" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimally-qualified" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "tidak berkualifikasi" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "komponen" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tone kulit:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "terang" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sedang-terang" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sedang" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sedang-gelap" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "gelap" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grup:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ukuran:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Segarkan" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Kata kunci: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" tidak mengembalikan hasil' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Salin Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nama Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cari kata kunci" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versi" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kode" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grup" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tampilkan di platform lain" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " untuk platform " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik kanan untuk menyalin atau mengunduh gambar" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Disalin" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Untuk para profesional: Mesin Pencari Ikona Vektor Multibahasa, termasuk lebih dari 200k ikona." } }
};
const resource$a = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Cari Emoji, 🖱️Klik untuk Menyalin - Enjin Carian Emoji yang Menyokong 30 Bahasa" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Biarkan Emojis Menghidupkan Kandungan Anda. SearchEmoji memuatkan koleksi emoji terbesar dari seluruh dunia. Cari emoji yang anda perlukan melalui fungsi carian yang kuat—sama ada dengan kata kunci atau melayari melalui kategori. Pratonton mana-mana emoji dan salinnya dengan sekali klik ke dalam dokumen, mesej, dan pos sosial anda." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Butiran Emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") telah ditambahkan kepada keluarga Emoji dalam versi " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", dimasukkan dalam kategori [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], dengan kod sumber Unicode " }, { "t": 4, "k": "code" }, { "t": 3, "v": " dan dinamakan secara rasmi sebagai " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cari Emoji, Klik untuk Menyalin" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Masukkan kata kunci" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tukar ke mod gelap" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tukar ke mod cahaya" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kembali ke atas" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik untuk" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik untuk menyalin:" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Pergi ke butiran" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Salin Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kelayakan" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sepenuhnya berkelayakan" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minima berkelayakan" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "tidak berkelayakan" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "komponen" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tona kulit:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ringan" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sederhana-ringan" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sederhana" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sederhana-gelap" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "gelap" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojis" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kumpulan:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Saiz:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Segar" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Kata kunci: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" tidak menghasilkan sebarang hasil' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Salin Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nama Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cari kata kunci" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versi" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kod" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Dalam Kumpulan" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Paparan di platform lain" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " untuk platform " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik kanan untuk menyalin atau muat turun imej" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Disalin" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Untuk profesional: Enjin Carian Ikon Vektor Bermultibahasa, termasuk lebih daripada 200k ikon." } }
};
const resource$9 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Tìm kiếm biểu tượng cảm xúc, 🖱️Bấm để Sao chép - Công cụ Tìm kiếm Biểu tượng Cảm xúc Hỗ trợ 30 Ngôn ngữ" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Hãy để Biểu tượng Cảm xúc Mang Nội dung của Bạn Đến Đời. SearchEmoji chứa đựng bộ sưu tập biểu tượng cảm xúc lớn nhất từ khắp nơi trên thế giới. Tìm chính xác biểu tượng cảm xúc bạn cần qua các chức năng tìm kiếm mạnh mẽ—bạn có thể tìm kiếm theo từ khóa hoặc duyệt qua các danh mục. Xem trước bất kỳ biểu tượng cảm xúc nào và sao chép nó bằng một lần nhấn vào tài liệu, tin nhắn và bài đăng trên mạng xã hội của bạn." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Chi tiết biểu tượng cảm xúc" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") được thêm vào gia đình Biểu tượng Cảm xúc từ phiên bản " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", bao gồm trong danh mục [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], với mã Unicode " }, { "t": 4, "k": "code" }, { "t": 3, "v": " và một tên chính thức là " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tìm kiếm Biểu tượng Cảm xúc, Bấm để Sao chép" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nhập từ khóa" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Chuyển sang chế độ tối" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Chuyển sang chế độ sáng" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Quay lại đầu trang" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nhấp để" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nhấp để sao chép: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Đi tới chi tiết" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Sao chép Biểu tượng Cảm xúc" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Đủ điều kiện" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "đủ điều kiện" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "cơ bản đủ điều kiện" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "không đủ điều kiện" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "thành phần" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tông da:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sáng" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "trung bình sáng" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "trung bình" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "trung bình đậm" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "tối" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Biểu tượng cảm xúc" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nhóm:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kích thước:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Làm mới" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Từ khóa: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" không có kết quả' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Sao chép Biểu tượng Cảm xúc" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tên Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tìm kiếm từ khóa" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Phiên bản" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Mã" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nhóm" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Hiển thị trên nền tảng khác" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " cho nền tảng " }, { "t": 4, "k": "name" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nhấp chuột phải để sao chép hoặc tải ảnh" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Đã sao chép" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Dành cho chuyên gia: Công cụ tìm kiếm biểu tượng đa ngôn ngữ, bao gồm hơn 200 nghìn biểu tượng." } }
};
const resource$8 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍ค้นหา Emoji, 🖱️คลิกเพื่อคัดลอก - มอเตอร์การค้นหา Emoji รองรับ 30 ภาษา" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ให้ Emoji ช่วยให้เนื้อหาของคุณมีชีวิตชีวา. SearchEmoji บริการสำรวจครบทั้ง Emoji จากทั่วโลก ค้นหาลำดับโดยใช้ฟังก์ชันค้นหาที่มีประสิทธิภาพ—ค้นหาตามคำหลักหรือดูผ่านหมวดหมู่ ดูตัวอย่างของ emoji และคัดลอกไปในเอกสาร ข้อความ และโพสต์ต่างๆ ได้โดยคลิกเพียงครั้งเดียว" } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - รายละเอียด Emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") เพิ่มเข้าสู่ครอบครัวของ Emoji ในเวอร์ชัน " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", รวมในหมวด[" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] พร้อมรหัส Unicode เป็น " }, { "t": 4, "k": "code" }, { "t": 3, "v": " และมีชื่อทางการว่า " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ค้นหา Emoji, คลิกเพื่อคัดลอก" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ป้อนคำหลัก" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "สลับเป็นโหมดมืด" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "สลับเป็นโหมดให้แสงสว่าง" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ย้อนกลับไปด้านบน" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "คลิกเพื่อ" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "คลิกเพื่อคัดลอก: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ไปที่รายละเอียด" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "คัดลอก Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "มีคุณภาพ" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "สมบูรณ์แบบ" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "มีคุณภาพน้อย" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ไม่มีคุณภาพ" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ส่วนประกอบ" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "โทนผิว:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "สว่าง" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "สีอ่อน" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "กลาง" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "เข้มกลาง" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "เข้ม" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "อีโมจิ" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "กลุ่ม:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ขนาด:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "รีเฟรช" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'คำหลัก: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" ไม่ได้ส่งกลับผลลัพธ์ใดๆ' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "คัดลอก Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ชื่อ Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "คำหลักในการค้นหา" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "เวอร์ชัน" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "รหัส" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ในกลุ่ม" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "แสดงบนแพลตฟอร์มอื่น" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " สำหรับแพลตฟอร์ม " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "คลิกขวาเพื่อคัดลอกหรือดาวน์โหลดรูปภาพ" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "คัดลอกแล้ว" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "สำหรับผู้เชี่ยวชาญ: เครื่องมือค้นหาไอคอนเวกเตอร์หลายภาษา รวมถึงมากกว่า 200k ไอคอน" } }
};
const resource$7 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Sök efter emotikoner, 🖱️Klicka för att kopiera - Emotikon-sökmotor som stöder 30 språk" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Låt emotikoner ge liv åt ditt innehåll. SearchEmoji har den största samlingen av emotikoner från hela världen. Hitta exakt den emotikon du behöver genom kraftfulla sökfunktioner - antingen genom nyckelordssökning eller genom att bläddra i kategorier. Förhandsvisa valfri emotikon och kopiera den med ett klick till dina dokument, meddelanden och sociala inlägg." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emotikoninformation" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") lades till i Emotikon-familjen i version " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", inkluderad i kategorin [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], med en Unicode-kodning av " }, { "t": 4, "k": "code" }, { "t": 3, "v": " och officiellt namngiven som " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Sök efter emotikoner, Klicka för att kopiera" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ange en nyckelord" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Växla till mörkt läge" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Växla till ljust läge" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tillbaka till toppen" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klicka för att" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klicka för att kopiera: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gå till information" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopiera emotikon" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kvalificerad" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "helt kvalificerad" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimt kvalificerad" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ouppkvalificerad" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "komponent" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Hudton:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ljus" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medium-ljus" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medium" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "medium-mörk" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mörk" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emotikoner" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grupp:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Storlek:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Uppdatera" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Nyckelord: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" returnerar inga resultat' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopiera emotikon" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode-namn" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Sök nyckelord" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Version" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kod" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grupp" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Visa på annan plattform" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " för " }, { "t": 4, "k": "platform" }, { "t": 3, "v": "-plattform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Högerklicka för att kopiera eller ladda ner bilden" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopierad" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "För professionella: Multispråkig vektorikonssökmotor, inkluderar mer än 200 000 ikoner." } }
};
const resource$6 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Αναζήτηση για Emoji, 🖱️Κάντε κλικ για αντιγραφή - Μηχανή αναζήτησης Emoji με υποστήριξη 30 Γλωσσών" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Επιτρέψτε στα Emoji να φέρουν ζωή στο περιεχόμενό σας. Το SearchEmoji διαθέτει τη μεγαλύτερη συλλογή από emojis από όλο τον κόσμο. Βρείτε ακριβώς το emoji που χρειάζεστε μέσω ισχυρών λειτουργιών αναζήτησης - είτε αναζητήστε με λέξεις-κλειδιά είτε περιηγηθείτε στις κατηγορίες. Προεπισκόπηση οποιουδήποτε emoji και αντιγράψτε το με ένα κλικ στα έγγραφά σας, τα μηνύματά σας και τις κοινωνικές αναρτήσεις σας." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Λεπτομερειακή περιγραφή Emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") προστέθηκε στην οικογένεια των Emoji στην έκδοση " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", συμπεριλαμβανομένης στην κατηγορία [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], με μια Unicode κωδικοποίηση " }, { "t": 4, "k": "code" }, { "t": 3, "v": " και επίσημα ονόματι " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Αναζήτηση για Emoji, Κάντε κλικ για αντιγραφή" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Εισαγωγή λέξης-κλειδιού" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Μετάβαση σε σκούρη λειτουργία" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Μετάβαση σε φωτεινή λειτουργία" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Πίσω στην κορυφή" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Κάντε κλικ για" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Κάντε κλικ για αντιγραφή: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Μετάβαση στη λεπτομέρεια" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Αντιγραφή Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Προσόντα" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "πλήρως προσόντα" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ελάχιστα προσόντα" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "μη προσόντα" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "συστατικό" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Χρώματος δέρματος:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "φωτεινό" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "μεσαία-φωτεινό" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "μέτριο" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "μεσαία-σκούρο" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "σκούρο" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojis" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ομάδα:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Μέγεθος:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ανανέωση" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Η λέξη-κλειδί "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" δεν επιστρέφει αποτελέσματα' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Αντιγραφή Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Όνομα Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Αναζήτηση λέξης-κλειδιού" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Έκδοση" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Κωδικός" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ομάδα" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Εμφάνιση σε άλλη πλατφόρμα" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " για την πλατφόρμα " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Κάντε δεξί κλικ για αντιγραφή ή λήψη της εικόνας" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Αντιγράφηκε" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Για επαγγελματίες: Πολύγλωσση μηχανή αναζήτησης εικονιδίων διανύσματος, περιλαμβάνει περισσότερα από 200k εικονίδια." } }
};
const resource$5 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍חיפוש אמוג'ים, 🖱️לחץ כדי להעתיק - מנוע חיפוש אמוג'ים התומך ב-30 שפות" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "תן לאמוג'ים להביא את התוכן שלך לחיים. SearchEmoji מכיל את האוסף הגדול ביותר של אמוג'ים מרחבי העולם. מצא בדיוק את האמוג'י שאתה זקוק אליו דרך פונקציות חיפוש חזקות - חיפוש לפי מילת מפתח או ניווט דרך קטגוריות. הצגה מקדימה של כל אמוג'י והעתקתו בלחיצה אחת למסמכים, הודעות ופוסטים ברשתות חברתיות." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - פרטי אמוג'י" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " (" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") נוסף למשפחת האמוג'ים בגרסה " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", כלול בקטגוריה [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], עם קידוד יוניקוד בקוד " }, { "t": 4, "k": "code" }, { "t": 3, "v": " ושם רשמי כ- " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "חיפוש אמוג'ים, לחץ כדי להעתיק" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "הכנס מילת מפתח" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "החלף למצב חשוך" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "החלף למצב אור" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "חזור לראש" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "לחץ כדי ל" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "לחץ כדי להעתיק: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "עבור לפרטים" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "העתק אמוג'י" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "מוסמך" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "מלא כשרות" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "מינימום כשרות" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "לא מוסמך" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "רכיב" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "גוון עור:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "בהיר" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "בהיר במידה מסוימת" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "בינוני" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "בינוני מעט" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "כהה" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "אמוג'ים" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "קבוצה:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "גודל:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "רענן" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'מילת מפתח: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" אינה מחזירה תוצאות' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "העתק אמוג'י" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "שם יוניקוד" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "חיפוש מילת מפתח" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "גרסה" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "קוד" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "בקבוצה" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "הצג בפלטפורמה אחרת" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " עבור פלטפורמת " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "לחיצה ימנית כדי להעתיק או להוריד את התמונה" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "הועתק" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "עבור מקצועני: מנוע חיפוש ציורי וקטור, כולל מעל 200,000 סמלים." } }
};
const resource$4 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Emoji-haku, 🖱️Napsauta kopioidaksesi - Emoji-hakukone, joka tukee 30 kieltä" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Anna Emojien elävöittää sisältöäsi. EtsiEmojista löytyy laajin valikoima emojikuvakkeita ympäri maailman. Löydä juuri se emoji, jonka tarvitset tehokkailla hakutoiminnoilla – etsi avainsanalla tai selaa kategorioiden avulla. Esikatsele mitä tahansa emojia ja kopioi se yhdellä napsautuksella asiakirjoihisi, viesteihisi ja some-julkaisuihisi." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji-yksityiskohdat" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") lisättiin Emojien perheeseen versiossa " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", se sisältyy [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] luokkaan, jossa on Unicode-koodaus " }, { "t": 4, "k": "code" }, { "t": 3, "v": " ja virallisesti nimetään " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "EtsiEmojit" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji-haku, Napsauta kopioidaksesi" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Anna hakusana" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Vaihda pimeään tilaan" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Vaihda vaaleaan tilaan" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Takaisin ylös" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Napsauta kopioidaksesi" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Napsauta kopioidaksesi: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Siirry yksityiskohtiin" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopioi emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Laadukas" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "täysin laadukas" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "vähimmäistasoinen" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "laiha" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "komponentti" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ihonväri:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "vaalea" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "keski-vaalea" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "keskisuuri" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "keski-tumma" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "tumma" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojit" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ryhmä:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Koko:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Päivitä" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Hakusana: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" ei tuottanut tuloksia' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopioi emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicodenimi" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Hae avainsanalla" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versio" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Koodi" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ryhmässä" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Näytä muilla alustoilla" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " alustalla " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Napsauta hiiren oikealla painikkeella kopioidaksesi tai ladataksesi kuva" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopioitu" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Ammattilaisille: Monikielinen vektorikuvakkeiden hakukone, sisältää yli 200 000 kuvaketta." } }
};
const resource$3 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Søk etter Emoji, 🖱️Klikk for å kopiere - Emoji-søkemotor som støtter 30 språk" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "La emojier bringe innholdet ditt til live. SearchEmoji har den største samlingen av emojier fra hele verden. Finn akkurat den emojien du trenger gjennom kraftige søkefunksjoner - enten ved søk etter nøkkelord eller gjennom kategorier. Forhåndsvis hvilken som helst emoji og kopier den med ett klikk inn i dokumentene dine, meldingene og innleggene dine på sosiale medier." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji-detalj" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") ble lagt til Emoji-familien i versjon " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", inkludert i [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "] kategorien, med en Unicode-koding på " }, { "t": 4, "k": "code" }, { "t": 3, "v": " og offisielt navngitt som " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Søk etter Emoji, Klikk for å kopiere" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Skriv inn et søkeord" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Bytt til mørk modus" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Bytt til lys modus" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tilbake til toppen" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klikk for å" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klikk for å kopiere:" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gå til detaljer" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopier Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kvalifisert" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "fullt kvalifisert" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimalt kvalifisert" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ukvalifisert" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "komponent" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Hudtone:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "lys" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "middels lys" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "middels" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "middels mørk" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mørk" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojier" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gruppe:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Størrelse:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Oppdater" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Søkeordet "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" returnerer ingen resultater' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopier Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode-navn" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Søk nøkkelord" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versjon" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kode" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gruppe" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Vises på annen plattform" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " for " }, { "t": 4, "k": "platform" }, { "t": 3, "v": "-plattformen" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Høyreklikk for å kopiere eller laste ned bildet" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copied" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "For professional: Multilingual Vector Icon Search Engine, includes more than 200k icons." } },
  "zh": {
    "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "已复制" } },
    "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "给专业人士：多语言矢量图标搜索引擎，收录超过 20 万图标！" } }
  }
};
const resource$2 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Søg efter emoji, 🖱️Klik for at kopiere - Emoji-søgemaskine der understøtter 30 sprog" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Lad emoji'er bringe dit indhold til live. SearchEmoji har den største samling af emoji'er fra hele verden. Find præcis den emoji, du har brug for, gennem kraftfulde søgefunktioner - enten søg efter nøgleord eller gennemse kategorier. Forhåndsvis enhver emoji og kopier den med et enkelt klik ind i dine dokumenter, beskeder og sociale indlæg." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji-detaljer" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") blev tilføjet til Emoji-familien i version " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", inkluderet i kategorien [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], med en Unicode-kodning af " }, { "t": 4, "k": "code" }, { "t": 3, "v": " og officielt navngivet som " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Søg efter emoji, klik for at kopiere" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Indtast et søgeord" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Skift til mørk tilstand" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Skift til lystilstand" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Tilbage til toppen" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik på" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Klik for at kopiere: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gå til detaljer" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopier emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kvalificeret" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "fuldt kvalificeret" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimalt kvalificeret" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "ukvalificeret" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "komponent" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Hudfarve:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "lys" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "middel-lys" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "middel" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "middel-mørk" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mørk" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji'er" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gruppe:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Størrelse:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Opdater" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Nøgleord: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" giver ingen resultater' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopier emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode-navn" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Søgeord" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Version" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kode" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Gruppe" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Vis på anden platform" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " til " }, { "t": 4, "k": "platform" }, { "t": 3, "v": " platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Højreklik for at kopiere eller downloade billedet" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kopieret" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Til professionelle: Multisproget Vektor Ikon Søgemaskine, inkluderer mere end 200k ikoner." } }
};
const resource$1 = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Caută Emoji, 🖱️Clic pentru a Copia - Motor de căutare Emoji care acceptă 30 de limbi" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Permiteți emoțiilor să dea viață conținutului dvs. SearchEmoji găzduiește cea mai mare colecție de emoji-uri din întreaga lume. Găsiți exact emoji-ul de care aveți nevoie printr-o funcție de căutare puternică - fie căutați după cuvinte cheie sau navigați prin categorii. Previzualizați orice emoji și copiați-l cu un singur clic în documentele, mesajele și postările dvs. sociale." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Detaliu emoji" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") a fost adăugat la familia de emoji-uri în versiunea " }, { "t": 4, "k": "version" }, { "t": 3, "v": ", inclus în categoria [" }, { "t": 4, "k": "group" }, { "t": 3, "v": "], cu o codare Unicode de " }, { "t": 4, "k": "code" }, { "t": 3, "v": " și numit oficial " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Caută Emoji, Clic pentru a Copia" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Introduceți un cuvânt cheie" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Comutare la modul întunecat" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Comutare la modul luminos" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Înapoi sus" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Clic pentru a" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Clic pentru a copia: " } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Mergi la detaliu" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiază Emoji" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Calificat" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "complet calificat" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minim calificat" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "necalificat" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "componentă" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nuanță de piele:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "luminos" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mediu-luminos" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mediu" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "mediu-închis" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "închis" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "emoji-uri" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Grup:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Mărime:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Reîmprospătează" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": "Cuvânt-cheie: „" }, { "t": 4, "k": "keyword" }, { "t": 3, "v": "” nu a returnat rezultate" }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiază Emoji" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Nume Unicode" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Căutare cuvânt-cheie" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Versiune" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Cod" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "În grup" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Afișare pe alte platforme" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": " pentru platforma " }, { "t": 4, "k": "platform" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Faceți clic dreapta pentru a copia sau descărca imaginea" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Copiat" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Pentru profesioniști: Motor de căutare de icoane vectoriale multilingv, include peste 200k de icoane." } }
};
const resource = {
  "seo": {
    "title": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "🔍Emoji Keresés, 🖱️Kattints a Másoláshoz - 30 Nyelvet Támogató Emoji Keresőmotor" } },
    "description": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Engedd, hogy az emojik életre keltsék a tartalmadat. A SearchEmoji a világ legnagyobb emoji gyűjteményét kínálja. Pontosan azt az emojit találd meg, amire szükséged van a hatékony keresési funkciók segítségével - kereshetsz kulcsszó alapján, vagy böngészheted a kategóriákat. Bármelyik emojit előnézheted, majd egy kattintással másolhatod a dokumentumaidba, üzeneteidbe és közösségi bejegyzéseidbe." } },
    "detailTitle": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "emoji" }, { "t": 3, "v": " " }, { "t": 4, "k": "name" }, { "t": 3, "v": " - Emoji részletek" }] } },
    "detailDescription": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "name" }, { "t": 3, "v": "(" }, { "t": 4, "k": "emoji" }, { "t": 3, "v": ") hozzáadásra került az Emoji családba a(z) " }, { "t": 4, "k": "version" }, { "t": 3, "v": " verzióban, beleértve a(z) [" }, { "t": 4, "k": "group" }, { "t": 3, "v": " ] kategóriát, Unicode kódolással " }, { "t": 4, "k": "code" }, { "t": 3, "v": ", hivatalos nevén " }, { "t": 4, "k": "oName" }] } },
    "siteName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "SearchEmoji" } }
  },
  "logoTips": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji Keresés, Kattints a Másoláshoz" } },
  "placeholder": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Írj be egy kulcsszót" } },
  "darkTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Váltás sötét módba" } },
  "lightTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Váltás világos módba" } },
  "backTop": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Vissza a tetejére" } },
  "clickTo": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kattints a(z)" } },
  "clickToCopy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kattints a Másoláshoz:" } },
  "detail": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Részletek megtekintése" } },
  "copy": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji Másolása" } },
  "qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Minősített" } },
  "fully-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "teljesen minősített" } },
  "minimally-qualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "minimálisan minősített" } },
  "unqualified": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "nem minősített" } },
  "component": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "komponens" } },
  "skinTone": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Bőrtónus:" } },
  "light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "világos" } },
  "medium-light": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "közepesen világos" } },
  "medium": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "közepes" } },
  "medium-dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "közepesen sötét" } },
  "dark": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "sötét" } },
  "emojis": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emojik" } },
  "group": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Csoport:" } },
  "size": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Méret:" } },
  "refresh": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Frissítés" } },
  "noResults": { "t": 0, "b": { "t": 2, "i": [{ "t": 3, "v": 'Kulcsszó: "' }, { "t": 4, "k": "keyword" }, { "t": 3, "v": '" nincs találat' }] } },
  "copyBtn": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Emoji Másolása" } },
  "unicodeName": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Unicode név" } },
  "searchKeyword": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kulcsszó keresése" } },
  "version": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Verzió" } },
  "code": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kód" } },
  "inGroup": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Csoportban" } },
  "otherPlatform": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Megjelenítés más platformon" } },
  "platformImg": { "t": 0, "b": { "t": 2, "i": [{ "t": 4, "k": "platform" }, { "t": 3, "v": " platformon a(z) " }, { "t": 4, "k": "name" }, { "t": 3, "v": " képe" }] } },
  "imgCopyTip": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Kattints jobb gombbal a kép másolásához vagy letöltéséhez" } },
  "copied": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Másolva" } },
  "yesicon": { "t": 0, "b": { "t": 2, "i": [{ "t": 3 }], "s": "Professzionális felhasználóknak: többnyelvű vektor ikon keresőmotor, tartalmaz több mint 200 ezer ikont." } }
};
const localeCodes = [
  "en",
  "zh-hans",
  "es",
  "zh-hant",
  "de",
  "ja",
  "fr",
  "ko",
  "pt",
  "ru",
  "tr",
  "ar",
  "it",
  "hi",
  "pl",
  "bn",
  "nl",
  "uk",
  "id",
  "ms",
  "vi",
  "th",
  "sv",
  "el",
  "he",
  "fi",
  "no",
  "da",
  "ro",
  "hu"
];
const localeMessages = {
  "en": [{ key: "../lang/en.json", load: () => Promise.resolve(resource$t), cache: true }],
  "zh-hans": [{ key: "../lang/zh-hans.json", load: () => Promise.resolve(resource$s), cache: true }],
  "es": [{ key: "../lang/es.json", load: () => Promise.resolve(resource$r), cache: true }],
  "zh-hant": [{ key: "../lang/zh-hant.json", load: () => Promise.resolve(resource$q), cache: true }],
  "de": [{ key: "../lang/de.json", load: () => Promise.resolve(resource$p), cache: true }],
  "ja": [{ key: "../lang/ja.json", load: () => Promise.resolve(resource$o), cache: true }],
  "fr": [{ key: "../lang/fr.json", load: () => Promise.resolve(resource$n), cache: true }],
  "ko": [{ key: "../lang/ko.json", load: () => Promise.resolve(resource$m), cache: true }],
  "pt": [{ key: "../lang/pt.json", load: () => Promise.resolve(resource$l), cache: true }],
  "ru": [{ key: "../lang/ru.json", load: () => Promise.resolve(resource$k), cache: true }],
  "tr": [{ key: "../lang/tr.json", load: () => Promise.resolve(resource$j), cache: true }],
  "ar": [{ key: "../lang/ar.json", load: () => Promise.resolve(resource$i), cache: true }],
  "it": [{ key: "../lang/it.json", load: () => Promise.resolve(resource$h), cache: true }],
  "hi": [{ key: "../lang/hi.json", load: () => Promise.resolve(resource$g), cache: true }],
  "pl": [{ key: "../lang/pl.json", load: () => Promise.resolve(resource$f), cache: true }],
  "bn": [{ key: "../lang/bn.json", load: () => Promise.resolve(resource$e), cache: true }],
  "nl": [{ key: "../lang/nl.json", load: () => Promise.resolve(resource$d), cache: true }],
  "uk": [{ key: "../lang/uk.json", load: () => Promise.resolve(resource$c), cache: true }],
  "id": [{ key: "../lang/id.json", load: () => Promise.resolve(resource$b), cache: true }],
  "ms": [{ key: "../lang/ms.json", load: () => Promise.resolve(resource$a), cache: true }],
  "vi": [{ key: "../lang/vi.json", load: () => Promise.resolve(resource$9), cache: true }],
  "th": [{ key: "../lang/th.json", load: () => Promise.resolve(resource$8), cache: true }],
  "sv": [{ key: "../lang/sv.json", load: () => Promise.resolve(resource$7), cache: true }],
  "el": [{ key: "../lang/el.json", load: () => Promise.resolve(resource$6), cache: true }],
  "he": [{ key: "../lang/he.json", load: () => Promise.resolve(resource$5), cache: true }],
  "fi": [{ key: "../lang/fi.json", load: () => Promise.resolve(resource$4), cache: true }],
  "no": [{ key: "../lang/no.json", load: () => Promise.resolve(resource$3), cache: true }],
  "da": [{ key: "../lang/da.json", load: () => Promise.resolve(resource$2), cache: true }],
  "ro": [{ key: "../lang/ro.json", load: () => Promise.resolve(resource$1), cache: true }],
  "hu": [{ key: "../lang/hu.json", load: () => Promise.resolve(resource), cache: true }]
};
const vueI18nConfigs = [
  () => import(
    './_nuxt/i18n.config-XEhn4iF_.mjs'
    /* webpackChunkName: "i18n_config_bffaebcb" */
  )
];
const nuxtI18nOptions = {
  "experimental": {
    "localeDetector": ""
  },
  "bundle": {
    "compositionOnly": true,
    "runtimeOnly": false,
    "fullInstall": true,
    "dropMessageCompiler": false
  },
  "compilation": {
    "jit": true,
    "strictMessage": true,
    "escapeHtml": false
  },
  "customBlocks": {
    "defaultSFCLang": "json",
    "globalSFCScope": false
  },
  "vueI18n": "",
  "locales": [
    {
      "code": "en",
      "iso": "en",
      "name": "English",
      "files": [
        "lang/en.json"
      ]
    },
    {
      "code": "zh-hans",
      "iso": "zh",
      "name": "简体中文",
      "files": [
        "lang/zh-hans.json"
      ]
    },
    {
      "code": "es",
      "iso": "es",
      "name": "Español",
      "files": [
        "lang/es.json"
      ]
    },
    {
      "code": "zh-hant",
      "iso": "zh-TW",
      "name": "正體中文",
      "files": [
        "lang/zh-hant.json"
      ]
    },
    {
      "code": "de",
      "iso": "de",
      "name": "Deutsch",
      "files": [
        "lang/de.json"
      ]
    },
    {
      "code": "ja",
      "iso": "ja",
      "name": "日本語",
      "files": [
        "lang/ja.json"
      ]
    },
    {
      "code": "fr",
      "iso": "fr",
      "name": "Français",
      "files": [
        "lang/fr.json"
      ]
    },
    {
      "code": "ko",
      "iso": "ko",
      "name": "한국어",
      "files": [
        "lang/ko.json"
      ]
    },
    {
      "code": "pt",
      "iso": "pt",
      "name": "Português",
      "files": [
        "lang/pt.json"
      ]
    },
    {
      "code": "ru",
      "iso": "pt",
      "name": "Русский",
      "files": [
        "lang/ru.json"
      ]
    },
    {
      "code": "tr",
      "iso": "tr",
      "name": "Türkçe",
      "files": [
        "lang/tr.json"
      ]
    },
    {
      "code": "ar",
      "iso": "ar",
      "name": "العربية",
      "dir": "ltr",
      "files": [
        "lang/ar.json"
      ]
    },
    {
      "code": "it",
      "iso": "it",
      "name": "Italiano",
      "files": [
        "lang/it.json"
      ]
    },
    {
      "code": "hi",
      "iso": "hi",
      "name": "हिन्दी",
      "files": [
        "lang/hi.json"
      ]
    },
    {
      "code": "pl",
      "iso": "pl",
      "name": "Polski",
      "files": [
        "lang/pl.json"
      ]
    },
    {
      "code": "bn",
      "iso": "bn",
      "name": "বাংলা",
      "files": [
        "lang/bn.json"
      ]
    },
    {
      "code": "nl",
      "iso": "nl",
      "name": "Nederlands",
      "files": [
        "lang/nl.json"
      ]
    },
    {
      "code": "uk",
      "iso": "uk",
      "name": "Українська",
      "files": [
        "lang/uk.json"
      ]
    },
    {
      "code": "id",
      "iso": "id",
      "name": "Bahasa Indonesia",
      "files": [
        "lang/id.json"
      ]
    },
    {
      "code": "ms",
      "iso": "ms",
      "name": "Bahasa Malaysia",
      "files": [
        "lang/ms.json"
      ]
    },
    {
      "code": "vi",
      "iso": "vi",
      "name": "Tiếng Việt",
      "files": [
        "lang/vi.json"
      ]
    },
    {
      "code": "th",
      "iso": "th",
      "name": "ไทย",
      "files": [
        "lang/th.json"
      ]
    },
    {
      "code": "sv",
      "iso": "sv",
      "name": "Svenska",
      "files": [
        "lang/sv.json"
      ]
    },
    {
      "code": "el",
      "iso": "el",
      "name": "Ελληνικά",
      "files": [
        "lang/el.json"
      ]
    },
    {
      "code": "he",
      "iso": "he",
      "name": "עברית‎",
      "dir": "ltr",
      "files": [
        "lang/he.json"
      ]
    },
    {
      "code": "fi",
      "iso": "fi",
      "name": "Suomi",
      "files": [
        "lang/fi.json"
      ]
    },
    {
      "code": "no",
      "iso": "no",
      "name": "Norsk",
      "files": [
        "lang/no.json"
      ]
    },
    {
      "code": "da",
      "iso": "da",
      "name": "Dansk",
      "files": [
        "lang/da.json"
      ]
    },
    {
      "code": "ro",
      "iso": "ro",
      "name": "Română",
      "files": [
        "lang/ro.json"
      ]
    },
    {
      "code": "hu",
      "iso": "hu",
      "name": "Magyar",
      "files": [
        "lang/hu.json"
      ]
    }
  ],
  "defaultLocale": "en",
  "defaultDirection": "ltr",
  "routesNameSeparator": "___",
  "trailingSlash": false,
  "defaultLocaleRouteNameSuffix": "default",
  "strategy": "prefix_except_default",
  "lazy": false,
  "langDir": "./lang",
  "rootRedirect": null,
  "detectBrowserLanguage": {
    "alwaysRedirect": false,
    "cookieCrossOrigin": true,
    "cookieDomain": null,
    "cookieKey": "lang",
    "cookieSecure": false,
    "fallbackLocale": "",
    "redirectOn": "root",
    "useCookie": true
  },
  "differentDomains": false,
  "baseUrl": "https://searchemoji.app",
  "dynamicRouteParams": false,
  "customRoutes": "page",
  "pages": {},
  "skipSettingLocaleOnNavigate": false,
  "types": "composition",
  "debug": false,
  "parallelPlugin": false,
  "i18nModules": []
};
const nuxtI18nOptionsDefault = {
  "experimental": {
    "localeDetector": ""
  },
  "bundle": {
    "compositionOnly": true,
    "runtimeOnly": false,
    "fullInstall": true,
    "dropMessageCompiler": false
  },
  "compilation": {
    "jit": true,
    "strictMessage": true,
    "escapeHtml": false
  },
  "customBlocks": {
    "defaultSFCLang": "json",
    "globalSFCScope": false
  },
  "vueI18n": "",
  "locales": [],
  "defaultLocale": "",
  "defaultDirection": "ltr",
  "routesNameSeparator": "___",
  "trailingSlash": false,
  "defaultLocaleRouteNameSuffix": "default",
  "strategy": "prefix_except_default",
  "lazy": false,
  "langDir": null,
  "rootRedirect": null,
  "detectBrowserLanguage": {
    "alwaysRedirect": false,
    "cookieCrossOrigin": false,
    "cookieDomain": null,
    "cookieKey": "i18n_redirected",
    "cookieSecure": false,
    "fallbackLocale": "",
    "redirectOn": "root",
    "useCookie": true
  },
  "differentDomains": false,
  "baseUrl": "",
  "dynamicRouteParams": false,
  "customRoutes": "page",
  "pages": {},
  "skipSettingLocaleOnNavigate": false,
  "types": "composition",
  "debug": false,
  "parallelPlugin": false
};
const nuxtI18nInternalOptions = {
  "__normalizedLocales": [
    {
      "code": "en",
      "iso": "en",
      "name": "English",
      "files": [
        {
          "path": "lang/en.json"
        }
      ]
    },
    {
      "code": "zh-hans",
      "iso": "zh",
      "name": "简体中文",
      "files": [
        {
          "path": "lang/zh-hans.json"
        }
      ]
    },
    {
      "code": "es",
      "iso": "es",
      "name": "Español",
      "files": [
        {
          "path": "lang/es.json"
        }
      ]
    },
    {
      "code": "zh-hant",
      "iso": "zh-TW",
      "name": "正體中文",
      "files": [
        {
          "path": "lang/zh-hant.json"
        }
      ]
    },
    {
      "code": "de",
      "iso": "de",
      "name": "Deutsch",
      "files": [
        {
          "path": "lang/de.json"
        }
      ]
    },
    {
      "code": "ja",
      "iso": "ja",
      "name": "日本語",
      "files": [
        {
          "path": "lang/ja.json"
        }
      ]
    },
    {
      "code": "fr",
      "iso": "fr",
      "name": "Français",
      "files": [
        {
          "path": "lang/fr.json"
        }
      ]
    },
    {
      "code": "ko",
      "iso": "ko",
      "name": "한국어",
      "files": [
        {
          "path": "lang/ko.json"
        }
      ]
    },
    {
      "code": "pt",
      "iso": "pt",
      "name": "Português",
      "files": [
        {
          "path": "lang/pt.json"
        }
      ]
    },
    {
      "code": "ru",
      "iso": "pt",
      "name": "Русский",
      "files": [
        {
          "path": "lang/ru.json"
        }
      ]
    },
    {
      "code": "tr",
      "iso": "tr",
      "name": "Türkçe",
      "files": [
        {
          "path": "lang/tr.json"
        }
      ]
    },
    {
      "code": "ar",
      "iso": "ar",
      "name": "العربية",
      "dir": "ltr",
      "files": [
        {
          "path": "lang/ar.json"
        }
      ]
    },
    {
      "code": "it",
      "iso": "it",
      "name": "Italiano",
      "files": [
        {
          "path": "lang/it.json"
        }
      ]
    },
    {
      "code": "hi",
      "iso": "hi",
      "name": "हिन्दी",
      "files": [
        {
          "path": "lang/hi.json"
        }
      ]
    },
    {
      "code": "pl",
      "iso": "pl",
      "name": "Polski",
      "files": [
        {
          "path": "lang/pl.json"
        }
      ]
    },
    {
      "code": "bn",
      "iso": "bn",
      "name": "বাংলা",
      "files": [
        {
          "path": "lang/bn.json"
        }
      ]
    },
    {
      "code": "nl",
      "iso": "nl",
      "name": "Nederlands",
      "files": [
        {
          "path": "lang/nl.json"
        }
      ]
    },
    {
      "code": "uk",
      "iso": "uk",
      "name": "Українська",
      "files": [
        {
          "path": "lang/uk.json"
        }
      ]
    },
    {
      "code": "id",
      "iso": "id",
      "name": "Bahasa Indonesia",
      "files": [
        {
          "path": "lang/id.json"
        }
      ]
    },
    {
      "code": "ms",
      "iso": "ms",
      "name": "Bahasa Malaysia",
      "files": [
        {
          "path": "lang/ms.json"
        }
      ]
    },
    {
      "code": "vi",
      "iso": "vi",
      "name": "Tiếng Việt",
      "files": [
        {
          "path": "lang/vi.json"
        }
      ]
    },
    {
      "code": "th",
      "iso": "th",
      "name": "ไทย",
      "files": [
        {
          "path": "lang/th.json"
        }
      ]
    },
    {
      "code": "sv",
      "iso": "sv",
      "name": "Svenska",
      "files": [
        {
          "path": "lang/sv.json"
        }
      ]
    },
    {
      "code": "el",
      "iso": "el",
      "name": "Ελληνικά",
      "files": [
        {
          "path": "lang/el.json"
        }
      ]
    },
    {
      "code": "he",
      "iso": "he",
      "name": "עברית‎",
      "dir": "ltr",
      "files": [
        {
          "path": "lang/he.json"
        }
      ]
    },
    {
      "code": "fi",
      "iso": "fi",
      "name": "Suomi",
      "files": [
        {
          "path": "lang/fi.json"
        }
      ]
    },
    {
      "code": "no",
      "iso": "no",
      "name": "Norsk",
      "files": [
        {
          "path": "lang/no.json"
        }
      ]
    },
    {
      "code": "da",
      "iso": "da",
      "name": "Dansk",
      "files": [
        {
          "path": "lang/da.json"
        }
      ]
    },
    {
      "code": "ro",
      "iso": "ro",
      "name": "Română",
      "files": [
        {
          "path": "lang/ro.json"
        }
      ]
    },
    {
      "code": "hu",
      "iso": "hu",
      "name": "Magyar",
      "files": [
        {
          "path": "lang/hu.json"
        }
      ]
    }
  ]
};
const NUXT_I18N_MODULE_ID = "@nuxtjs/i18n";
const parallelPlugin = false;
const isSSG = false;
async function loadVueI18nOptions(vueI18nConfigs2, nuxt) {
  const vueI18nOptions = { messages: {} };
  for (const configFile of vueI18nConfigs2) {
    const { default: resolver2 } = await configFile();
    const resolved = typeof resolver2 === "function" ? await nuxt.runWithContext(async () => await resolver2()) : resolver2;
    deepCopy(resolved, vueI18nOptions);
  }
  return vueI18nOptions;
}
function makeFallbackLocaleCodes(fallback, locales) {
  let fallbackLocales = [];
  if (isArray$1(fallback)) {
    fallbackLocales = fallback;
  } else if (isObject$1(fallback)) {
    const targets = [...locales, "default"];
    for (const locale of targets) {
      if (fallback[locale]) {
        fallbackLocales = [...fallbackLocales, ...fallback[locale].filter(Boolean)];
      }
    }
  } else if (isString$1(fallback) && locales.every((locale) => locale !== fallback)) {
    fallbackLocales.push(fallback);
  }
  return fallbackLocales;
}
async function loadInitialMessages(messages, localeLoaderMessages, options2) {
  const { defaultLocale, initialLocale, localeCodes: localeCodes2, fallbackLocale, lazy, cacheMessages: cacheMessages2 } = options2;
  const setter = (locale, message) => {
    const base = messages[locale] || {};
    deepCopy(message, base);
    messages[locale] = base;
  };
  if (lazy && fallbackLocale) {
    const fallbackLocales = makeFallbackLocaleCodes(fallbackLocale, [defaultLocale, initialLocale]);
    await Promise.all(
      fallbackLocales.map((locale) => loadLocale({ locale, setter, localeMessages: localeLoaderMessages }, cacheMessages2))
    );
  }
  const locales = lazy ? [...(/* @__PURE__ */ new Set()).add(defaultLocale).add(initialLocale)] : localeCodes2;
  await Promise.all(
    locales.map((locale) => loadLocale({ locale, setter, localeMessages: localeLoaderMessages }, cacheMessages2))
  );
  return messages;
}
async function loadMessage(locale, { key, load }, cacheMessages2) {
  let message = null;
  try {
    const getter = await load().then((r) => r.default || r);
    if (isFunction$1(getter)) {
      message = await getter(locale);
    } else {
      message = getter;
      if (message != null && cacheMessages2) {
        cacheMessages2.set(key, message);
      }
    }
  } catch (e) {
    console.error("Failed locale loading: " + e.message);
  }
  return message;
}
async function loadLocale({
  locale,
  localeMessages: localeMessages2,
  setter
}, cacheMessages2) {
  const loaders = localeMessages2[locale];
  if (loaders == null) {
    console.warn("Could not find messages for locale code: " + locale);
    return;
  }
  const targetMessage = {};
  for (const loader of loaders) {
    let message = null;
    if (cacheMessages2 && cacheMessages2.has(loader.key) && loader.cache) {
      message = cacheMessages2.get(loader.key);
    } else {
      message = await loadMessage(locale, loader, cacheMessages2);
    }
    if (message != null) {
      deepCopy(message, targetMessage);
    }
  }
  setter(locale, targetMessage);
}
const CookieDefaults = {
  path: "/",
  watch: true,
  decode: (val) => destr(decodeURIComponent(val)),
  encode: (val) => encodeURIComponent(typeof val === "string" ? val : JSON.stringify(val))
};
function useCookie(name, _opts) {
  var _a;
  const opts = { ...CookieDefaults, ..._opts };
  const cookies = readRawCookies(opts) || {};
  let delay;
  if (opts.maxAge !== void 0) {
    delay = opts.maxAge * 1e3;
  } else if (opts.expires) {
    delay = opts.expires.getTime() - Date.now();
  }
  const hasExpired = delay !== void 0 && delay <= 0;
  const cookieValue = klona(hasExpired ? void 0 : cookies[name] ?? ((_a = opts.default) == null ? void 0 : _a.call(opts)));
  const cookie = ref(cookieValue);
  {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const writeFinalCookieValue = () => {
      if (opts.readonly || isEqual$1(cookie.value, cookies[name])) {
        return;
      }
      writeServerCookie(useRequestEvent(nuxtApp), name, cookie.value, opts);
    };
    const unhook = nuxtApp.hooks.hookOnce("app:rendered", writeFinalCookieValue);
    nuxtApp.hooks.hookOnce("app:error", () => {
      unhook();
      return writeFinalCookieValue();
    });
  }
  return cookie;
}
function readRawCookies(opts = {}) {
  {
    return parse$1(getRequestHeader(useRequestEvent(), "cookie") || "", opts);
  }
}
function writeServerCookie(event, name, value, opts = {}) {
  if (event) {
    if (value !== null && value !== void 0) {
      return setCookie(event, name, value, opts);
    }
    if (getCookie(event, name) !== void 0) {
      return deleteCookie(event, name, opts);
    }
  }
}
function isHTTPS(req, trustProxy = true) {
  const _xForwardedProto = trustProxy && req.headers ? req.headers["x-forwarded-proto"] : void 0;
  const protoCheck = typeof _xForwardedProto === "string" ? _xForwardedProto.includes("https") : void 0;
  if (protoCheck) {
    return true;
  }
  const _encrypted = req.connection ? req.connection.encrypted : void 0;
  const encryptedCheck = _encrypted !== void 0 ? _encrypted === true : void 0;
  if (encryptedCheck) {
    return true;
  }
  if (protoCheck === void 0 && encryptedCheck === void 0) {
    return void 0;
  }
  return false;
}
function formatMessage(message) {
  return NUXT_I18N_MODULE_ID + " " + message;
}
function isLegacyVueI18n(target) {
  return target != null && ("__VUE_I18N_BRIDGE__" in target || "_sync" in target);
}
function callVueI18nInterfaces(i18n, name, ...args) {
  const target = isI18nInstance(i18n) ? i18n.global : i18n;
  const [obj, method] = [target, target[name]];
  return Reflect.apply(method, obj, [...args]);
}
function getVueI18nPropertyValue(i18n, name) {
  const target = isI18nInstance(i18n) ? i18n.global : i18n;
  const ret = isComposer(target) ? target[name].value : isExportedGlobalComposer(target) || isVueI18n(target) || isLegacyVueI18n(target) ? target[name] : target[name];
  return ret;
}
function defineGetter(obj, key, val) {
  Object.defineProperty(obj, key, { get: () => val });
}
function proxyNuxt(nuxt, target) {
  return function() {
    return Reflect.apply(
      target,
      {
        i18n: nuxt.$i18n,
        getRouteBaseName: nuxt.$getRouteBaseName,
        localePath: nuxt.$localePath,
        localeRoute: nuxt.$localeRoute,
        switchLocalePath: nuxt.$switchLocalePath,
        localeHead: nuxt.$localeHead,
        route: nuxt.$router.currentRoute.value,
        router: nuxt.$router
      },
      // eslint-disable-next-line prefer-rest-params
      arguments
    );
  };
}
function parseAcceptLanguage(input) {
  return input.split(",").map((tag) => tag.split(";")[0]);
}
function getBrowserLocale(options2) {
  let ret;
  {
    const header = useRequestHeaders(["accept-language"]);
    const accept = header["accept-language"];
    if (accept) {
      ret = findBrowserLocale(options2.__normalizedLocales, parseAcceptLanguage(accept));
    }
  }
  return ret;
}
function getLocaleCookie({
  useCookie: useCookie$1 = nuxtI18nOptionsDefault.detectBrowserLanguage.useCookie,
  cookieKey = nuxtI18nOptionsDefault.detectBrowserLanguage.cookieKey,
  localeCodes: localeCodes2 = []
} = {}) {
  if (!useCookie$1) {
    return;
  }
  const localeCookie = useCookie(cookieKey);
  const localeCode = localeCookie.value ?? void 0;
  if (localeCode && localeCodes2.includes(localeCode)) {
    return localeCode;
  }
}
function setLocaleCookie(locale, {
  useCookie: useCookie$1 = nuxtI18nOptionsDefault.detectBrowserLanguage.useCookie,
  cookieKey = nuxtI18nOptionsDefault.detectBrowserLanguage.cookieKey,
  cookieDomain = nuxtI18nOptionsDefault.detectBrowserLanguage.cookieDomain,
  cookieSecure = nuxtI18nOptionsDefault.detectBrowserLanguage.cookieSecure,
  cookieCrossOrigin = nuxtI18nOptionsDefault.detectBrowserLanguage.cookieCrossOrigin
} = {}) {
  if (!useCookie$1) {
    return;
  }
  const date = /* @__PURE__ */ new Date();
  const cookieOptions = {
    expires: new Date(date.setDate(date.getDate() + 365)),
    path: "/",
    sameSite: cookieCrossOrigin ? "none" : "lax",
    secure: cookieCrossOrigin || cookieSecure
  };
  if (cookieDomain) {
    cookieOptions.domain = cookieDomain;
  }
  const localeCookie = useCookie(cookieKey, cookieOptions);
  localeCookie.value = locale;
}
const DefaultDetectBrowserLanguageFromResult = {
  locale: "",
  stat: false,
  reason: "unknown",
  from: "unknown"
};
function detectBrowserLanguage(route, nuxtI18nOptions2, nuxtI18nInternalOptions2, vueI18nOptions, detectLocaleContext, localeCodes2 = [], locale = "") {
  const { strategy } = nuxtI18nOptions2;
  const { ssg, callType, firstAccess } = detectLocaleContext;
  if (!firstAccess) {
    return { locale: strategy === "no_prefix" ? locale : "", stat: false, reason: "first_access_only" };
  }
  const { redirectOn, alwaysRedirect, useCookie: useCookie2, fallbackLocale } = nuxtI18nOptions2.detectBrowserLanguage;
  const path = isString$1(route) ? route : route.path;
  if (strategy !== "no_prefix") {
    if (redirectOn === "root") {
      if (path !== "/") {
        return { locale: "", stat: false, reason: "not_redirect_on_root" };
      }
    } else if (redirectOn === "no prefix") {
      if (!alwaysRedirect && path.match(getLocalesRegex(localeCodes2))) {
        return { locale: "", stat: false, reason: "not_redirect_on_no_prefix" };
      }
    }
  }
  let localeFrom = "unknown";
  let cookieLocale;
  let matchedLocale;
  if (useCookie2) {
    matchedLocale = cookieLocale = getLocaleCookie({ ...nuxtI18nOptions2.detectBrowserLanguage, localeCodes: localeCodes2 });
    localeFrom = "cookie";
  }
  if (!matchedLocale) {
    matchedLocale = getBrowserLocale(nuxtI18nInternalOptions2);
    localeFrom = "navigator_or_header";
  }
  const finalLocale = matchedLocale || fallbackLocale;
  if (!matchedLocale && fallbackLocale) {
    localeFrom = "fallback";
  }
  const vueI18nLocale = locale || vueI18nOptions.locale;
  if (finalLocale && (!useCookie2 || alwaysRedirect || !cookieLocale)) {
    if (strategy === "no_prefix") {
      return { locale: finalLocale, stat: true, from: localeFrom };
    } else {
      if (callType === "setup") {
        if (finalLocale !== vueI18nLocale) {
          return { locale: finalLocale, stat: true, from: localeFrom };
        }
      }
      if (alwaysRedirect) {
        const redirectOnRoot = path === "/";
        const redirectOnAll = redirectOn === "all";
        const redirectOnNoPrefix = redirectOn === "no prefix" && !path.match(getLocalesRegex(localeCodes2));
        if (redirectOnRoot || redirectOnAll || redirectOnNoPrefix) {
          return { locale: finalLocale, stat: true, from: localeFrom };
        }
      }
    }
  }
  if (ssg === "ssg_setup" && finalLocale) {
    return { locale: finalLocale, stat: true, from: localeFrom };
  }
  if ((localeFrom === "navigator_or_header" || localeFrom === "cookie") && finalLocale) {
    return { locale: finalLocale, stat: true, from: localeFrom };
  }
  return { locale: "", stat: false, reason: "not_found_match" };
}
function getHost() {
  let host;
  {
    const header = useRequestHeaders(["x-forwarded-host", "host"]);
    let detectedHost;
    if ("x-forwarded-host" in header) {
      detectedHost = header["x-forwarded-host"];
    } else if ("host" in header) {
      detectedHost = header["host"];
    }
    host = isArray$1(detectedHost) ? detectedHost[0] : detectedHost;
  }
  return host;
}
function getLocaleDomain(locales) {
  let host = getHost() || "";
  if (host) {
    const matchingLocale = locales.find((locale) => {
      if (locale && locale.domain) {
        let domain = locale.domain;
        if (hasProtocol(locale.domain)) {
          domain = locale.domain.replace(/(http|https):\/\//, "");
        }
        return domain === host;
      }
      return false;
    });
    if (matchingLocale) {
      return matchingLocale.code;
    } else {
      host = "";
    }
  }
  return host;
}
function getDomainFromLocale(localeCode, locales) {
  var _a, _b;
  const runtimeConfig = /* @__PURE__ */ useRuntimeConfig();
  const nuxtApp = /* @__PURE__ */ useNuxtApp();
  const config = runtimeConfig.public.i18n;
  const lang = locales.find((locale) => locale.code === localeCode);
  const domain = ((_b = (_a = config == null ? void 0 : config.locales) == null ? void 0 : _a[localeCode]) == null ? void 0 : _b.domain) ?? (lang == null ? void 0 : lang.domain);
  if (domain) {
    if (hasProtocol(domain, { strict: true })) {
      return domain;
    }
    let protocol;
    {
      const {
        node: { req }
      } = useRequestEvent(nuxtApp);
      protocol = req && isHTTPS(req) ? "https:" : "http:";
    }
    return protocol + "//" + domain;
  }
  console.warn(formatMessage("Could not find domain name for locale " + localeCode));
}
function useLocalePath(options2) {
  const { route, router, i18n } = options2 || {};
  return useLocalePath$1({
    route: route || useRoute(),
    router: router || useRouter(),
    i18n: i18n || getComposer((/* @__PURE__ */ useNuxtApp()).$i18n)
  });
}
function useSwitchLocalePath(options2) {
  const { route, router, i18n } = options2 || {};
  return useSwitchLocalePath$1({
    route: route || useRoute(),
    router: router || useRouter(),
    i18n: i18n || getComposer((/* @__PURE__ */ useNuxtApp()).$i18n)
  });
}
function useLocaleHead(options2) {
  const { addDirAttribute, addSeoAttributes, identifierAttribute, route, router, i18n } = options2 || {};
  return useLocaleHead$1({
    addDirAttribute: addDirAttribute || false,
    addSeoAttributes: addSeoAttributes || false,
    identifierAttribute: identifierAttribute || "hid",
    route: route || useRoute(),
    router: router || useRouter(),
    i18n: i18n || getComposer((/* @__PURE__ */ useNuxtApp()).$i18n)
  });
}
function setCookieLocale(i18n, locale) {
  return callVueI18nInterfaces(i18n, "setLocaleCookie", locale);
}
function mergeLocaleMessage(i18n, locale, messages) {
  return callVueI18nInterfaces(i18n, "mergeLocaleMessage", locale, messages);
}
function onBeforeLanguageSwitch(i18n, oldLocale, newLocale, initial, context) {
  return callVueI18nInterfaces(i18n, "onBeforeLanguageSwitch", oldLocale, newLocale, initial, context);
}
function onLanguageSwitched(i18n, oldLocale, newLocale) {
  return callVueI18nInterfaces(i18n, "onLanguageSwitched", oldLocale, newLocale);
}
async function loadAndSetLocale(newLocale, localeMessages2, i18n, {
  useCookie: useCookie2 = nuxtI18nOptionsDefault.detectBrowserLanguage.useCookie,
  skipSettingLocaleOnNavigate = nuxtI18nOptionsDefault.skipSettingLocaleOnNavigate,
  differentDomains = nuxtI18nOptionsDefault.differentDomains,
  initial = false,
  cacheMessages: cacheMessages2 = void 0,
  lazy = false
} = {}) {
  const nuxtApp = /* @__PURE__ */ useNuxtApp();
  let ret = false;
  const oldLocale = getLocale(i18n);
  if (!newLocale) {
    return [ret, oldLocale];
  }
  if (!initial && differentDomains) {
    return [ret, oldLocale];
  }
  if (oldLocale === newLocale) {
    return [ret, oldLocale];
  }
  const localeOverride = await onBeforeLanguageSwitch(i18n, oldLocale, newLocale, initial, nuxtApp);
  const localeCodes2 = getLocaleCodes(i18n);
  if (localeOverride && localeCodes2 && localeCodes2.includes(localeOverride)) {
    if (localeOverride === oldLocale) {
      return [ret, oldLocale];
    }
    newLocale = localeOverride;
  }
  const i18nFallbackLocales = getVueI18nPropertyValue(i18n, "fallbackLocale");
  if (lazy) {
    const setter = (locale, message) => mergeLocaleMessage(i18n, locale, message);
    if (i18nFallbackLocales) {
      const fallbackLocales = makeFallbackLocaleCodes(i18nFallbackLocales, [newLocale]);
      await Promise.all(fallbackLocales.map((locale) => loadLocale({ locale, setter, localeMessages: localeMessages2 }, cacheMessages2)));
    }
    await loadLocale({ locale: newLocale, setter, localeMessages: localeMessages2 }, cacheMessages2);
  }
  if (skipSettingLocaleOnNavigate) {
    return [ret, oldLocale];
  }
  if (useCookie2) {
    setCookieLocale(i18n, newLocale);
  }
  setLocale(i18n, newLocale);
  await onLanguageSwitched(i18n, oldLocale, newLocale);
  ret = true;
  return [ret, oldLocale];
}
function detectLocale(route, routeLocaleGetter, nuxtI18nOptions2, vueI18nOptions, initialLocaleLoader, detectLocaleContext, normalizedLocales, localeCodes2 = []) {
  const { strategy, defaultLocale, differentDomains } = nuxtI18nOptions2;
  const initialLocale = isFunction$1(initialLocaleLoader) ? initialLocaleLoader() : initialLocaleLoader;
  const {
    locale: browserLocale,
    stat,
    reason,
    from
  } = nuxtI18nOptions2.detectBrowserLanguage ? detectBrowserLanguage(
    route,
    nuxtI18nOptions2,
    nuxtI18nInternalOptions,
    vueI18nOptions,
    detectLocaleContext,
    localeCodes2,
    initialLocale
  ) : DefaultDetectBrowserLanguageFromResult;
  if (reason === "detect_ignore_on_ssg") {
    return initialLocale;
  }
  if ((from === "navigator_or_header" || from === "cookie" || from === "fallback") && browserLocale) {
    return browserLocale;
  }
  let finalLocale = browserLocale;
  if (!finalLocale) {
    if (differentDomains) {
      finalLocale = getLocaleDomain(normalizedLocales);
    } else if (strategy !== "no_prefix") {
      finalLocale = routeLocaleGetter(route);
    } else {
      if (!nuxtI18nOptions2.detectBrowserLanguage) {
        finalLocale = initialLocale;
      }
    }
  }
  if (!finalLocale && nuxtI18nOptions2.detectBrowserLanguage && nuxtI18nOptions2.detectBrowserLanguage.useCookie) {
    finalLocale = getLocaleCookie({ ...nuxtI18nOptions2.detectBrowserLanguage, localeCodes: localeCodes2 }) || "";
  }
  if (!finalLocale) {
    finalLocale = defaultLocale || "";
  }
  return finalLocale;
}
function detectRedirect({
  route,
  targetLocale,
  routeLocaleGetter,
  nuxtI18nOptions: nuxtI18nOptions2,
  calledWithRouting = false
}) {
  const nuxtApp = /* @__PURE__ */ useNuxtApp();
  const { strategy, differentDomains } = nuxtI18nOptions2;
  let redirectPath = "";
  const { fullPath: toFullPath } = route.to;
  if (!differentDomains && (calledWithRouting || strategy !== "no_prefix") && routeLocaleGetter(route.to) !== targetLocale) {
    const routePath = nuxtApp.$switchLocalePath(targetLocale) || nuxtApp.$localePath(toFullPath, targetLocale);
    if (isString$1(routePath) && routePath && !isEqual(routePath, toFullPath) && !routePath.startsWith("//")) {
      redirectPath = !(route.from && route.from.fullPath === routePath) ? routePath : "";
    }
  }
  if ((differentDomains || isSSG) && routeLocaleGetter(route.to) !== targetLocale) {
    const switchLocalePath2 = useSwitchLocalePath({
      i18n: getComposer(nuxtApp.$i18n),
      route: route.to,
      router: nuxtApp.$router
    });
    const routePath = switchLocalePath2(targetLocale);
    if (isString$1(routePath) && routePath && !isEqual(routePath, toFullPath) && !routePath.startsWith("//")) {
      redirectPath = routePath;
    }
  }
  return redirectPath;
}
function isRootRedirectOptions(rootRedirect) {
  return isObject$1(rootRedirect) && "path" in rootRedirect && "statusCode" in rootRedirect;
}
const useRedirectState = () => useState(NUXT_I18N_MODULE_ID + ":redirect", () => "");
function _navigate(redirectPath, status) {
  return navigateTo(redirectPath, { redirectCode: status });
}
async function navigate(args, {
  status = 302,
  rootRedirect = nuxtI18nOptionsDefault.rootRedirect,
  differentDomains = nuxtI18nOptionsDefault.differentDomains,
  skipSettingLocaleOnNavigate = nuxtI18nOptionsDefault.skipSettingLocaleOnNavigate,
  enableNavigate = false
} = {}) {
  const { i18n, locale, route } = args;
  let { redirectPath } = args;
  if (route.path === "/" && rootRedirect) {
    if (isString$1(rootRedirect)) {
      redirectPath = "/" + rootRedirect;
    } else if (isRootRedirectOptions(rootRedirect)) {
      redirectPath = "/" + rootRedirect.path;
      status = rootRedirect.statusCode;
    }
    return _navigate(redirectPath, status);
  }
  if (!differentDomains) {
    if (redirectPath) {
      return _navigate(redirectPath, status);
    }
  } else {
    const state = useRedirectState();
    if (state.value && state.value !== redirectPath) {
      {
        state.value = redirectPath;
      }
    }
  }
}
function injectNuxtHelpers(nuxt, i18n) {
  defineGetter(nuxt, "$i18n", i18n.global);
  for (const pair of [
    ["getRouteBaseName", getRouteBaseName],
    ["localePath", localePath],
    ["localeRoute", localeRoute],
    ["switchLocalePath", switchLocalePath],
    ["localeHead", localeHead]
  ]) {
    defineGetter(nuxt, "$" + pair[0], proxyNuxt(nuxt, pair[1]));
  }
}
function extendPrefixable(differentDomains) {
  return (opts) => {
    return DefaultPrefixable(opts) && !differentDomains;
  };
}
function extendSwitchLocalePathIntercepter(differentDomains, normalizedLocales) {
  return (path, locale) => {
    if (differentDomains) {
      const domain = getDomainFromLocale(locale, normalizedLocales);
      if (domain) {
        return joinURL(domain, path);
      } else {
        return path;
      }
    } else {
      return DefaultSwitchLocalePathIntercepter(path);
    }
  };
}
function extendBaseUrl(baseUrl, options2) {
  return () => {
    var _a;
    const ctx = /* @__PURE__ */ useNuxtApp();
    const runtimeConfig = /* @__PURE__ */ useRuntimeConfig();
    if (isFunction$1(baseUrl)) {
      const baseUrlResult = baseUrl(ctx);
      return baseUrlResult;
    }
    const { differentDomains, localeCodeLoader, normalizedLocales } = options2;
    const localeCode = isFunction$1(localeCodeLoader) ? localeCodeLoader() : localeCodeLoader;
    if (differentDomains && localeCode) {
      const domain = getDomainFromLocale(localeCode, normalizedLocales);
      if (domain) {
        return domain;
      }
    }
    const config = (_a = runtimeConfig == null ? void 0 : runtimeConfig.public) == null ? void 0 : _a.i18n;
    if (config == null ? void 0 : config.baseUrl) {
      return config.baseUrl;
    }
    return baseUrl;
  };
}
const cacheMessages = /* @__PURE__ */ new Map();
const i18n_w1yNAiqacI = /* @__PURE__ */ defineNuxtPlugin({
  name: "i18n:plugin",
  parallel: parallelPlugin,
  async setup(nuxt) {
    let __temp, __restore;
    const router = useRouter();
    const route = useRoute();
    const { vueApp: app } = nuxt;
    const nuxtContext = nuxt;
    const nuxtI18nOptions$1 = { ...nuxtI18nOptions };
    const vueI18nOptions = ([__temp, __restore] = executeAsync(() => loadVueI18nOptions(vueI18nConfigs, /* @__PURE__ */ useNuxtApp())), __temp = await __temp, __restore(), __temp);
    const useCookie2 = nuxtI18nOptions$1.detectBrowserLanguage && nuxtI18nOptions$1.detectBrowserLanguage.useCookie;
    const { __normalizedLocales: normalizedLocales } = nuxtI18nInternalOptions;
    const {
      defaultLocale,
      differentDomains,
      skipSettingLocaleOnNavigate,
      lazy,
      routesNameSeparator,
      defaultLocaleRouteNameSuffix,
      strategy,
      rootRedirect
    } = nuxtI18nOptions$1;
    nuxtI18nOptions$1.baseUrl = extendBaseUrl(nuxtI18nOptions$1.baseUrl, {
      differentDomains,
      localeCodeLoader: defaultLocale,
      normalizedLocales
    });
    const getLocaleFromRoute = createLocaleFromRouteGetter(
      localeCodes,
      routesNameSeparator,
      defaultLocaleRouteNameSuffix
    );
    vueI18nOptions.messages = vueI18nOptions.messages || {};
    vueI18nOptions.fallbackLocale = vueI18nOptions.fallbackLocale ?? false;
    registerGlobalOptions(router, {
      ...nuxtI18nOptions$1,
      dynamicRouteParamsKey: "nuxtI18n",
      switchLocalePathIntercepter: extendSwitchLocalePathIntercepter(differentDomains, normalizedLocales),
      prefixable: extendPrefixable(differentDomains)
    });
    const getDefaultLocale = (defaultLocale2) => defaultLocale2 || vueI18nOptions.locale || "en-US";
    let initialLocale = detectLocale(
      route,
      getLocaleFromRoute,
      nuxtI18nOptions$1,
      vueI18nOptions,
      getDefaultLocale(defaultLocale),
      { ssg: "normal", callType: "setup", firstAccess: true },
      normalizedLocales,
      localeCodes
    );
    vueI18nOptions.messages = ([__temp, __restore] = executeAsync(() => loadInitialMessages(vueI18nOptions.messages, localeMessages, {
      ...nuxtI18nOptions$1,
      initialLocale,
      fallbackLocale: vueI18nOptions.fallbackLocale,
      localeCodes,
      cacheMessages
    })), __temp = await __temp, __restore(), __temp);
    initialLocale = getDefaultLocale(initialLocale);
    const i18n = createI18n({
      ...vueI18nOptions,
      locale: initialLocale
    });
    let notInitialSetup = true;
    const isInitialLocaleSetup = (locale) => initialLocale !== locale && notInitialSetup;
    extendI18n(i18n, {
      locales: nuxtI18nOptions$1.locales,
      localeCodes,
      baseUrl: nuxtI18nOptions$1.baseUrl,
      context: nuxtContext,
      hooks: {
        onExtendComposer(composer) {
          composer.strategy = strategy;
          composer.localeProperties = computed(() => {
            return normalizedLocales.find((l) => l.code === composer.locale.value) || {
              code: composer.locale.value
            };
          });
          composer.setLocale = async (locale) => {
            const localeSetup = isInitialLocaleSetup(locale);
            const [modified] = await loadAndSetLocale(locale, localeMessages, i18n, {
              useCookie: useCookie2,
              differentDomains,
              initial: localeSetup,
              cacheMessages,
              skipSettingLocaleOnNavigate,
              lazy
            });
            if (modified && localeSetup) {
              notInitialSetup = false;
            }
            const redirectPath = detectRedirect({
              route: { to: route },
              targetLocale: locale,
              routeLocaleGetter: getLocaleFromRoute,
              nuxtI18nOptions: nuxtI18nOptions$1
            });
            await navigate(
              {
                i18n,
                redirectPath,
                locale,
                route
              },
              {
                differentDomains,
                skipSettingLocaleOnNavigate,
                rootRedirect,
                enableNavigate: true
              }
            );
          };
          composer.differentDomains = differentDomains;
          composer.defaultLocale = defaultLocale;
          composer.getBrowserLocale = () => getBrowserLocale(nuxtI18nInternalOptions);
          composer.getLocaleCookie = () => getLocaleCookie({ ...nuxtI18nOptions$1.detectBrowserLanguage, localeCodes });
          composer.setLocaleCookie = (locale) => setLocaleCookie(locale, nuxtI18nOptions$1.detectBrowserLanguage || void 0);
          composer.onBeforeLanguageSwitch = (oldLocale, newLocale, initialSetup, context) => nuxt.callHook("i18n:beforeLocaleSwitch", { oldLocale, newLocale, initialSetup, context });
          composer.onLanguageSwitched = (oldLocale, newLocale) => nuxt.callHook("i18n:localeSwitched", { oldLocale, newLocale });
          composer.finalizePendingLocaleChange = async () => {
            if (!i18n.__pendingLocale) {
              return;
            }
            setLocale(i18n, i18n.__pendingLocale);
            if (i18n.__resolvePendingLocalePromise) {
              await i18n.__resolvePendingLocalePromise();
            }
            i18n.__pendingLocale = void 0;
          };
          composer.waitForPendingLocaleChange = async () => {
            if (i18n.__pendingLocale && i18n.__pendingLocalePromise) {
              await i18n.__pendingLocalePromise;
            }
          };
        },
        onExtendExportedGlobal(g) {
          return {
            strategy: {
              get() {
                return g.strategy;
              }
            },
            localeProperties: {
              get() {
                return g.localeProperties.value;
              }
            },
            setLocale: {
              get() {
                return async (locale) => Reflect.apply(g.setLocale, g, [locale]);
              }
            },
            differentDomains: {
              get() {
                return g.differentDomains;
              }
            },
            defaultLocale: {
              get() {
                return g.defaultLocale;
              }
            },
            getBrowserLocale: {
              get() {
                return () => Reflect.apply(g.getBrowserLocale, g, []);
              }
            },
            getLocaleCookie: {
              get() {
                return () => Reflect.apply(g.getLocaleCookie, g, []);
              }
            },
            setLocaleCookie: {
              get() {
                return (locale) => Reflect.apply(g.setLocaleCookie, g, [locale]);
              }
            },
            onBeforeLanguageSwitch: {
              get() {
                return (oldLocale, newLocale, initialSetup, context) => Reflect.apply(g.onBeforeLanguageSwitch, g, [oldLocale, newLocale, initialSetup, context]);
              }
            },
            onLanguageSwitched: {
              get() {
                return (oldLocale, newLocale) => Reflect.apply(g.onLanguageSwitched, g, [oldLocale, newLocale]);
              }
            },
            finalizePendingLocaleChange: {
              get() {
                return () => Reflect.apply(g.finalizePendingLocaleChange, g, []);
              }
            },
            waitForPendingLocaleChange: {
              get() {
                return () => Reflect.apply(g.waitForPendingLocaleChange, g, []);
              }
            }
          };
        },
        onExtendVueI18n(composer) {
          return {
            strategy: {
              get() {
                return composer.strategy;
              }
            },
            localeProperties: {
              get() {
                return composer.localeProperties.value;
              }
            },
            setLocale: {
              get() {
                return async (locale) => Reflect.apply(composer.setLocale, composer, [locale]);
              }
            },
            differentDomains: {
              get() {
                return composer.differentDomains;
              }
            },
            defaultLocale: {
              get() {
                return composer.defaultLocale;
              }
            },
            getBrowserLocale: {
              get() {
                return () => Reflect.apply(composer.getBrowserLocale, composer, []);
              }
            },
            getLocaleCookie: {
              get() {
                return () => Reflect.apply(composer.getLocaleCookie, composer, []);
              }
            },
            setLocaleCookie: {
              get() {
                return (locale) => Reflect.apply(composer.setLocaleCookie, composer, [locale]);
              }
            },
            onBeforeLanguageSwitch: {
              get() {
                return (oldLocale, newLocale, initialSetup, context) => Reflect.apply(composer.onBeforeLanguageSwitch, composer, [
                  oldLocale,
                  newLocale,
                  initialSetup,
                  context
                ]);
              }
            },
            onLanguageSwitched: {
              get() {
                return (oldLocale, newLocale) => Reflect.apply(composer.onLanguageSwitched, composer, [oldLocale, newLocale]);
              }
            },
            finalizePendingLocaleChange: {
              get() {
                return () => Reflect.apply(composer.finalizePendingLocaleChange, composer, []);
              }
            },
            waitForPendingLocaleChange: {
              get() {
                return () => Reflect.apply(composer.waitForPendingLocaleChange, composer, []);
              }
            }
          };
        }
      }
    });
    const pluginOptions = {
      __composerExtend: (c) => {
        const g = getComposer(i18n);
        c.strategy = g.strategy;
        c.localeProperties = computed(() => g.localeProperties.value);
        c.setLocale = g.setLocale;
        c.differentDomains = g.differentDomains;
        c.getBrowserLocale = g.getBrowserLocale;
        c.getLocaleCookie = g.getLocaleCookie;
        c.setLocaleCookie = g.setLocaleCookie;
        c.onBeforeLanguageSwitch = g.onBeforeLanguageSwitch;
        c.onLanguageSwitched = g.onLanguageSwitched;
        c.finalizePendingLocaleChange = g.finalizePendingLocaleChange;
        c.waitForPendingLocaleChange = g.waitForPendingLocaleChange;
        return () => {
        };
      }
    };
    app.use(i18n, pluginOptions);
    injectNuxtHelpers(nuxtContext, i18n);
    let routeChangeCount = 0;
    addRouteMiddleware(
      "locale-changing",
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      /* @__PURE__ */ defineNuxtRouteMiddleware(async (to, from) => {
        let __temp2, __restore2;
        const locale = detectLocale(
          to,
          getLocaleFromRoute,
          nuxtI18nOptions$1,
          vueI18nOptions,
          () => {
            return getLocale(i18n) || getDefaultLocale(defaultLocale);
          },
          {
            ssg: "normal",
            callType: "routing",
            firstAccess: routeChangeCount === 0
          },
          normalizedLocales,
          localeCodes
        );
        const localeSetup = isInitialLocaleSetup(locale);
        const [modified] = ([__temp2, __restore2] = executeAsync(() => loadAndSetLocale(locale, localeMessages, i18n, {
          useCookie: useCookie2,
          differentDomains,
          initial: localeSetup,
          cacheMessages,
          skipSettingLocaleOnNavigate,
          lazy
        })), __temp2 = await __temp2, __restore2(), __temp2);
        if (modified && localeSetup) {
          notInitialSetup = false;
        }
        const redirectPath = detectRedirect({
          route: { to, from },
          targetLocale: locale,
          routeLocaleGetter: nuxtI18nOptions$1.strategy === "no_prefix" ? () => locale : getLocaleFromRoute,
          nuxtI18nOptions: nuxtI18nOptions$1,
          calledWithRouting: true
        });
        routeChangeCount++;
        return navigate(
          {
            i18n,
            redirectPath,
            locale,
            route: to
          },
          {
            differentDomains,
            skipSettingLocaleOnNavigate,
            rootRedirect
          }
        );
      }),
      { global: true }
    );
  }
});
const preference = "dark";
const plugin_server_qJ3V1hB4BV = /* @__PURE__ */ defineNuxtPlugin((nuxtApp) => {
  const colorMode = useState("color-mode", () => reactive({
    preference,
    value: preference,
    unknown: true,
    forced: false
  })).value;
  const htmlAttrs = {};
  {
    useHead({ htmlAttrs });
  }
  useRouter().afterEach((to) => {
    const forcedColorMode = to.meta.colorMode;
    if (forcedColorMode && forcedColorMode !== "system") {
      colorMode.value = htmlAttrs["data-color-mode-forced"] = forcedColorMode;
      colorMode.forced = true;
    } else if (forcedColorMode === "system") {
      console.warn("You cannot force the colorMode to system at the page level.");
    }
  });
  nuxtApp.provide("colorMode", colorMode);
});
const _1_absoluteImageUrls_server_qftBF1YoVO = /* @__PURE__ */ defineNuxtPlugin({
  enforce: "post",
  setup() {
    const head = injectHead();
    if (!head)
      return;
    const resolver2 = createSitePathResolver({
      withBase: true,
      absolute: true,
      canonical: true
    });
    head.use({
      hooks: {
        "tags:resolve": async ({ tags }) => {
          for (const tag of tags) {
            if (tag.tag !== "meta")
              continue;
            if (tag.props.property !== "og:image:url" && tag.props.property !== "og:image" && tag.props.name !== "twitter:image")
              continue;
            if (!tag.props.content || tag.props.content.startsWith("http") || tag.props.content.startsWith("//"))
              continue;
            tag.props.content = unref(resolver2(tag.props.content));
          }
        }
      }
    });
  }
});
const _0_routeRules_server_D01Ny9Oajm = /* @__PURE__ */ defineNuxtPlugin({
  enforce: "post",
  async setup() {
    const head = injectHead();
    if (!head)
      return;
    const event = useRequestEvent();
    if (event.context._nitro.routeRules.head)
      head.push(event.context._nitro.routeRules.head, { mode: "server" });
    if (event.context._nitro.routeRules.seoMeta) {
      const meta = unpackMeta({ ...event.context._nitro.routeRules.seoMeta });
      head.push({
        meta
      }, { mode: "server" });
    }
  }
});
const init_iqyeXtZCks = /* @__PURE__ */ defineNuxtPlugin({
  name: "nuxt-schema-org:init",
  enforce: "post",
  setup(nuxtApp) {
    const head = injectHead();
    const config = (/* @__PURE__ */ useRuntimeConfig())["nuxt-schema-org"] || (/* @__PURE__ */ useRuntimeConfig()).public["nuxt-schema-org"];
    const route = useRoute();
    const siteConfig = useSiteConfig();
    const schemaOrg = computed(() => {
      var _a;
      return {
        ...((_a = route.meta) == null ? void 0 : _a.schemaOrg) || {},
        ...siteConfig,
        url: joinURL(siteConfig.url, route.path),
        host: siteConfig.url,
        inLanguage: siteConfig.currentLocale || siteConfig.defaultLocale,
        path: route.path
      };
    });
    head.push({ templateParams: { schemaOrg } });
    head.use(
      SchemaOrgUnheadPlugin({}, async () => {
        const meta = {};
        await nuxtApp.hooks.callHook("schema-org:meta", meta);
        return meta;
      }, {
        minify: config.minify,
        trailingSlash: siteConfig.trailingSlash
      })
    );
  }
});
const plugins = [
  unhead_uGsi8HO7ef,
  plugin,
  _0_siteConfig_PmgwD9dYJy,
  revive_payload_server_lq8NAzC4IZ,
  components_plugin_KR1HBZs4kY,
  titles_CZZrVZoIyy,
  defaults_oYhGr5yYt9,
  siteConfig_JLt9UuYZxZ,
  inferSeoMetaPlugin_hZhhlDCNd2,
  defaults_dOQDx4xFky,
  og_image_canonical_urls_server_EgfbWs4KJr,
  route_rule_og_image_server_NjzMbK7oJI,
  robot_meta_server_5dG6q8tTdi,
  i18n_server_eydIu9K4Cx,
  composition_nLOleWny7F,
  i18n_w1yNAiqacI,
  plugin_server_qJ3V1hB4BV,
  _1_absoluteImageUrls_server_qftBF1YoVO,
  _0_routeRules_server_D01Ny9Oajm,
  init_iqyeXtZCks
];
const RouteProvider = defineComponent({
  props: {
    vnode: {
      type: Object,
      required: true
    },
    route: {
      type: Object,
      required: true
    },
    vnodeRef: Object,
    renderKey: String,
    trackRootNodes: Boolean
  },
  setup(props) {
    const previousKey = props.renderKey;
    const previousRoute = props.route;
    const route = {};
    for (const key in props.route) {
      Object.defineProperty(route, key, {
        get: () => previousKey === props.renderKey ? props.route[key] : previousRoute[key]
      });
    }
    provide(PageRouteSymbol, shallowReactive(route));
    return () => {
      return h(props.vnode, { ref: props.vnodeRef });
    };
  }
});
const __nuxt_component_0 = defineComponent({
  name: "NuxtPage",
  inheritAttrs: false,
  props: {
    name: {
      type: String
    },
    transition: {
      type: [Boolean, Object],
      default: void 0
    },
    keepalive: {
      type: [Boolean, Object],
      default: void 0
    },
    route: {
      type: Object
    },
    pageKey: {
      type: [Function, String],
      default: null
    }
  },
  setup(props, { attrs, expose }) {
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    const pageRef = ref();
    const forkRoute = inject(PageRouteSymbol, null);
    let previousPageKey;
    expose({ pageRef });
    inject(LayoutMetaSymbol, null);
    let vnode;
    const done = nuxtApp.deferHydration();
    if (props.pageKey) {
      watch(() => props.pageKey, (next, prev) => {
        if (next !== prev) {
          nuxtApp.callHook("page:loading:start");
        }
      });
    }
    return () => {
      return h(RouterView, { name: props.name, route: props.route, ...attrs }, {
        default: (routeProps) => {
          if (!routeProps.Component) {
            done();
            return;
          }
          const key = generateRouteKey$1(routeProps, props.pageKey);
          if (!nuxtApp.isHydrating && !hasChildrenRoutes(forkRoute, routeProps.route, routeProps.Component) && previousPageKey === key) {
            nuxtApp.callHook("page:loading:end");
          }
          previousPageKey = key;
          const hasTransition = !!(props.transition ?? routeProps.route.meta.pageTransition ?? appPageTransition);
          const transitionProps = hasTransition && _mergeTransitionProps([
            props.transition,
            routeProps.route.meta.pageTransition,
            appPageTransition,
            { onAfterLeave: () => {
              nuxtApp.callHook("page:transition:finish", routeProps.Component);
            } }
          ].filter(Boolean));
          const keepaliveConfig = props.keepalive ?? routeProps.route.meta.keepalive ?? appKeepalive;
          vnode = _wrapIf(
            Transition,
            hasTransition && transitionProps,
            wrapInKeepAlive(
              keepaliveConfig,
              h(Suspense, {
                suspensible: true,
                onPending: () => nuxtApp.callHook("page:start", routeProps.Component),
                onResolve: () => {
                  nextTick(() => nuxtApp.callHook("page:finish", routeProps.Component).then(() => nuxtApp.callHook("page:loading:end")).finally(done));
                }
              }, {
                default: () => {
                  const providerVNode = h(RouteProvider, {
                    key: key || void 0,
                    vnode: routeProps.Component,
                    route: routeProps.route,
                    renderKey: key || void 0,
                    trackRootNodes: hasTransition,
                    vnodeRef: pageRef
                  });
                  return providerVNode;
                }
              })
            )
          ).default();
          return vnode;
        }
      });
    };
  }
});
function _mergeTransitionProps(routeProps) {
  const _props = routeProps.map((prop) => ({
    ...prop,
    onAfterLeave: prop.onAfterLeave ? toArray(prop.onAfterLeave) : void 0
  }));
  return defu(..._props);
}
function hasChildrenRoutes(fork, newRoute, Component) {
  if (!fork) {
    return false;
  }
  const index = newRoute.matched.findIndex((m) => {
    var _a;
    return ((_a = m.components) == null ? void 0 : _a.default) === (Component == null ? void 0 : Component.type);
  });
  return index < newRoute.matched.length - 1;
}
function useRequestURL() {
  {
    const url = getRequestURL(useRequestEvent());
    url.pathname = joinURL((/* @__PURE__ */ useRuntimeConfig()).app.baseURL, url.pathname);
    return url;
  }
}
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "app",
  __ssrInlineRender: true,
  setup(__props) {
    var _a, _b;
    const { t } = useI18n();
    const route = useRoute();
    const i18nHead = useLocaleHead({
      addSeoAttributes: true
    });
    const url = useRequestURL();
    const origin = url.origin;
    useHead({
      htmlAttrs: {
        lang: (_a = i18nHead.value.htmlAttrs) == null ? void 0 : _a.lang
      },
      titleTemplate: (titleChunk) => {
        return route.name.startsWith("index") && !route.query.q ? titleChunk || t("seo.title") : `${titleChunk} - SearchEmoji`;
      },
      link: [
        ...i18nHead.value.link || [],
        {
          rel: "icon",
          type: "image/png",
          sizes: "16x16",
          href: "/favicon-16x16.png"
        },
        {
          rel: "icon",
          type: "image/png",
          sizes: "32x32",
          href: "/favicon-32x32.png"
        },
        {
          rel: "apple-touch-icon",
          sizes: "152x152",
          href: "/apple-touch-icon.png"
        },
        {
          rel: "manifest",
          href: "/site.webmanifest"
        }
      ],
      meta: [
        ...((_b = i18nHead.value) == null ? void 0 : _b.meta) || [],
        { name: "description", content: t("seo.description") },
        { property: "og:site_name", content: t("seo.siteName") },
        { property: "og:url", content: `${origin}/` },
        { property: "og:type", content: "website" },
        { property: "og:title", content: t("seo.title") },
        { property: "og:description", content: t("seo.description") },
        { property: "og:image", content: `${origin}/cover.jpg` },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:domain", content: url.host },
        { name: "twitter:url", content: `${origin}/` },
        { name: "twitter:title", content: t("seo.title") },
        { name: "twitter:description", content: t("seo.description") },
        { name: "twitter:image", content: `${origin}/cover.jpg` }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtPage = __nuxt_component_0;
      _push(ssrRenderComponent(_component_NuxtPage, _attrs, null, _parent));
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("app.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "error",
  __ssrInlineRender: true,
  setup(__props) {
    const error = useError();
    useHead({
      title: `${error.value.statusCode} - ${error.value.url}`
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "m-6" }, _attrs))}><h2 class="text-4xl color-title">${ssrInterpolate(unref(error).statusCode)}</h2><div class="mt-4">${ssrInterpolate(unref(error).message)}</div><div class="card p-6 rounded-2xl mt-4">${unref(error).stack}</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("error.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const ErrorComponent = _sfc_main$1;
const _sfc_main = {
  __name: "nuxt-root",
  __ssrInlineRender: true,
  setup(__props) {
    const IslandRenderer = defineAsyncComponent(() => import('./_nuxt/island-renderer-vxY27SqH.mjs').then((r) => r.default || r));
    const nuxtApp = /* @__PURE__ */ useNuxtApp();
    nuxtApp.deferHydration();
    nuxtApp.ssrContext.url;
    const SingleRenderer = false;
    provide(PageRouteSymbol, useRoute());
    nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
    const error = useError();
    onErrorCaptured((err, target, info) => {
      nuxtApp.hooks.callHook("vue:error", err, target, info).catch((hookError) => console.error("[nuxt] Error in `vue:error` hook", hookError));
      {
        const p2 = nuxtApp.runWithContext(() => showError(err));
        onServerPrefetch(() => p2);
        return false;
      }
    });
    const islandContext = nuxtApp.ssrContext.islandContext;
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderSuspense(_push, {
        default: () => {
          if (unref(error)) {
            _push(ssrRenderComponent(unref(ErrorComponent), { error: unref(error) }, null, _parent));
          } else if (unref(islandContext)) {
            _push(ssrRenderComponent(unref(IslandRenderer), { context: unref(islandContext) }, null, _parent));
          } else if (unref(SingleRenderer)) {
            ssrRenderVNode(_push, createVNode(resolveDynamicComponent(unref(SingleRenderer)), null, null), _parent);
          } else {
            _push(ssrRenderComponent(unref(_sfc_main$2), null, null, _parent));
          }
        },
        _: 1
      });
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/.pnpm/nuxt@3.9.1_@types+node@18.18.9_eslint@8.53.0_rollup@3.29.4_typescript@5.2.2_vite@5.0.11/node_modules/nuxt/dist/app/components/nuxt-root.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const RootComponent = _sfc_main;
let entry;
{
  entry = async function createNuxtAppServer(ssrContext) {
    const vueApp = createApp(RootComponent);
    const nuxt = createNuxtApp({ vueApp, ssrContext });
    try {
      await applyPlugins(nuxt, plugins);
      await nuxt.hooks.callHook("app:created", vueApp);
    } catch (err) {
      await nuxt.hooks.callHook("app:error", err);
      nuxt.payload.error = nuxt.payload.error || err;
    }
    if (ssrContext == null ? void 0 : ssrContext._renderResponse) {
      throw new Error("skipping render");
    }
    return vueApp;
  };
}
const entry$1 = (ssrContext) => entry(ssrContext);

export { useRouter as a, useI18n as b, createError as c, useLocalePath as d, entry$1 as default, useHead as e, useSwitchLocalePath as f, useSchemaOrg as g, defineWebSite as h, hasProtocol as i, joinURL as j, parseQuery$1 as k, useRuntimeConfig as l, navigateTo as m, nuxtLinkDefaults as n, withoutTrailingSlash$1 as o, parseURL as p, useState as q, asyncDataDefaults as r, useNuxtApp as s, fetchDefaults as t, useRoute as u, useRequestFetch as v, withTrailingSlash$1 as w, useOgImageRuntimeConfig as x, useSiteConfig as y };
//# sourceMappingURL=server.mjs.map
