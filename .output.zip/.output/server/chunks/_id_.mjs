import { d as defineEventHandler, g as getQuery, c as createError } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'nitropack/dist/runtime/plugin';
import 'node:fs';
import 'node:url';

const _id_ = defineEventHandler((ev) => {
  var _a, _b, _c;
  const id = ((_a = ev.context.params) == null ? void 0 : _a.id) || "";
  const query = getQuery(ev);
  const locale = query.locale;
  const res = ev.context.emojis.find((emoji2) => emoji2.c === id);
  const groups = ev.context.groups.map((g) => ({ n: g.name, nt: g[locale] }));
  const groupName = groups[res.g];
  const subGroupName = groups[res.s];
  if (!res) {
    throw createError({
      statusCode: 404,
      statusMessage: "Emoji not found"
    });
  }
  const emoji = {
    ...res,
    t: ((_b = res.t) == null ? void 0 : _b[locale]) || null,
    k: ((_c = res.k) == null ? void 0 : _c[locale]) || [],
    g: groupName.nt,
    s: subGroupName.nt
  };
  return emoji;
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
