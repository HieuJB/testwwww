import { d as defineEventHandler, g as getQuery } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'nitropack/dist/runtime/plugin';
import 'node:fs';
import 'node:url';

const home = defineEventHandler((ev) => {
  const query = getQuery(ev);
  const locale = query.locale;
  const quality = (query.quality || "").split(",");
  const skinTone = (query.skinTone || "").split(",");
  const groups = ev.context.groups.map((g) => ({ n: g.name, nt: g[locale] }));
  const skinToneSubGroupIndex = groups.findIndex((gn) => gn.n === "skin-tone");
  const filtered = ev.context.emojis.filter(
    (li) => quality.includes(li.q) && (!li.n.includes("skin tone") || li.n.includes("skin tone") && (skinTone.find((fst) => li.n.includes(" " + fst)) || li.s === skinToneSubGroupIndex))
  );
  const emojis = filtered.map((emoji) => ({
    c: emoji.c,
    e: emoji.e,
    g: emoji.g,
    s: emoji.s,
    t: emoji.t[locale]
  }));
  return { groups, emojis };
});

export { home as default };
//# sourceMappingURL=home.mjs.map
