import { d as defineEventHandler, g as getQuery } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'nitropack/dist/runtime/plugin';
import 'node:fs';
import 'node:url';

const emojis = defineEventHandler((ev) => {
  const query = getQuery(ev);
  const locale = query.locale;
  const quality = (query.quality || "").split(",");
  const skinTone = (query.skinTone || "").split(",");
  const groups = ev.context.groups.map((g) => ({ n: g.name, nt: g[locale] }));
  const skinToneSubGroupIndex = groups.findIndex((gn) => gn.n === "skin-tone");
  const filtered = ev.context.emojis.filter(
    (li) => quality.includes(li.q) && (!li.n.includes("skin tone") || li.n.includes("skin tone") && (skinTone.find((fst) => li.n.includes(" " + fst)) || li.s === skinToneSubGroupIndex))
  );
  return filtered.map((emoji) => {
    var _a, _b;
    return {
      c: emoji.c,
      n: emoji.n,
      t: (_a = emoji.t) == null ? void 0 : _a[locale],
      k: (_b = emoji.k) == null ? void 0 : _b[locale]
    };
  });
});

export { emojis as default };
//# sourceMappingURL=emojis.mjs.map
