import { d as defineEventHandler, u as useRuntimeConfig, r as readBody } from '../../../../runtime.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'ipx';

const register = defineEventHandler(async (event) => {
  const baseAPI = useRuntimeConfig(event).apiBaseUrl;
  const brandCode = useRuntimeConfig(event).brandCode;
  const body = await readBody(event);
  body.brand_code = brandCode;
  const data = await $fetch(baseAPI + event._path, {
    method: "POST",
    body
  });
  return data;
});

export { register as default };
//# sourceMappingURL=register.mjs.map
