globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node:http';
import 'node:https';
export { a1 as default } from './chunks/nitro/node-server.mjs';
import 'fs';
import 'path';
import 'vue';
import 'nitropack/dist/runtime/plugin';
import 'node:fs';
import 'node:url';
//# sourceMappingURL=index.mjs.map
