import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node:http';
import 'node:https';
export { ad as default } from './chunks/nitro/nitro.mjs';
import 'lru-cache';
import 'devalue';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'ipx';
//# sourceMappingURL=index.mjs.map
