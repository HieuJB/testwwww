import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node:http';
import 'node:https';
export { a7 as default } from './chunks/runtime.mjs';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import 'ipx';
//# sourceMappingURL=index.mjs.map
