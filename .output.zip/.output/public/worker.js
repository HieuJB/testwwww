// public/worker.js
self.addEventListener('message', async (event) => {
  const imageUrl = event.data;

  try {
    // Fetch the image
    const response = await fetch(imageUrl);
    console.log(response);
    
    const blob = await response.blob();

    // Send the image data (as a blob) back to the main thread
    self.postMessage({
      imageUrl,
      blob,
    });
  } catch (error) {
    console.error(`Failed to load image: ${imageUrl}`, error);
    self.postMessage({ imageUrl, blob: null });
  }
});
