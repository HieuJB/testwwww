import{bW as e}from"./mKL8z1WK.js";const a=e("actions",{state:()=>({isOpenLoginForm:!1,isOpenRegisterForm:!1,isOpenFilterLeague:!1,isOpenSearchForm:!1}),actions:{}});export{a};
