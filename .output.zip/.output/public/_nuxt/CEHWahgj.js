import{dw as f}from"./BiNerXF2.js";export{f as default};
