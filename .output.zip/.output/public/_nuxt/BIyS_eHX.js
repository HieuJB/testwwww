import{bT as s}from"./DL1fGiRR.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
