import{ao as e}from"./DOg6D9pF.js";const a=e("actions",{state:()=>({isOpenLoginForm:!1,isOpenRegisterForm:!1,isOpenFilterLeague:!1,isOpenSearchForm:!1}),actions:{}});export{a};
