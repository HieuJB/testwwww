import{N as s}from"./Bz_exKAH.js";const t=s("/img/fx.svg");export{t as _};
