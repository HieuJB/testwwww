import"./DC0_vZ0_.js";function n(){return new URL(window.location.href)}export{n as u};
