import{cj as o,a as r,r as a}from"./CvZwDZOA.js";import{s as t}from"./Dpiou21P.js";const n=o(()=>{const e=r();t();const s=a(null);return{route:e,infoLeague:s}});export{n as u};
