import{Y as s}from"./DJS8guEt.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
