import{N as s}from"./DiF-gjqG.js";const t=s("/img/fx.svg");export{t as _};
