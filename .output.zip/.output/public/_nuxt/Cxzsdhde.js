import{bZ as s}from"./C1MTHeC0.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
