import{M as s}from"./BPoIvXaB.js";const t=s("/img/fx.svg");export{t as _};
