import{cj as o,bG as r,aN as a}from"./n1csI74N.js";import{s as t}from"./bgueJbKb.js";const n=o(()=>{const e=r();t();const s=a(null);return{route:e,infoLeague:s}});export{n as u};
