import{bZ as s}from"./Bj6u4HDk.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
