import{Q as s}from"./Dxxz3yQz.js";const t=s("/img/fx.svg");export{t as _};
