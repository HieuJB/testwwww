import{dx as f}from"./BTCeps3w.js";export{f as default};
