import"./CNWrwO0D.js";const e=window.setInterval;export{e as s};
