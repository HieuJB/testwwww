import{Q as s}from"./B41Wcqf9.js";const t=s("/img/fx.svg");export{t as _};
