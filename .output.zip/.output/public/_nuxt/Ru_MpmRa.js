import{ci as o,bF as r,aM as a}from"./Dh5VsZTZ.js";import{s as t}from"./sgEYhTcQ.js";const n=o(()=>{const e=r();t();const s=a(null);return{route:e,infoLeague:s}});export{n as u};
