import{G as s}from"./DFh11JwS.js";const t=s("/img/fx.svg");export{t as _};
