import{bT as s}from"./C5ETq8pw.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
