import{_ as e,c,o as n}from"./BsbA-9aa.js";const o={},t={id:"warehouse-screen",class:"mcontent container"};function s(r,a){return n(),c("div",t)}const i=e(o,[["render",s]]);export{i as default};
