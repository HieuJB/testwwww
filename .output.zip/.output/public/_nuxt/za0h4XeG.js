import"./O8DkhmHP.js";const e=window.setInterval;export{e as s};
