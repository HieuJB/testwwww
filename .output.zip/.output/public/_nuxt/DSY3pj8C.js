import{r as e,c as a,o}from"./W1_asCWg.js";const s={__name:"[category]",setup(r){return e(!1),(t,c)=>(o(),a("h1",null,"Football"))}};export{s as default};
