import"./4n7viQya.js";function n(){return new URL(window.location.href)}export{n as u};
