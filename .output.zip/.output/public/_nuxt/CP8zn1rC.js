import{aj as e}from"./B5g8yurY.js";const a=e("actions",{state:()=>({isOpenLoginForm:!1,isOpenRegisterForm:!1,isOpenFilterLeague:!1,isOpenSearchForm:!1}),actions:{}});export{a};
