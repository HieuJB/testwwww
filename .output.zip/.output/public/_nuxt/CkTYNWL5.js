import{G as s}from"./Cj98Ab3C.js";const t=s("/img/fx.svg");export{t as _};
