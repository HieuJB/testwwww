import"./CxwbT9MN.js";const e=window.setInterval;export{e as s};
