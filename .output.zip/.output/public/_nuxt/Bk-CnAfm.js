import{bU as s}from"./B3xriH40.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
