import{bZ as s}from"./czWVcWQw.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
