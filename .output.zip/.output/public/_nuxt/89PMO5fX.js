import"./C83JA1UV.js";function n(){return new URL(window.location.href)}export{n as u};
