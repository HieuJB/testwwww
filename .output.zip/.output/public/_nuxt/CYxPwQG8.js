import"./BWGl6XZh.js";function n(){return new URL(window.location.href)}export{n as u};
