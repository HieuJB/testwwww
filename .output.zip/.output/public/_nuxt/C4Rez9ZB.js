import{G as s}from"./D4y8QlQH.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
