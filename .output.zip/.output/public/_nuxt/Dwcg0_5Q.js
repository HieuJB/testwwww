function n(e){return new URL(window.location.href)}export{n as u};
