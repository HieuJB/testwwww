import"./Bk7GH-9W.js";function n(){return new URL(window.location.href)}export{n as u};
