import{Q as s}from"./Ctrld2vu.js";const t=s("/img/fx.svg");export{t as _};
