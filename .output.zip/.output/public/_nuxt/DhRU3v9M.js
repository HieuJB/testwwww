import{N as s}from"./Ce3hzi3s.js";const t=s("/img/fx.svg");export{t as _};
