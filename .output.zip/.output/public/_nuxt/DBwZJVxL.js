import{N as s}from"./4n7viQya.js";const t=s("/img/fx.svg");export{t as _};
