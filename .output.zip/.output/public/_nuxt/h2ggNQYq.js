import{dA as a,bH as o,bI as r,aN as t}from"./BxFeZXon.js";const n=a(()=>{const e=o();r();const s=t(null);return{route:e,infoLeague:s}});export{n as u};
