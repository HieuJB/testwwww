import{N as s}from"./BWGl6XZh.js";const t=s("/img/fx.svg");export{t as _};
