import{bZ as s}from"./BrR8eL8l.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
