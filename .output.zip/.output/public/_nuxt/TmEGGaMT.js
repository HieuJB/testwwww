import{G as s}from"./SWX6tv_t.js";const t=s("/img/fx.svg");export{t as _};
