import{bY as s}from"./C83JA1UV.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
