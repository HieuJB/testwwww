import{O as s}from"./CvyDlEIS.js";const t=s("/img/fx.svg");export{t as _};
