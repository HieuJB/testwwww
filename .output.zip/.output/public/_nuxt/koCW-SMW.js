import"./DhD8-Pn6.js";const e=window.setInterval;export{e as s};
