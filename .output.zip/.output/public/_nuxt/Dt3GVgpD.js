import{_ as e,c,o as t}from"./BB1OhIIt.js";const n={};function o(r,_){return t(),c("div",null," ewqweqqwe111111111111 ")}const s=e(n,[["render",o]]);export{s as default};
