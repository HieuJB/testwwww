import{dv as f}from"./C1MTHeC0.js";export{f as default};
