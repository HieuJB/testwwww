import{G as s}from"./C3mxrMP8.js";const t=s("/img/fx.svg");export{t as _};
