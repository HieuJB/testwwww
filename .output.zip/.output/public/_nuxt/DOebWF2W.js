import{G as s}from"./MaF3Ermi.js";const t=s("/img/fx.svg");export{t as _};
