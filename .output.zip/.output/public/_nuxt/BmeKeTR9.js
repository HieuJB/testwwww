import{N as s}from"./CZcWF3Qh.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
