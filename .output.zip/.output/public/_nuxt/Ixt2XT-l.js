import{bT as s}from"./B4RwAFdS.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
