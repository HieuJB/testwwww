import{N as s}from"./O8DkhmHP.js";const t=s("/img/fx.svg");export{t as _};
