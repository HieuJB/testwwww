import{Y as s}from"./DJS8guEt.js";const t=s("/img/fx.svg");export{t as _};
