import{an as e}from"./JgilxRpU.js";const s=e("match",{state:()=>({wssSocket:void 0,loadingMessages:!1,loadingMember:!1,socketData:[]}),actions:{}});export{s as u};
