import{N as s}from"./Bk7GH-9W.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
