import{_ as e,v as c,t as n}from"./7V5L8QMx.js";const s={};function t(r,o){return n(),c("div",null," News pages ")}const _=e(s,[["render",t]]);export{_ as default};
