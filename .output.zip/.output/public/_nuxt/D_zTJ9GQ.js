import{dA as f}from"./CroaTqPE.js";export{f as default};
