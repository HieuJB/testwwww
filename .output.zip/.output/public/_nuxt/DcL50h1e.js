import{P as s}from"./Dsuy2_zz.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
