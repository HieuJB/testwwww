import"./DOg6D9pF.js";const e=window.setInterval;export{e as s};
