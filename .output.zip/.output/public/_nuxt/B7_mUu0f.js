import{N as s}from"./Bk7GH-9W.js";const t=s("/img/fx.svg");export{t as _};
