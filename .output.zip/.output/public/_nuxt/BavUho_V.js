import{Q as s}from"./iaSiYbEh.js";const t=s("/img/fx.svg");export{t as _};
