import{cj as o,bG as r,aN as a}from"./BsbA-9aa.js";import{s as t}from"./tpOBq0x5.js";const n=o(()=>{const e=r();t();const s=a(null);return{route:e,infoLeague:s}});export{n as u};
