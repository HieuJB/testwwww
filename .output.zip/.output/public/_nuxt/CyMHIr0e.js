import{cj as o,a as r,r as a}from"./DBM9bqk4.js";import{s as t}from"./CCQRvh0p.js";const n=o(()=>{const e=r();t();const s=a(null);return{route:e,infoLeague:s}});export{n as u};
