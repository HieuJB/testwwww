import{G as s}from"./Cj98Ab3C.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
