import"./CUTupmkG.js";function t(e){return new URL(window.location.href)}export{t as u};
