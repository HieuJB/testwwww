import{G as s}from"./ZtBwf2Ze.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
