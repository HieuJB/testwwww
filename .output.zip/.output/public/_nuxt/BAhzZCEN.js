import{bW as e}from"./Cj98Ab3C.js";const a=e("match",{state:()=>({wssSocket:void 0,loadingMessages:!1,loadingMember:!1,socketData:[]}),actions:{}});export{a as u};
