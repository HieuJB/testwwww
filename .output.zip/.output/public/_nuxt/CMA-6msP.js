import{Q as s}from"./DSGQBYdq.js";const t=s("/img/fx.svg");export{t as _};
