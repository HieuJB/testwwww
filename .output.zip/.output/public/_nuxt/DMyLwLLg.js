import{ds as s}from"./DGwlZo00.js";export{s as default};
