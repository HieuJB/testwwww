import{Q as s}from"./B1e6I8EP.js";const t=s("/img/fx.svg");export{t as _};
