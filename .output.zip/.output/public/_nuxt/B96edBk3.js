import{aj as e}from"./DZ92njke.js";const s=e("match",{state:()=>({wssSocket:void 0,loadingMessages:!1,loadingMember:!1,socketData:[]}),actions:{}});export{s as u};
