import{S as s}from"./DOg6D9pF.js";const t=s("/img/fx.svg");export{t as _};
