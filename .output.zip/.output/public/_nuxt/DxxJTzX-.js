import"./DSGQBYdq.js";const e=window.setInterval;export{e as s};
