import{ai as e}from"./s7EpR-Qw.js";const s=e("match",{state:()=>({wssSocket:void 0,loadingMessages:!1,loadingMember:!1,socketData:[]}),actions:{}});export{s as u};
