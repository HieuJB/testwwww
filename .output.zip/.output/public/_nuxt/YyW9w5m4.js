import{al as e}from"./Bve7pSj2.js";const r=e((o,t)=>{});export{r as default};
