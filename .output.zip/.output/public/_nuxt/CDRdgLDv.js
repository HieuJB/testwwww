import{G as s}from"./ZtBwf2Ze.js";const t=s("/img/fx.svg");export{t as _};
