import{bZ as s}from"./CroaTqPE.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
