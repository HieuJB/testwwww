import"./s99M7IiU.js";const e=window.setInterval;export{e as s};
