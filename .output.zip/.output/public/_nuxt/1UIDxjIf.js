import"./B1e6I8EP.js";function t(e){return new URL(window.location.href)}export{t as u};
