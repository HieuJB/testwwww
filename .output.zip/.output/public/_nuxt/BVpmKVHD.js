import{ds as s}from"./DihkRQ9p.js";export{s as default};
