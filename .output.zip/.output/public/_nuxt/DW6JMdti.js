import{P as s}from"./DgHCimsw.js";const t=s("/img/fx.svg");export{t as _};
