import{N as s}from"./Bz_exKAH.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
