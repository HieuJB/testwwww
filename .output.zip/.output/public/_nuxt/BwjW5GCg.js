import"./Ctrld2vu.js";const e=window.setInterval;export{e as s};
