import{bU as s}from"./DC0_vZ0_.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
