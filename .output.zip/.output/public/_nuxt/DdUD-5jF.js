import{Q as s}from"./CxwbT9MN.js";const t=s("/img/fx.svg");export{t as _};
