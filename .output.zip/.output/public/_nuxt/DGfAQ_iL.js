import{dt as t}from"./KclCGdPJ.js";export{t as default};
