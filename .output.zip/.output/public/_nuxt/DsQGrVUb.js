import{bM as s}from"./n1csI74N.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
