import"./B1e6I8EP.js";const e=window.setInterval;export{e as s};
