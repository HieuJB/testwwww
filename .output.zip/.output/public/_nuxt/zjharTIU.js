import{O as s}from"./DhD8-Pn6.js";const t=s("/img/fx.svg");export{t as _};
