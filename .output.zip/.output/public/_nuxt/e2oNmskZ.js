import{dv as f}from"./BEMYdC11.js";export{f as default};
