import{O as s}from"./Bxd5akP6.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
