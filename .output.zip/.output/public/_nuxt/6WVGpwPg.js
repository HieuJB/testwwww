import{S as s}from"./DOg6D9pF.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
