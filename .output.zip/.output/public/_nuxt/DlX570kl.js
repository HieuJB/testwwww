import{ai as e}from"./Bk7GH-9W.js";const s=e("match",{state:()=>({wssSocket:void 0,loadingMessages:!1,loadingMember:!1,socketData:[]}),actions:{}});export{s as u};
