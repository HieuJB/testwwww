import"./BFsloeq7.js";function n(){return new URL(window.location.href)}export{n as u};
