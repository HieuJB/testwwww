import{G as s}from"./DCsWAUUX.js";const t=s("/img/fx.svg");export{t as _};
