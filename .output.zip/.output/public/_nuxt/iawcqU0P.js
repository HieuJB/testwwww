import{N as s}from"./O_gRmHBr.js";const t=s("/img/fx.svg");export{t as _};
