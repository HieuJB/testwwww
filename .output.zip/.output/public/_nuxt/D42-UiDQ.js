import{Q as s}from"./B1e6I8EP.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
