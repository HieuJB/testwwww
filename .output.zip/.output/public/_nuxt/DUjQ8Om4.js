import{bS as s}from"./DigN3n0Z.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
