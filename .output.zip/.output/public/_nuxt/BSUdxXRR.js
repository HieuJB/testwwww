import"./Dxxz3yQz.js";const e=window.setInterval;export{e as s};
