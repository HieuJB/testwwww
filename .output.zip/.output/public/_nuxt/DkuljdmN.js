import{P as s}from"./Dsuy2_zz.js";const t=s("/img/fx.svg");export{t as _};
