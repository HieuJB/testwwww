import{G as s}from"./B6rUrlSv.js";const t=s("/img/fx.svg");export{t as _};
