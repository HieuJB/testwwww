function e(){return new URL(window.location.href)}export{e as u};
