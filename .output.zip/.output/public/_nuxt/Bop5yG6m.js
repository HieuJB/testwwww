import{N as s}from"./Bve7pSj2.js";const t=s("/img/fx.svg");export{t as _};
