import"./CbBa1s43.js";function n(){return new URL(window.location.href)}export{n as u};
