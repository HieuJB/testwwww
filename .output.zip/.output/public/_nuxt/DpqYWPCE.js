import{M as s}from"./B5g8yurY.js";const t=s("/img/fx.svg");export{t as _};
