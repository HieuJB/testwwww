import{Q as s}from"./CxwbT9MN.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
