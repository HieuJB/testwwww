import{N as s}from"./s7EpR-Qw.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
