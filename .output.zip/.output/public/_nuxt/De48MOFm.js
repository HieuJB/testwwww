import{cy as a,a as o,s as r,r as t}from"./t6iZGvzl.js";const n=a(()=>{const e=o();r();const s=t(null);return{route:e,infoLeague:s}});export{n as u};
