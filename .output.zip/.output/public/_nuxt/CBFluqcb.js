import{M as s}from"./CNWrwO0D.js";const t=s("/img/fx.svg");export{t as _};
