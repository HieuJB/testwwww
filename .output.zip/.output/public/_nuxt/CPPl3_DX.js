import"./O_gRmHBr.js";const e=window.setInterval;export{e as s};
