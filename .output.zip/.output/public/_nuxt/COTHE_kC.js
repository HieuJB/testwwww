import"./D-EA2D1w.js";function n(){return new URL(window.location.href)}export{n as u};
