import{G as s}from"./Btv9gqZp.js";const t=s("/img/fx.svg");export{t as _};
