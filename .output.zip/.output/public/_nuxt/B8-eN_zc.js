import{N as s}from"./O_gRmHBr.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
