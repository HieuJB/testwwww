import{r as e,c as a,o}from"./Dxxz3yQz.js";const s={__name:"[category]",setup(r){return e(!1),(t,c)=>(o(),a("h1",null,"Football"))}};export{s as default};
