import{cw as a,a as o,s as r,r as t}from"./CbBa1s43.js";const n=a(()=>{const e=o();r();const s=t(null);return{route:e,infoLeague:s}});export{n as u};
