import{c9 as e}from"./DC0_vZ0_.js";const a=e("actions",{state:()=>({isOpenLoginForm:!1,isOpenRegisterForm:!1,isOpenFilterLeague:!1,isOpenSearchForm:!1}),actions:{}});export{a};
