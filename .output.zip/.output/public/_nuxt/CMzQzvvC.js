import"./D4y8QlQH.js";function n(){return new URL(window.location.href)}export{n as u};
