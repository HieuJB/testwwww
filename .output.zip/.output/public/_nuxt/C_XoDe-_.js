import{_ as e,c,o as t}from"./DihkRQ9p.js";const n={};function o(r,_){return t(),c("div",null," ewqweqqwe11111111111122222222222222222 ")}const s=e(n,[["render",o]]);export{s as default};
