import{Q as s}from"./BfkfDnBD.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
