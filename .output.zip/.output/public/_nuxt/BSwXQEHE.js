import{G as s}from"./D4y8QlQH.js";const t=s("/img/fx.svg");export{t as _};
