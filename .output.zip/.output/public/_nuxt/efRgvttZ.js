import{O as s}from"./DhD8-Pn6.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
