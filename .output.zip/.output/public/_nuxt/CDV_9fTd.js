import{O as s}from"./s99M7IiU.js";const t=s("/img/fx.svg");export{t as _};
