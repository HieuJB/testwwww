import{bL as s}from"./Dh5VsZTZ.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
