import{aN as e,c as a,o}from"./_Y1avJXr.js";const s={__name:"[category]",setup(t){return e(!1),(r,c)=>(o(),a("h1",null,"Football"))}};export{s as default};
