import"./Bve7pSj2.js";const e=window.setInterval;export{e as s};
