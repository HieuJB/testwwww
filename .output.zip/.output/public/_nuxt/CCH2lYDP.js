import"./Dsuy2_zz.js";const e=window.setInterval;export{e as s};
