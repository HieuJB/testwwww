import{bT as s}from"./BIer192b.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
