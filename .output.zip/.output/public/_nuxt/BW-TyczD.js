import{bZ as s}from"./Dy4CPT7x.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
