import{_ as s}from"./Dm80aAQq.js";const a={};function d(e,r){return" dsasdadassdaddsaasdasdasddsasadasd "}const n=s(a,[["render",d]]);export{n as default};
