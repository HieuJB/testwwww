import{_ as e,c,o as n}from"./5yXop0vV.js";const o={},t={id:"warehouse-screen",class:"mcontent container"};function s(r,a){return n(),c("div",t)}const i=e(o,[["render",s]]);export{i as default};
