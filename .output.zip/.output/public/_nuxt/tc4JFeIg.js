import{an as e}from"./B1e6I8EP.js";const s=e("match",{state:()=>({wssSocket:void 0,loadingMessages:!1,loadingMember:!1,socketData:[]}),actions:{}});export{s as u};
