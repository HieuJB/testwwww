import{M as s}from"./B5g8yurY.js";const t=s("/icon/left.svg"),i=s("/icon/right.svg");export{t as _,i as a};
