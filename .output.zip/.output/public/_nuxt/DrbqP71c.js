import"./BfkfDnBD.js";const e=window.setInterval;export{e as s};
